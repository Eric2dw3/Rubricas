-- phpMyAdmin SQL Dump
-- version 4.7.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Dec 11, 2017 at 12:40 PM
-- Server version: 10.1.26-MariaDB
-- PHP Version: 7.1.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `Rubrica`
--

-- --------------------------------------------------------

--
-- Table structure for table `Centro`
--

CREATE TABLE `Centro` (
  `ID_Centro` int(11) NOT NULL,
  `COD_Centro` varchar(10) NOT NULL,
  `DESC_Centro` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Centro`
--

INSERT INTO `Centro` (`ID_Centro`, `COD_Centro`, `DESC_Centro`) VALUES
(1, '015110', 'CIFP Txurdinaga LHII'),
(2, '015111', 'CIFP Elorrieta');

-- --------------------------------------------------------

--
-- Table structure for table `Ciclo`
--

CREATE TABLE `Ciclo` (
  `ID_Ciclo` int(11) NOT NULL,
  `ID_Centro` int(11) NOT NULL,
  `ID_Curso` int(11) NOT NULL,
  `COD_Ciclo` varchar(10) NOT NULL,
  `DESC_Ciclo` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Ciclo`
--

INSERT INTO `Ciclo` (`ID_Ciclo`, `ID_Centro`, `ID_Curso`, `COD_Ciclo`, `DESC_Ciclo`) VALUES
(4, 1, 1, '2DW3', 'Desarrollo web'),
(5, 1, 4, '2DM3', 'Desarrollo Multiplataforma'),
(6, 2, 1, '2DW3', 'Desarrollo Web'),
(7, 2, 4, '2DM3', 'Desarrollo Multiplataforma');

-- --------------------------------------------------------

--
-- Table structure for table `Curso`
--

CREATE TABLE `Curso` (
  `ID_Curso` int(11) NOT NULL,
  `COD_Curso` varchar(9) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Curso`
--

INSERT INTO `Curso` (`ID_Curso`, `COD_Curso`) VALUES
(1, '2017-2018'),
(4, '2018-2019'),
(5, '2019-2020');

-- --------------------------------------------------------

--
-- Table structure for table `Equipo`
--

CREATE TABLE `Equipo` (
  `ID_Equipo` int(11) NOT NULL,
  `ID_Reto_Modulo` int(11) NOT NULL,
  `COD_Equipo` varchar(10) NOT NULL,
  `DESC_Equipo` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `Equipo_Usuario`
--

CREATE TABLE `Equipo_Usuario` (
  `ID_Equipo_Alaumno` int(11) NOT NULL,
  `ID_Equipo` int(11) NOT NULL,
  `ID_Usuario` int(11) NOT NULL,
  `COD_Rol` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `Modulo`
--

CREATE TABLE `Modulo` (
  `ID_Modulo` int(11) NOT NULL,
  `ID_Ciclo` int(11) NOT NULL,
  `COD_Modulo` varchar(10) NOT NULL,
  `DESC_Modulo` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `Reto`
--

CREATE TABLE `Reto` (
  `ID_Reto` int(11) NOT NULL,
  `COD_Reto` varchar(10) NOT NULL,
  `DESC_Reto` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `Reto_Modulo`
--

CREATE TABLE `Reto_Modulo` (
  `ID_Reto_modulo` int(11) NOT NULL,
  `ID_Reto` int(11) NOT NULL,
  `ID_Modulo` int(11) NOT NULL,
  `ID_UAdmin` int(11) NOT NULL,
  `IN_Extendido` tinyint(1) NOT NULL,
  `IN_EAbierta` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `TEvaluador`
--

CREATE TABLE `TEvaluador` (
  `ID_TEvaluador` int(11) NOT NULL,
  `DESC_TEvaluador` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `TNEvaluador`
--

CREATE TABLE `TNEvaluador` (
  `ID_TNEvaluador` int(11) NOT NULL,
  `DESC_TNEvaluador` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `TUsuario`
--

CREATE TABLE `TUsuario` (
  `ID_TUsuario` int(11) NOT NULL,
  `DESC_TUsuario` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `Usuario`
--

CREATE TABLE `Usuario` (
  `ID_Usuario` int(11) NOT NULL,
  `ID_Centro` int(11) NOT NULL,
  `ID_TUsuario` int(11) NOT NULL,
  `User` varchar(15) NOT NULL,
  `Password` varchar(50) NOT NULL,
  `Nombre` varchar(50) NOT NULL,
  `Apellidos` varchar(100) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `Dni` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `Usuario_Modulo`
--

CREATE TABLE `Usuario_Modulo` (
  `ID_Usuario_Modulo` int(11) NOT NULL,
  `ID_Usuario` int(11) NOT NULL,
  `ID_Modulo` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `Centro`
--
ALTER TABLE `Centro`
  ADD PRIMARY KEY (`ID_Centro`);

--
-- Indexes for table `Ciclo`
--
ALTER TABLE `Ciclo`
  ADD PRIMARY KEY (`ID_Ciclo`),
  ADD KEY `ID_Centro` (`ID_Centro`,`ID_Curso`),
  ADD KEY `ID_Curso` (`ID_Curso`);

--
-- Indexes for table `Curso`
--
ALTER TABLE `Curso`
  ADD PRIMARY KEY (`ID_Curso`);

--
-- Indexes for table `Equipo`
--
ALTER TABLE `Equipo`
  ADD PRIMARY KEY (`ID_Equipo`),
  ADD KEY `ID_Reto` (`ID_Reto_Modulo`),
  ADD KEY `ID_Reto_Modulo` (`ID_Reto_Modulo`);

--
-- Indexes for table `Equipo_Usuario`
--
ALTER TABLE `Equipo_Usuario`
  ADD PRIMARY KEY (`ID_Equipo_Alaumno`),
  ADD KEY `ID_Equipo` (`ID_Equipo`,`ID_Usuario`),
  ADD KEY `ID_Usuario` (`ID_Usuario`);

--
-- Indexes for table `Modulo`
--
ALTER TABLE `Modulo`
  ADD PRIMARY KEY (`ID_Modulo`),
  ADD KEY `ID_Ciclo` (`ID_Ciclo`);

--
-- Indexes for table `Reto`
--
ALTER TABLE `Reto`
  ADD PRIMARY KEY (`ID_Reto`);

--
-- Indexes for table `Reto_Modulo`
--
ALTER TABLE `Reto_Modulo`
  ADD PRIMARY KEY (`ID_Reto_modulo`),
  ADD KEY `ID_Reto` (`ID_Reto`,`ID_Modulo`,`ID_UAdmin`),
  ADD KEY `ID_Modulo` (`ID_Modulo`);

--
-- Indexes for table `TEvaluador`
--
ALTER TABLE `TEvaluador`
  ADD PRIMARY KEY (`ID_TEvaluador`);

--
-- Indexes for table `TNEvaluador`
--
ALTER TABLE `TNEvaluador`
  ADD PRIMARY KEY (`ID_TNEvaluador`);

--
-- Indexes for table `TUsuario`
--
ALTER TABLE `TUsuario`
  ADD PRIMARY KEY (`ID_TUsuario`);

--
-- Indexes for table `Usuario`
--
ALTER TABLE `Usuario`
  ADD PRIMARY KEY (`ID_Usuario`),
  ADD KEY `ID_Centro` (`ID_Centro`,`ID_TUsuario`),
  ADD KEY `ID_TUsuario` (`ID_TUsuario`);

--
-- Indexes for table `Usuario_Modulo`
--
ALTER TABLE `Usuario_Modulo`
  ADD PRIMARY KEY (`ID_Usuario_Modulo`),
  ADD KEY `ID_Usuario` (`ID_Usuario`,`ID_Modulo`),
  ADD KEY `ID_Modulo` (`ID_Modulo`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `Centro`
--
ALTER TABLE `Centro`
  MODIFY `ID_Centro` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `Ciclo`
--
ALTER TABLE `Ciclo`
  MODIFY `ID_Ciclo` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `Curso`
--
ALTER TABLE `Curso`
  MODIFY `ID_Curso` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `Equipo`
--
ALTER TABLE `Equipo`
  MODIFY `ID_Equipo` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `Equipo_Usuario`
--
ALTER TABLE `Equipo_Usuario`
  MODIFY `ID_Equipo_Alaumno` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `Modulo`
--
ALTER TABLE `Modulo`
  MODIFY `ID_Modulo` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `Reto`
--
ALTER TABLE `Reto`
  MODIFY `ID_Reto` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `Reto_Modulo`
--
ALTER TABLE `Reto_Modulo`
  MODIFY `ID_Reto_modulo` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `TEvaluador`
--
ALTER TABLE `TEvaluador`
  MODIFY `ID_TEvaluador` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `TNEvaluador`
--
ALTER TABLE `TNEvaluador`
  MODIFY `ID_TNEvaluador` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `TUsuario`
--
ALTER TABLE `TUsuario`
  MODIFY `ID_TUsuario` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `Usuario`
--
ALTER TABLE `Usuario`
  MODIFY `ID_Usuario` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `Usuario_Modulo`
--
ALTER TABLE `Usuario_Modulo`
  MODIFY `ID_Usuario_Modulo` int(11) NOT NULL AUTO_INCREMENT;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `Ciclo`
--
ALTER TABLE `Ciclo`
  ADD CONSTRAINT `Ciclo_ibfk_1` FOREIGN KEY (`ID_Curso`) REFERENCES `Curso` (`ID_Curso`),
  ADD CONSTRAINT `Ciclo_ibfk_2` FOREIGN KEY (`ID_Centro`) REFERENCES `Centro` (`ID_Centro`);

--
-- Constraints for table `Equipo`
--
ALTER TABLE `Equipo`
  ADD CONSTRAINT `Equipo_ibfk_1` FOREIGN KEY (`ID_Reto_Modulo`) REFERENCES `Reto_Modulo` (`ID_Reto_modulo`);

--
-- Constraints for table `Equipo_Usuario`
--
ALTER TABLE `Equipo_Usuario`
  ADD CONSTRAINT `Equipo_Usuario_ibfk_1` FOREIGN KEY (`ID_Equipo`) REFERENCES `Equipo` (`ID_Equipo`),
  ADD CONSTRAINT `Equipo_Usuario_ibfk_2` FOREIGN KEY (`ID_Usuario`) REFERENCES `Usuario` (`ID_Usuario`);

--
-- Constraints for table `Modulo`
--
ALTER TABLE `Modulo`
  ADD CONSTRAINT `Modulo_ibfk_1` FOREIGN KEY (`ID_Ciclo`) REFERENCES `Ciclo` (`ID_Ciclo`);

--
-- Constraints for table `Reto_Modulo`
--
ALTER TABLE `Reto_Modulo`
  ADD CONSTRAINT `Reto_Modulo_ibfk_1` FOREIGN KEY (`ID_Reto`) REFERENCES `Reto` (`ID_Reto`),
  ADD CONSTRAINT `Reto_Modulo_ibfk_2` FOREIGN KEY (`ID_Modulo`) REFERENCES `Modulo` (`ID_Modulo`);

--
-- Constraints for table `Usuario`
--
ALTER TABLE `Usuario`
  ADD CONSTRAINT `Usuario_ibfk_1` FOREIGN KEY (`ID_TUsuario`) REFERENCES `TUsuario` (`ID_TUsuario`),
  ADD CONSTRAINT `Usuario_ibfk_2` FOREIGN KEY (`ID_Centro`) REFERENCES `Centro` (`ID_Centro`);

--
-- Constraints for table `Usuario_Modulo`
--
ALTER TABLE `Usuario_Modulo`
  ADD CONSTRAINT `Usuario_Modulo_ibfk_1` FOREIGN KEY (`ID_Usuario`) REFERENCES `Usuario` (`ID_Usuario`),
  ADD CONSTRAINT `Usuario_Modulo_ibfk_2` FOREIGN KEY (`ID_Modulo`) REFERENCES `Modulo` (`ID_Modulo`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Alumno extends CI_Controller {

	function __construct(){
		parent::__construct();
		$this->load->helper('form');
		$this->load->helper('url');		
		$this->load->model('Alumno_model');
	}

	//ok
	public function index()
	{
	
		//$ID_Usuario = '15';
	
		//$datos['Retos'] = $this->Alumno_model->obtener_RetosAlumno($ID_Usuario);
		
		$this->load->view('Alumno/listar_centro');
	
	}
	public function anadir_nota()
	{
		$ID_Usuario = '15';
		$Nota = $_GET['N'];
		$ID_UsuarioA = $_GET['ID_Usuario'];
		$ID_Competencia = $_GET['ID_Competencia'];

		$this->Alumno_model->anadir_Alumno_notas($Nota,$ID_UsuarioA,$ID_Competencia,$ID_Usuario);

	}
	public function Notas()
	{

		$Reto=$this->uri->segment(3);
		$ID_Evaluador = '15';

		$datos['NotasA'] = $this->Alumno_model->obtener_Notasalumnos($Reto,$ID_Evaluador);
		$datos['Porcentaje'] = $this->Alumno_model->obtener_Porcentaje();
		$datos['ob'] = $this->Alumno_model->obtener_ob();
		
		$this->load->view('header');
		$this->load->view('Alumno/body_Alumno',$datos);
		$this->load->view('footer');
	}
	


}
<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class GrupoCompetencia extends CI_Controller {

	function __construct(){
		parent::__construct();
		$this->load->helper('form');
		$this->load->helper('url');		
		$this->load->model('GrupoCompetencia_model');
	}

	//ok
	public function index()
	{
		$datos['segmento']=$this->uri->segment(3);
		if (!$datos['segmento']){
			$datos['GrupoCompetencias'] = $this->GrupoCompetencia_model->obtener_GrupoCompetencias();
		}else{
			$datos['GrupoCompetencias'] = $this->GrupoCompetencia_model->obtener_GrupoCompetencia($datos['segmento']);
		}
	
		$this->load->view('header');
		$this->load->view('GrupoCompetencia/listar_GrupoCompetencia',$datos);
		$this->load->view('footer');
	}

	
	public function filtrar_GrupoCompetencia(){
	
		$this->GrupoCompetencia_model->obtener_GrupoCompetencia();		
	}	
}
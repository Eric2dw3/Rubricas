<?php
$form = array(
	'name' => 'form_Reto'
	);
$COD_Reto = array(
	'name' => 'COD_Reto',
	'placeholder' => 'Código de Reto',
	'maxlength' => 10,
	'size' => 20
	);
$DESC_Reto = array(	
	'name' => 'DESC_Reto',
	'placeholder' => 'Descripción de Reto',
	'maxlength' => 100,
	'size' => 30
	);
?>


<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
<script type="text/javascript">
		$("document").ready(function(){
	
				$(".target").on('change',function(){
					
					//alert($(this).val())
					var Nota=$(this).val();
					var ID_Usuario=$(this).attr("id"); 
					var ID_Competencia=$(this).attr("name"); 
					
					  $.get('../anadir_nota',{N:Nota,ID_Usuario:ID_Usuario,ID_Competencia:ID_Competencia});
					  location.reload();
			
				
				});
			
		});
	</script>
<style>
	table, th, td {
    border: 1px solid black;

}

#user{
width: 200px;	
min-width: 200px;
}
#nota{
width: 308px;	
min-width: 308px;
}
#nota2{
width: 50px;	
min-width: 50px;
}
#th{
width: 308px;	
min-width: 308px;
}

</style>



<?
if (isset($Retos)) {
foreach ($Retos->result() as $Reto) {
?>	
<a href="Alumno/Notas/<?= $Reto->ID_Reto;?>"><?=$Reto->COD_Reto;?></a><br>
<?
}}
?>
<?


if (isset($NotasA)) {

$Usuario = 0;
$kontotal= 0;
?>

<div style="overflow-x:auto;">
<table>
	<th id="user"></th>
<?
	foreach ($ob->result() as $os) {

		?><th id="th"><?=$os->DESC_Competencia;?></th><?
	}
?>
<th id="nota2">Nota Final</th>
</table>
<?

$kont2= 0;
$kont= 0;
$va=0;
$Arr="";
$array = "";
foreach ($NotasA->result() as $Nota) {
$selec="";$selec1="";$selec2="";$selec3="";
$kontotal++;	
if ($Usuario == $Nota->ID_Usuario) {
	$kont++;
	switch ($Nota->Nota) {
    case 2:
       	$selec="selected='selected'";
        break;
    case 5:
       	$selec1="selected='selected'";
        break;
    case 7:
        $selec2="selected='selected'";
        break;
    case 10:
        $selec3="selected='selected'";
        break;
}
	?>
	
		<td id="nota">
		<select class="target" id=<?=$Nota->ID_Usuario?> name=<?=$Nota->ID_Competencia?>>    
       		<option value="2" <?=$selec?>>Mal</option>
       		<option value="5" <?=$selec1?>>Regular</option>
       		<option value="7" <?=$selec2?>>Bien</option>
       		 <option value="10"<?=$selec3?>>Excelente</option>
  		 </select>
		</td>
		
		<?

		if ($Nota->Nota==10) {
			$Arr=  $Arr.'A';
		}else{
		$Arr=  $Arr.$Nota->Nota;
	}

		?>
	

	<?
	if ($kont== 5) {
		 $kont= 0;
		 $kompr2=0;
		 $Notatotal2=0;
		 $arr1 = str_split($Arr);
	for ($i=0; $i < 5; $i++) { 
		if ($arr1[$i] == 'A') {
			$arr1[$i]='10';
		}
	}

	for ($i=0; $i < 5; $i++) { 
	foreach ($Porcentaje->result() as $Porcenta) {
					if ($i+1==$Porcenta->ID_Competencia ) {
						$kompr2=$Porcenta->Porcentaje;
						

					}elseif ($i==4) {
						$kompr2=$Porcenta->Porcentaje;
						
					}
				}
			if ( $kompr2 !=0) {

			$Notatotal = $arr1[$i]*($kompr2/100);

			$Notatotal2=  $Notatotal2+$Notatotal;
		}
	}

	?>
		<td id="nota2"><?=$Notatotal2;?></td>
	
		
	<?
		}
}else{
	switch ($Nota->Nota) {
    case 2:
       	$selec="selected='selected'";
        break;
    case 5:
       	$selec1="selected='selected'";
        break;
    case 7:
        $selec2="selected='selected'";
        break;
    case 10:
        $selec3="selected='selected'";
        break;
}
	

	?><table>

	<td id="user"><? echo $Nota->User," ", $Nota->Apellidos?></td>
	<td id="nota">
	<select  class="target" id=<?=$Nota->ID_Usuario?> name=<?=$Nota->ID_Competencia?>>    
       <option value="2" <?=$selec?>>Mal</option>
       <option value="5" <?=$selec1?>>Regular</option>
       <option value="7" <?=$selec2?>>Bien</option>
        <option value="10"<?=$selec3?>>Excelente</option>
   </select>
	</td>	

	<?
	
	if ($Nota->Nota==10) {
		$Arr=  'A';
	}else{
		$Arr= $Nota->Nota;
	}

	
	$kont++;
	$Usuario = $Nota->ID_Usuario;


}?><?}

?>

</table>
</div>
<?

}
?>






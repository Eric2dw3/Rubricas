<?php
$form = array(
	'name' => 'form_RetoModulo'
	);
$url = "'".base_url()."index.php/RetoModulo'";
$js_cancel_button = 'onClick="location.href='.$url.'"';
/*$ID_UAdmin = array(	
	'name' => 'ID_UAdmin',
	'value' =>  $RetoModulos->result()[0]->ID_UAdmin,
	'placeholder' => 'ID_UAdmin',
	'maxlength' => 11,
	'size' => 11,
	'required' => 1
	);*/
$IN_Extendido = array(	
	'name' => 'IN_Extendido',
	'value' =>  $RetoModulos->result()[0]->IN_Extendido,
	'maxlength' => 1,
	'size' =>1,
	'required' => 1
	);
$IN_EAbierta = array(	
	'name' => 'IN_EAbierta',
	'placeholder' => 'IN_EAbierta',
	'maxlength' => 1,
	'size' => 1,
	'required' => 1,
	'value' => $RetoModulos->result()[0]->IN_EAbierta	
	);

	if ($Retos){
		$ID_Reto = array();
		foreach ($Retos->result() as $Reto) {
			$ID_Reto[$Reto->ID_Reto] = $Reto->COD_Reto;
		}	
	}
	else{
		$ID_Reto = array(
    		0         => 'No hay Retos'
		);
	}

	if ($Modulos){
		$ID_Modulo = array();
		foreach ($Modulos->result() as $Modulo) {
			$ID_Modulo[$Modulo->ID_Modulo] = $Modulo->COD_Modulo;
		}	
	}
	else{
		$ID_Modulo = array(
    		0         => 'No hay Modulos'
		);
	}	
	if ($Usuarios){
		$ID_Usuario = array();
		foreach ($Usuarios->result() as $Admin) {
			$ID_Usuario[$Admin->ID_Usuario] = $Admin->User;
		}	
	}
	else{
		$ID_Usuario = array(
    		0         => 'No hay Administrador'
		);
	}	

?>

<div>
	<?php echo form_open('RetoModulo/actualizar/'.$RetoModulos->result()[0]->ID_Reto_modulo);?>
	<?php echo form_label('Reto: ','ID_Reto'); ?>
	<?php
	//DESPLEGABLE DE CENTRO
	echo form_dropdown('ID_Reto', $ID_Reto, $RetoModulos->result()[0]->ID_Reto);
	?>
	<br>

	<?php echo form_label('Modulo: ','ID_Modulo'); ?>
	<?php
	//DESPLEGABLE DE CURSOS
	echo form_dropdown('ID_Modulo', $ID_Modulo, $RetoModulos->result()[0]->ID_Modulo);
	?>
	<br>
	<?php echo form_label('Administrador: ','ID_Usuario'); ?>
	<?php
	//DESPLEGABLE DE CURSOS
	echo form_dropdown('ID_UAdmin', $ID_Usuario, $RetoModulos->result()[0]->ID_UAdmin);
	?>
	<br>
	<?php echo form_label('IN_Extendido: ','IN_Extendido'); ?>
	<?php echo form_input($IN_Extendido); ?>
	<br>
	<?php echo form_label('IN_EAbierta: ','IN_EAbierta'); ?>
	<?php echo form_input($IN_EAbierta); ?>
	<br>
	<?php echo form_submit('Actualizar','Actualizar'); ?>
	<?php echo form_button('Cancelar','Cancelar',$js_cancel_button); ?>	
	<?php echo form_close();?>
</div>
<?php
$form = array(
	'name' => 'form_equipousuario'
	);
$COD_Rol = array(	
	'name' => 'COD_Rol',
	'placeholder' => 'COD_Rol',
	'maxlength' => 100,
	'size' => 30,
	'required' => 1
	);


	if ($Equipos){
		$ID_Equipo = array();
		foreach ($Equipos->result() as $Equipo) {
			$ID_Equipo[$Equipo->ID_Equipo] = $Equipo->COD_Equipo;
		}	
	}
	else{
		$ID_Equipo = array(
    		0         => 'No hay Equipos'
		);
	}

	if ($Usuarios){
		$ID_Usuario = array();
		foreach ($Usuarios->result() as $Usuario) {
			$ID_Usuario[$Usuario->ID_Usuario] = $Usuario->User;
		}	
	}
	else{
		$ID_Usuario = array(
    		0         => 'No hay Usuarios'
		);
	}	

?>


<button class="accordion">Crear EqupoUsuario</button>



	<div class="panel">
	<?php echo form_open('EquipoUsuario/nuevo_equipousuario',$form);?>
	<?php echo form_label('Equipo: ','ID_Equipo'); ?>
	<?php
	//DESPLEGABLE DE Equipo
	echo form_dropdown('ID_Equipo', $ID_Equipo,1);
	?>
	<br>

	<?php echo form_label('Usuario: ','ID_Usuario'); ?>
	<?php
	//DESPLEGABLE DE UsuarioS
	echo form_dropdown('ID_Usuario', $ID_Usuario,1);
	?>
	<br>
	<?php echo form_label('COD_Rol: ','COD_Rol'); ?>
	<?php echo form_input($COD_Rol); ?>
	<br>
	<?php echo form_submit('Crear','Crear'); ?>
	<?php echo form_close();?>
</div>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<link href="login.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" type="text/css" href="<? echo base_url();?>css/login.css">

<div id="header">
	<ul class="nav">
		<li><a href="<? echo base_url();?>index.php/Centro">Centro</a></li>
		<li><a href="<? echo base_url();?>index.php/Ciclo">Ciclo</a></li>
		<li><a href="<? echo base_url();?>index.php/Curso">Curso</a></li>
		<li><a href="<? echo base_url();?>index.php/Equipo">Equipo</a>
			<ul>
				<li><a href="<? echo base_url();?>index.php/EquipoUsuario">EquipoUsuario</a></li>
			</ul>
		</li>
		<li><a href="<? echo base_url();?>index.php/Reto">Reto</a>
			<ul>
				<li><a href="<? echo base_url();?>index.php/RetoModulo">RetoModulo</a></li>
				<li><a href="<? echo base_url();?>index.php/Modulo">Modulo</a></li>
			</ul>
		</li>
		<li><a href="<? echo base_url();?>index.php/Usuario">Usuarios</a>
			<ul>
				<li><a href="<? echo base_url();?>index.php/TUsuario">TUsuarios</a></li>
				<li><a href="<? echo base_url();?>index.php/UsuarioModulo">UsuarioModulo</a></li>
			</ul>
		</li>
		<li><a href="<? echo base_url();?>index.php/Medicion">Medición</a>
			<ul>
				<li><a href="<? echo base_url();?>index.php/Medicion_GupoCompetencia_Competencia">Medicion_GupoCompetencia_Competencias</a></li>
			</ul>
		</li>
		<li><a href="<? echo base_url();?>index.php/Competencia">Comp.</a>
			<ul>
				<li><a href="<? echo base_url();?>index.php/GrupoCompetencia">GrupoCompetencia</a></li>
			</ul>
		</li>
		<li><a href="<? echo base_url();?>index.php/login" id="animacion">Logout</a></li>
	</ul><br><br>
</div>

</head>

<body>
<header>
    <title>Rúbricas</title>
</header>

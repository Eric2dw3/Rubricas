<div>
	
<b class="borde">Gestión de EQUIPOS</b><br>

		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
	
	
		
	<script type="text/javascript">
var box = [];
var ciclo =[];
var activo = false;

function gurdar(id){
		 	 alert(id); 
		}
$("document").ready(function(source){

	$('#Eliminar').click(function(event) {
		if(activo==false){
			for(var i=0;i<box.length;i++){
				z=box[i];
				alert(z);
		 		$.get('Equipo/borrar',{box:z});
			}
			box = [];
			ciclo =[];
			mostrartabla();
		}
		if(activo){
			for(var i=0;i<ciclo.length;i++){
				z=ciclo[i];
				alert (z);
		 		$.get('Equipo/borrar',{box:z});
			}
			activo=false;
			box = [];
			ciclo =[];
		}
		mostrartabla();
	});

		mostrartabla();

	$('#select-all').click(function(event) {  
	 if(this.checked) {
		$(':checkbox').each(function() {
			this.checked = true;                        
		});
	  }
	  else {
	    $(':checkbox').each(function() {
	          this.checked = false;
		});
	  }

	});

	$(document).on('change','input[type="checkbox"]' ,function(e) {
		if(this.id=="select-all") {
			if(activo==false){
				activo = true;
				for(var i=0;i<ciclo.length;i++){
						box[i]=ciclo[i];
				}
			}else{
				activo=false;
				box=[];
			}
		}
		else{
	        if(this.checked){
	        	box.push(this.value);
	        	activo=false;
				box = jQuery.unique(box);
				alert('box '+box);
	        }
	        else{

	        	alert('elimino el '+this.value);
			    box.splice($.inArray(this.value, box),1);
				activo=false;
				alert('box '+box);
				document.getElementById('select-all').checked = false;
				ciclo = jQuery.unique(ciclo);
				box = jQuery.unique(box);
	        }
	    }
	    
	});

				function mostrartabla() {

				document.getElementById('select-all').checked = false;
					//var cod1 = document.getElementById('Equipos').value;
					//var cod2 = document.getElementById('TEquipo').value;

  $.get('Equipo/filtrar_Equipo', function(datos){
		ciclo=[];
							datos2=JSON.parse(datos);
							document.getElementById("sacardatos").innerHTML="";
							$("#sacardatos").append(
								"<tr><td></td><td><strong>ID_Equipo</strong></td><td><strong>ID_Reto</strong></td><td><strong>COD_Equipo</strong></td><td><strong>DESC_Equipo</strong></td></tr>"
						)
						$.each(datos2,function(indice,valor){
						ciclo.push(valor.ID_Equipo);						
						ciclo = jQuery.unique(ciclo);
		
							$("#sacardatos").append(

									
  "<tr><td><input type='checkbox' name='checkbox[]' id='"+valor.ID_Equipo+"'class='td1' value='"+valor.ID_Equipo+"'></td><td><a href=Equipo/editar/"+valor.ID_Equipo+">"+valor.ID_Equipo+"</a></td><td><a href=Equipo/editar/"+valor.ID_Equipo+">"+valor.ID_Reto+"</a></td><td><a href=Equipo/editar/"+valor.ID_Equipo+">"+valor.COD_Equipo+"</a></td><td><a href=Equipo/editar/"+valor.ID_Equipo+">"+valor.DESC_Equipo+"</a></td>"
								)
						});
					});
}
					
		mostrartabla();

	});

	</script>
	<hr>
	<input type='checkbox' name='select-all' id='select-all'>
	<table id='sacardatos'>
	</table>
	<input type="submit" name="BtnEliminar" value="Eliminar" id="Eliminar"/>
	<br>
	<hr>
</div>
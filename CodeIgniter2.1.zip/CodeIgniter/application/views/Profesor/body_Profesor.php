<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
<script type="text/javascript">
		$("document").ready(function(){
	
				$(".target").on('change',function(){
					
					//alert($(this).val())
					var Nota=$(this).val();
					var ID_Usuario=$(this).attr("id"); 
					var ID_Competencia=$(this).attr("name"); 

					  $.get('../anadir_nota',{N:Nota,ID_Usuario:ID_Usuario,ID_Competencia:ID_Competencia});
					  location.reload();
			
				
				});
			
		});
	</script>
<style>
	table, th, td {
    border: 1px solid black;

}

#user{
width: 100px;	
min-width: 100px;
}
#nota{
width: 100px;	
min-width: 100px;
}
#nota2{
width: 80px;	
min-width: 80px;
}
#th{
width: 100px;	
min-width: 100px;
}


input[type="number"] {
  width: 47px;
}

input + span {
  padding-right: 30px;
}

input:invalid+span:after {
  position: absolute;
  content: '✖';
  padding-left: 5px;
}

input:valid+span:after {
  position: absolute;
  content: '✓';
  padding-left: 5px;
}
</style>

<?
if (isset($Retos)) {
foreach ($Retos->result() as $Reto) {
?>	
<a href="Profesor/Notas/<?= $Reto->ID_Reto;?>"><?=$Reto->COD_Reto;?></a><br>
<?
}}
?>


<?
if (isset($NotasA)) {
//	$array[]="";
$Usuario = 0;
$kontotal= 0;
?>
<script type="text/javascript">
$("document").ready(function(source){
	
	 $("#inches").keyup(function () {
        var value = $(this).val();
        value=100-value;
  
       document.getElementById("inches2").setAttribute("max", value);
 
    });


	 $("#inches2").keyup(function () {
        var value1 = $(this).val();
        var value2 = $('#inches').val();
       
        value1=parseInt(value1)+parseInt(value2);
      
       	value1=100-value1;
       	if(value1>=0 && value1<=100 ){
        $("#inches3").val(value1);
    }else{
    	$("#inches3").val(0);
    }
    });
	 $("#button").click	(function () {

    var value1 = $("#inches").val();
    var value2 = $("#inches2").val();
 	var value3 = $("#inches3").val();
 	var array1 = [];
 	var array2 = [];
 	var array3 = [];
 
 	$("#miTabla tr").find('td:eq(10)').each(function () {
 
			 //obtenemos el codigo de la celda
			  codigo1 = $(this).html();
			  codigo1 = codigo1 * (value1/100);	
			  	  array1.push(codigo1);
            //alert(codigo);
	})
 	$("#miTabla tr").find('td:eq(12)').each(function () {
			codigo2 = $(this).html();
			codigo2 = codigo2 * (value2/100);	
			 array2.push(codigo2);		
           // alert(codigo2);
	})	
	$("#miTabla tr").find('td:eq(14)').each(function () {
			codigo3 = $(this).html();
			codigo3 = codigo3 * (value3/100);	
			 array3.push(codigo3);		
          //  alert(codigo3);
	})	
	
	for (var i = 0; i < array1.length; i++) {
		var total = array1[i]+array2[i]+array3[i];
		jQuery('a#'+i).html(total.toFixed(2));
	}
	//document.getElementById("Total").innerHTML = codigo;
    jQuery('a#Prof').html(value1);
    jQuery('a#Auto').html(value2);
    jQuery('a#Coe').html(value3);
    //jQuery('a#Total').html(value4);


    });
	
});
	
</script>








Porcentaje Profesor: <input id="inches" type="number" name="inches" min="0" max="100" step="1" value="0"><span class="validity"></span> 
Porcentaje Autoevaluación: <input id="inches2" type="number" name="inches" min="0" step="1" value="0"><span class="validity"></span> 
Porcentaje Coevaluación: <input id="inches3" type="number" name="inches" value="0" min="0" max="100" readonly>
<input type="button" id="button" value="Porcentaje">
<br><br>

<div style="overflow-x:auto;">
<table id="miTabla">
	<th id="user"></th>
<?
	foreach ($ob->result() as $os) {

		?><th id="th"><?=$os->DESC_Competencia;?></th><?
	}
?>
<th id="nota2">Nota Profesor</th>
<th id="nota2">Porcentaje Profesor</th>
<th id="nota2">Autoevaluación</th>
<th id="nota2">Porcentaje Autoevaluación</th>
<th id="nota2">Coevaluación</th>
<th id="nota2">Porcentaje Coevaluación</th>
<th id="nota2">Nota Final</th>

</table>
<?

$kont2= 0;
$kont= 0;
$va=0;
$Arr="";

$kont4=-1;
foreach ($NotasA->result() as $Nota) {
	
$selec="";$selec1="";$selec2="";$selec3="";
$kontotal++;	
if ($Usuario == $Nota->ID_Usuario) {
	$kont++;
	switch ($Nota->Nota) {
    case 2:
       	$selec="selected='selected'";
        break;
    case 5:
       	$selec1="selected='selected'";
        break;
    case 7:
        $selec2="selected='selected'";
        break;
    case 10:
        $selec3="selected='selected'";
        break;
}
	?>
	
		<td id="nota">
		<select class="target" id=<?=$Nota->ID_Usuario?> name=<?=$Nota->ID_Competencia?>>    
       		<option value="2" <?=$selec?>>Mal</option>
       		<option value="5" <?=$selec1?>>Regular</option>
       		<option value="7" <?=$selec2?>>Bien</option>
       		 <option value="10"<?=$selec3?>>Excelente</option>
  		 </select>
		</td>
		
		<?

		if ($Nota->Nota==10) {
			$Arr=  $Arr.'A';
		}else{
		$Arr=  $Arr.$Nota->Nota;
	}

		?>
	

	<?

	if ($kont== 9) {
		 $kont= 0;
		 $kompr2=0;
		 $Notatotal2=0;
		 $Notatotal3=0;
		 $Notatotal4=0;
		 $Notatotal5=0;
		 $arr1 = str_split($Arr);
	for ($i=0; $i < 9; $i++) { 
		if ($arr1[$i] == 'A') {
			$arr1[$i]='10';
		}
	}

	for ($i=0; $i < 9; $i++) { 
	foreach ($Porcentaje->result() as $Porcenta) {
					if ($i+1==$Porcenta->ID_Competencia) {
						$kompr2=$Porcenta->Porcentaje;
						

					}
				}
			if ( $kompr2 !=0) {
				
	
			$Notatotal = $arr1[$i]*($kompr2/100);

			$Notatotal2=  $Notatotal2+$Notatotal;
		}
	}
	$Kon = 0;
	foreach ($notas->result() as $No) {
		if ($Nota->ID_Usuario == $No->ID_Usuario and $Kon < 9 and $Nota->ID_Usuario == $No->ID_Evaluador) {

			foreach ($PorcentajeA->result() as $PorA) {
				if ($PorA->ID_Competencia == $No->ID_Competencia) {
					$Notatotal = $No->Nota*($PorA->Porcentaje/100);
						$Notatotal3=  $Notatotal3+$Notatotal;
				}
				
			}
			$Kon ++;
		}
		
	}
	foreach ($coe->result() as $co) {
		if ($co->ID_Usuario == $Nota->ID_Usuario and $co->ID_Evaluador != $Nota->ID_Usuario) {
				foreach ($PorcentajeA->result() as $Por) {
			if ($co->ID_Competencia == $Por->ID_Competencia){
				$Notatotal = $co->Nota*($Por->Porcentaje/100);
			$Notatotal4=  $Notatotal4+$Notatotal;
		}}
		}
	
	}
	$Notatotal4=$Notatotal4/2;
	?>


		<td id="nota2"><?=$Notatotal2;?></td>
		<td id="nota2"><a id="Prof"></a></td>
		<td id="nota2"><?=$Notatotal3;?></td>
		<td id="nota2"><a id="Auto"></a></td>
		<td id="nota2"><?=$Notatotal4;?></td>
		<td id="nota2"><a id="Coe"></a></td>
		<td id="nota2"><a id=<?= $kont4?>></a></td>
	<?
	//$array[$kont4]= array($Notatotal2, $Notatotal3, $Notatotal4);	
	//print_r($array);
		}
}else{
	switch ($Nota->Nota) {
    case 2:
       	$selec="selected='selected'";
        break;
    case 5:
       	$selec1="selected='selected'";
        break;
    case 7:
        $selec2="selected='selected'";
        break;
    case 10:
        $selec3="selected='selected'";
        break;
}
	
$kont4++;
	?><table id="miTabla">

	<td id="user"><? echo $Nota->User," ", $Nota->Apellidos;?></td>
	<td id="nota">
	<select  class="target" id=<?=$Nota->ID_Usuario?> name=<?=$Nota->ID_Competencia?>>    
       <option value="2" <?=$selec?>>Mal</option>
       <option value="5" <?=$selec1?>>Regular</option>
       <option value="7" <?=$selec2?>>Bien</option>
        <option value="10"<?=$selec3?>>Excelente</option>
   </select>
	</td>	

	<?
	
	if ($Nota->Nota==10) {
		$Arr=  'A';
	}else{
		$Arr= $Nota->Nota;
	}

	
	$kont++;
	$Usuario = $Nota->ID_Usuario;


}?><?}

?>

</table>
</div>
<?
//echo $array[0][0];
}
?>






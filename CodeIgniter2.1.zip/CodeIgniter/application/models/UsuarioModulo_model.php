<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class UsuarioModulo_model extends CI_Model{

	function __construct(){
		parent::__construct();
		$this->load->database();
	}

	public function nuevo_UsuarioModulo($datos){
		$datosBD = array(
			'ID_Usuario' => $this->input->post('ID_Usuario'),
			'ID_Modulo' => $this->input->post('ID_Modulo'),
		);
		$this->db->insert('Usuario_Modulo', $datosBD);
	}

	public function obtener_UsuarioModulos(){
	
		$query = $this->db->get('Usuario_Modulo');
		if ($query->num_rows() > 0){
			return $query;
		}else{
			return false;
		}
	}

	//Obtiene todo los UsuarioModulo, pero con los valores de las claves referenciadas
	public function obtener_UsuarioModulos_valores(){
		$query = "SELECT ID_Usuario_Modulo, User, Nombre, Apellidos, COD_Modulo, DESC_Modulo FROM Usuario_Modulo, Modulo, Usuario WHERE Usuario_Modulo.ID_Modulo=Modulo.ID_Modulo and Usuario_Modulo.ID_Usuario= Usuario.ID_Usuario";
		$query = $this->db->query($query);
		if ($query->num_rows() > 0){
			return $query;
		}else{
			return false;
		}
	}	

	public function obtener_UsuarioModulo($id){
		$where = $this->db->where('ID_Usuario_Modulo',$id);
		$query = $this->db->get('Usuario_Modulo');
		if ($query->num_rows() > 0){
			return $query;
		}else{
			return false;
		}
	}	

	//Obtiene UsuarioModulo por ID, pero con los valores de las claves referenciadas
	public function obtener_UsuarioModulo_valores($id){
		$query = "SELECT ID_Usuario_Modulo, User, Nombre, Apellidos, COD_Modulo, DESC_Modulo FROM Usuario_Modulo, Modulo, Usuario WHERE Usuario_Modulo.ID_Modulo=Modulo.ID_Modulo and Usuario_Modulo.ID_Usuario= Usuario.ID_Usuario and Usuario_Modulo.ID_Usuario_Modulo= ".$id;

		$query = $this->db->query($query);
		if ($query->num_rows() > 0){
			return $query;
		}else{
			return false;
		}
	}	

	public function actualizar_UsuarioModulo($id,$datos){
		$datosBD = array(
		'ID_Usuario' => $this->input->post('ID_Usuario'),
		'ID_Modulo' => $this->input->post('ID_Modulo'),
	
		);
		$this->db->where('ID_Usuario_Modulo',$id);
		$this->db->update('Usuario_Modulo', $datosBD);
	}	

		public function borrar_UsuarioModulo($box){
		include("conexion.php");
		if(!$con) {
	    	echo "No se pudo conectar a la base de datos";
	  	}	  
			$sql = "DELETE FROM Usuario_Modulo WHERE ID_Usuario_modulo= $box";
		$result = $con->query($sql);
	}

	public function filtrar_UsuarioModulo_valores($COD_Modulo,$User){
		include("conexion.php");
		if(!$con) {
	    	echo "No se pudo conectar a la base de datos";
	  	}

		if ($User == '' and $COD_Modulo != '') {
			$where = "and Modulo.COD_Modulo='$COD_Modulo'";
		}
		elseif($User != '' and $COD_Modulo == ''){
			$where = "and Usuario.User='$User'";
		}
		elseif($User == '' and $COD_Modulo == ''){
			$where = "";
		}
		else{
			$where = "and Modulo.COD_Modulo='$COD_Modulo' and Usuario.User='$User'";
		}

		$sql = "SELECT * FROM Usuario_Modulo, Modulo, Usuario WHERE Usuario_Modulo.ID_Modulo=Modulo.ID_Modulo and Usuario_Modulo.ID_Usuario= Usuario.ID_Usuario $where  ORDER BY Usuario_Modulo.ID_Usuario_Modulo ASC";

		$result = $con->query($sql);
		$rowdata=array();
		$i=0;
			while ($row = $result->fetch_array())
			{
				$rowdata[$i]=$row;
				$i++;			
			}
		echo json_encode($rowdata);

	}	

	
}


?>
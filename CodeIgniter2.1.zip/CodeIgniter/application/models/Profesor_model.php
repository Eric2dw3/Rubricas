<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Profesor_model extends CI_Model{

	function __construct(){
		parent::__construct();
		$this->load->database();
	}


	public function obtener_Retosprofesor($ID_Usuario){

		//$query = "SELECT Reto.ID_Reto ,COD_Reto FROM Usuario, Reto_Modulo, Reto WHERE Usuario.ID_Usuario=Reto_Modulo.ID_UAdmin and Reto_Modulo.ID_Reto=Reto.ID_Reto and ID_Usuario=$ID_Usuario";
		$query = "SELECT Reto.ID_Reto, COD_Reto FROM Usuario_Modulo, Reto_Modulo, Reto, Modulo WHERE Reto_Modulo.ID_Reto=Reto.ID_Reto and Modulo.ID_Modulo=Reto_Modulo.ID_Modulo and Modulo.ID_Modulo=Usuario_Modulo.ID_Modulo and Usuario_Modulo.ID_Usuario=$ID_Usuario";
		$query = $this->db->query($query);
		if ($query->num_rows() > 0){
			return $query;
		}else{
			return false;
		}

	}

	public function obtener_Notasalumnos($Reto){

		$query = "SELECT * FROM Notas, Usuario, Competencia WHERE ID_Reto=$Reto and Notas.ID_Usuario=Usuario.ID_Usuario and Notas.ID_Competencia=Competencia.ID_Competencia and Notas.ID_Evaluador IN 
       (SELECT ID_Evaluador FROM Notas, Usuario WHERE Notas.ID_Evaluador=Usuario.ID_Usuario and Usuario.ID_TUsuario=2)";
		$query = $this->db->query($query);
		if ($query->num_rows() > 0){
			return $query;
		}else{
			return false;
		}

	}
	public function obtener_Notasalumnos_coe($Reto){

		$query = "SELECT * FROM Notas, Usuario, Competencia WHERE ID_Reto=$Reto and Notas.ID_Usuario=Usuario.ID_Usuario and Notas.ID_Competencia=Competencia.ID_Competencia and Notas.ID_Evaluador IN 
       (SELECT ID_Evaluador FROM Notas, Usuario WHERE Notas.ID_Evaluador=Usuario.ID_Usuario and Usuario.ID_TUsuario=3)";
		$query = $this->db->query($query);
		if ($query->num_rows() > 0){
			return $query;
		}else{
			return false;
		}

	}

	public function obtener_Porcentaje(){

		$query = "SELECT * FROM Medicion_GupoCompetencia_Competencia WHERE ID_Medicion=3 ORDER BY Medicion_GupoCompetencia_Competencia.ID_Competencia ASC";
		$query = $this->db->query($query);
		if ($query->num_rows() > 0){
			return $query;
		}else{
			return false;
		}

	}
		public function obtener_ob(){

		$query = "SELECT DESC_Competencia FROM Competencia ";
		$query = $this->db->query($query);
		if ($query->num_rows() > 0){
			return $query;
		}else{
			return false;
		}

	}
	public function anadir_profesor_notas($Nota,$ID_UsuarioA,$ID_Competencia){

		$query = "UPDATE Notas SET Nota=$Nota WHERE ID_Usuario=$ID_UsuarioA and ID_Competencia=$ID_Competencia and ID_Evaluador=13";
		$query = $this->db->query($query);
		
	}
	public function obtener_notas(){

		$query = "SELECT * FROM Notas";
		$query = $this->db->query($query);
		if ($query->num_rows() > 0){
			return $query;
		}else{
			return false;
		}

	}

	public function obtener_Coevaluacion($ID_Usuario){

		$query = "SELECT * FROM Notas, Usuario, Competencia, Medicion_GupoCompetencia_Competencia WHERE ID_Reto=2 and Notas.ID_Usuario=Usuario.ID_Usuario and Notas.ID_Competencia=Competencia.ID_Competencia and Notas.ID_Evaluador IN (SELECT ID_Evaluador FROM Notas, Usuario WHERE Notas.ID_Evaluador=Usuario.ID_Usuario and Usuario.ID_TUsuario=3) and Notas.ID_Usuario=$ID_Usuario and Notas.ID_Evaluador != $ID_Usuario and Medicion_GupoCompetencia_Competencia.ID_Competencia=Competencia.ID_Competencia";
		$query = $this->db->query($query);
		if ($query->num_rows() > 0){
			return $query;
		}else{
			return false;
		}

	}
}


?>
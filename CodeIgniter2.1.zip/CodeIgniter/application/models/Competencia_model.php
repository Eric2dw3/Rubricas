<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Competencia_model extends CI_Model{

	function __construct(){
		parent::__construct();
		$this->load->database();
	}


	public function obtener_Competencias(){
		$query = $this->db->get('Competencia');
		if ($query->num_rows() > 0){
			return $query;
		}else{
			return false;
		}
	}	
	public function obtener_Competencia2(){
		include ("conexion.php");


		if(!$con) {
	  		echo "No se pudo conectar a la base de datos";
	  	}

		$sql = "SELECT * FROM Competencia";
		$result = $con->query($sql);

		$rowdata=array();
		$i=0;
		while ($row = $result->fetch_array())
		{	
			$rowdata[$i]=$row;
			$i++;			
		}
	
		echo json_encode($rowdata, JSON_UNESCAPED_UNICODE);
	}		
	
}


?>
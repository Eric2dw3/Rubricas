<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Reto_model extends CI_Model{

	function __construct(){
		parent::__construct();
		$this->load->database();
	}

	public function nuevo_Reto($datos){
		$datosBD = array(
			'COD_Reto' => $datos['COD_Reto'],
			'DESC_Reto' => $datos['DESC_Reto'],
		);
		$this->db->insert('Reto', $datosBD);
	}

	public function obtener_Retos(){
		$query = $this->db->get('Reto');
		if ($query->num_rows() > 0){
			return $query;
		}else{
			return false;
		}
	}

	public function obtener_Reto($id){
		$where = $this->db->where('ID_Reto',$id);
		$query = $this->db->get('Reto');
		if ($query->num_rows() > 0){
			return $query;
		}else{
			return false;
		}
	}	

	public function actualizar_Reto($id,$datos){
		$datosBD = array(
			'COD_Reto' => $datos['COD_Reto'],
			'DESC_Reto' => $datos['DESC_Reto'],
		);
		$this->db->where('ID_Reto',$id);
		$this->db->update('Reto', $datosBD);
	}	

		public function borrar_Reto($id){
		$this->db->where('ID_Reto',$id);
		$this->db->delete('Reto');
	}	
	public function obtener_Reto2(){
		include ("conexion.php");

		if(!$con) {
	  		echo "No se pudo conectar a la base de datos";
	  	}

		$sql = "SELECT DISTINCT COD_Reto FROM Reto";
		$result = $con->query($sql);

		$rowdata=array();
		$i=0;
		while ($row = $result->fetch_array())
		{	
			$rowdata[$i]=$row;
			$i++;			
		}
		echo json_encode($rowdata);
	}	
	public function obtener_Reto3(){
		include ("conexion.php");

		if(!$con) {
	  		echo "No se pudo conectar a la base de datos";
	  	}

		$sql = "SELECT * FROM Reto";
		$result = $con->query($sql);

		$rowdata=array();
		$i=0;
		while ($row = $result->fetch_array())
		{	
			$rowdata[$i]=$row;
			$i++;			
		}
		echo json_encode($rowdata);
	}	
}



?>
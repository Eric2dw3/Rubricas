<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class RetoModulo_model extends CI_Model{

	function __construct(){
		parent::__construct();
		$this->load->database();
	}

	public function nuevo_RetoModulo($datos){
		$datosBD = array(
			//'ID_Reto' => $this->input->post('ID_Reto'),
			//'ID_Modulo' => $this->input->post('ID_Modulo'),
		'ID_Reto' => $datos['ID_Reto'],
		'ID_Modulo' => $datos['ID_Modulo'],
		'ID_UAdmin' => $datos['ID_UAdmin'],
		//'ID_UAdmin' => $this->input->post('ID_UAdmin'),
		'IN_Extendido' => $this->input->post('IN_Extendido'),
		'IN_EAbierta' => $this->input->post('IN_EAbierta'),
		);
		$this->db->insert('Reto_Modulo', $datosBD);
	}

	public function obtener_RetoModulos(){

		$query = $this->db->get('Reto_Modulo');
		if ($query->num_rows() > 0){
			return $query;
		}else{
			return false;
		}
	}


	//Obtiene todo los RetoModulo, pero con los valores de las claves referenciadas
	public function obtener_RetoModulos_valores(){
		$query = "SELECT ID_Reto_modulo, ID_UAdmin, IN_Extendido, IN_EAbierta, DESC_Reto, COD_Reto, COD_Modulo, DESC_Modulo FROM Reto_Modulo, Modulo, Reto WHERE Reto_Modulo.ID_Modulo=Modulo.ID_Modulo and Reto_Modulo.ID_Reto= Reto.ID_Reto";
		$query = $this->db->query($query);
		if ($query->num_rows() > 0){
			return $query;
		}else{
			return false;
		}
	}	

	public function obtener_RetoModulo($id){
		$where = $this->db->where('ID_Reto_modulo',$id);
		$query = $this->db->get('Reto_Modulo');
		if ($query->num_rows() > 0){
			return $query;
		}else{
			return false;
		}
	}	

	//Obtiene RetoModulo por ID, pero con los valores de las claves referenciadas
	public function obtener_RetoModulo_valores($id){
		$query = "SELECT ID_Reto_modulo, ID_UAdmin, IN_Extendido, IN_EAbierta, DESC_Reto, COD_Reto, COD_Modulo, DESC_Modulo FROM Reto_Modulo, Modulo, Reto WHERE Reto_Modulo.ID_Modulo=Modulo.ID_Modulo and Reto_Modulo.ID_Reto= Reto.ID_Reto and Reto_Modulo.ID_Reto_modulo= ".$id;

		$query = $this->db->query($query);
		if ($query->num_rows() > 0){
			return $query;
		}else{
			return false;
		}
	}	

	public function actualizar_RetoModulo($id,$datos){
		$datosBD = array(
		//'ID_Reto' => $this->input->post('ID_Reto'),
		//'ID_Modulo' => $this->input->post('ID_Modulo'),
		'ID_Reto' => $datos['ID_Reto'],
		'ID_Modulo' => $datos['ID_Modulo'],
		'ID_UAdmin' => $datos['ID_UAdmin'],
		//'ID_UAdmin' => $this->input->post('ID_UAdmin'),
		'IN_Extendido' => $this->input->post('IN_Extendido'),
		'IN_EAbierta' => $this->input->post('IN_EAbierta'),
	
		);
		$this->db->where('ID_Reto_modulo',$id);
		$this->db->update('Reto_Modulo', $datosBD);
	}	

		public function borrar_RetoModulo($box){
		include("conexion.php");
		if(!$con) {
	    	echo "No se pudo conectar a la base de datos";
	  	}  
			$sql = "DELETE FROM Reto_Modulo WHERE ID_Reto_modulo= $box";
		$result = $con->query($sql);
	}


	public function filtrar_RetoModulo_valores($COD_Reto,$COD_Modulo){
		include("conexion.php");
		if(!$con) {
	    	echo "No se pudo conectar a la base de datos";
	  	}

		if ($COD_Modulo == '' and $COD_Reto != '') {
			$where = "and Reto.COD_Reto='$COD_Reto'";
		}
		elseif($COD_Modulo != '' and $COD_Reto == ''){
			$where = "and Modulo.COD_Modulo='$COD_Modulo'";
		}
		elseif($COD_Modulo == '' and $COD_Reto == ''){
			$where = "";
		}
		else{
			$where = "and Reto.COD_Reto='$COD_Reto' and Modulo.COD_Modulo='$COD_Modulo'";
		}

		$sql = "SELECT ID_Reto_modulo, ID_UAdmin, IN_Extendido, IN_EAbierta, DESC_Reto, COD_Reto, COD_Modulo, DESC_Modulo FROM Reto_Modulo, Modulo, Reto WHERE Reto_Modulo.ID_Modulo=Modulo.ID_Modulo and Reto_Modulo.ID_Reto= Reto.ID_Reto $where";

		$result = $con->query($sql);
		$rowdata=array();
		$i=0;
			while ($row = $result->fetch_array())
			{
				$rowdata[$i]=$row;
				$i++;			
			}
		echo json_encode($rowdata);

	}	

	
}


?>
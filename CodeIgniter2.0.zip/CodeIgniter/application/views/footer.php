<script type="text/javascript" src="<?php echo base_url();?>js/javascript.js" ></script>
<footer>
</footer>
	<div class="footer">
		&copy;Copyright FP Txurdinaga.
	</div>
</body>
</html>
<?php
$form = array(
	'name' => 'form_equipousuario'
	);
$url = "'".base_url()."index.php/EquipoUsuario'";
$js_cancel_button = 'onClick="location.href='.$url.'"';
$COD_Rol = array(	
	'name' => 'COD_Rol',
	'value' =>  $EquipoUsuarios->result()[0]->COD_Rol,
	'placeholder' => 'COD_Rol',
	'maxlength' => 100,
	'size' => 30,
	'required' => 1
	);

	if ($Equipos){
		$ID_Equipo = array();
		foreach ($Equipos->result() as $Equipo) {
			$ID_Equipo[$Equipo->ID_Equipo] = $Equipo->DESC_Equipo;
		}	
	}
	else{
		$ID_Equipo = array(
    		0         => 'No hay Equipos'
		);
	}

	if ($Usuarios){
		$ID_Usuario = array();
		foreach ($Usuarios->result() as $Usuario) {
			$ID_Usuario[$Usuario->ID_Usuario] = $Usuario->User;
		}	
	}
	else{
		$ID_Usuario = array(
    		0         => 'No hay Usuarios'
		);
	}	

?>

<div>
	<?php echo form_open('EquipoUsuario/actualizar/'.$EquipoUsuarios->result()[0]->ID_Equipo_Usuario);?>
	<?php echo form_label('Equipo: ','ID_Equipo'); ?>
	<?php
	//DESPLEGABLE DE CENTRO
	echo form_dropdown('ID_Equipo', $ID_Equipo, $EquipoUsuarios->result()[0]->ID_Equipo);
	?>
	<br>

	<?php echo form_label('Usuario: ','ID_Usuario'); ?>
	<?php
	//DESPLEGABLE DE CURSOS
	echo form_dropdown('ID_Usuario', $ID_Usuario, $EquipoUsuarios->result()[0]->ID_Usuario);
	?>
	<br>
	<?php echo form_label('COD_Rol: ','COD_Rol'); ?>
	<?php echo form_input($COD_Rol); ?>
	<br>
	<?php echo form_submit('Actualizar','Actualizar'); ?>
	<?php echo form_button('Cancelar','Cancelar',$js_cancel_button); ?>	
	<?php echo form_close();?>
</div>
<div>

<b class="borde">Gestión de EquipoUsuario</b><br><br>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
	
	
	
	<script type="text/javascript">
function gurdar(id){
			  alert(id); 


 //$.get('EquipoUsuario/borrar',{ID:id}); 
		}
		$("document").ready(function(source){

$('#select-all').click(function(event) {   
 if(this.checked) {
        // Iterate each checkbox
        $(':checkbox').each(function() {
            this.checked = true;                        
        });
  }
  else {
    $(':checkbox').each(function() {
          this.checked = false;
      });
  }

});

		

			$(document).on('change','input[type="checkbox"]' ,function(e) {
    if(this.id=="select-all") {
        if(this.checked) $('#id_fiscal').val(this.value);
        else $('#id_fiscal').val("");
    }
});

				function mostrartabla() {

					var cod1 = document.getElementById('Equipos').value;
					var cod2 = document.getElementById('Usuarios').value;
					
  $.get('EquipoUsuario/filtrar_EquipoUsuario',{COD_Equipo:cod1,User:cod2},function(datos){
		
							datos2=JSON.parse(datos);
							document.getElementById("sacardatos").innerHTML="";
							$("#sacardatos").append(
								"<tr><td></td><td><strong>ID_Equipo_Usuario</strong></td><td><strong>DESC_Equipo</strong></td><td><strong>COD_Equipo</strong></td><td><strong>COD_Rol</strong></td><td><strong>User</strong></td><td><strong>Nombre</strong></td><td><strong>Apellidos</strong></td></tr>"
						)
						$.each(datos2,function(indice,valor){
						
		
							$("#sacardatos").append(

									
  "<tr><td><input type='checkbox' name='checkbox[]' id='"+valor.ID_Equipo_Usuario+"'onClick='gurdar(this.id)'></td><td><a href=EquipoUsuario/editar/"+valor.ID_Equipo_Usuario+">"+valor.ID_Equipo_Usuario+"</a></td><td><a href=EquipoUsuario/editar/"+valor.ID_Equipo_Usuario+">"+valor.DESC_Equipo+"</a></td><td><a href=EquipoUsuario/editar/"+valor.ID_Equipo_Usuario+">"+valor.COD_Equipo+"</a></td><td><a href=EquipoUsuario/editar/"+valor.ID_Equipo_Usuario+">"+valor.COD_Rol+"</a></td><td><a href=EquipoUsuario/editar/"+valor.ID_Equipo_Usuario+">"+valor.User+"</a></td><td><a href=EquipoUsuario/editar/"+valor.ID_Equipo_Usuario+">"+valor.Nombre+"</a></td><td><a href=EquipoUsuario/editar/"+valor.ID_Equipo_Usuario+">"+valor.Apellidos+"</a></td>"



								)
						});
					});
}

					$.get('EquipoUsuario/Equipo', function(datos){
				
					datos2=JSON.parse(datos);
				
					$.each(datos2,function(indice,valor){
						$("#Equipos").append('<option value="'+valor.COD_Equipo +'">'+valor.COD_Equipo	+'</option>')
					});
		
				});

				$.get('EquipoUsuario/Usuario', function(datos){
				
					datos2=JSON.parse(datos);

					$.each(datos2,function(indice,valor){
						$("#Usuarios").append('<option value="'+valor.User +'">'+valor.User	+'</option>')
					});
		
				});
	
		
					$("#boton").click(function(){
					
					mostrartabla();
					});
					
					mostrartabla();

	});

	</script>
	<td>
	<label>Equipos: </label>
	<select id="Equipos">
	<option value="">Todos los Equipos</option>
		option	
	</select>
	<label>Usuarios: </label>
	<select id="Usuarios">
		<option value="">Todos los Tipos de Usuarios</option>
		option
	</select>
	<button id="boton" >Mostrar</button>
	<hr>
	<input type='checkbox' name='select-all' id='select-all' value="hola">
	<table id='sacardatos'>
	</table>
	<input id="boton" type="submit" name="BtnEliminar" value="Eliminar"/>

	<br>

	<hr>
	  <input type="text" name="id_fiscal" class="form-control" id="id_fiscal">
	<br><br>


</div>
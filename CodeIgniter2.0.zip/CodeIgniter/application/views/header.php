<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<link href="login.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" type="text/css" href="<? echo base_url();?>css/login.css">

<div id="header">
	<ul class="nav">
		<li><a href="Centro">Centro</a></li>
		<li><a href="Ciclo">Ciclo</a></li>
		<li><a href="Curso">Curso</a></li>
		<li><a href="Equipo">Equipo</a>
			<ul>
				<li><a href="EquipoUsuario">EquipoUsuario</a></li>
			</ul>
		</li>
		<li><a href="Reto">Reto</a></li>
		<li><a href="Usuario">Usuarios</a>
			<ul>
				<li><a href="TUsuario">TUsuarios</a></li>
				<li><a href="UsuarioModulo">UsuarioModulo</a></li>
			</ul>
		</li>
		<li><a href="Medicion">Medición</a>
			<ul>
				<li><a href="Medicion_GupoCompetencia_Competencia">Medicion_GupoCompetencia_Competencias</a></li>
			</ul>
		</li>
		<li><a href="Competencia">Comp.</a>
			<ul>
				<li><a href="GrupoCompetencia">GrupoCompetencia</a></li>
			</ul>
		</li>
		<li><a href="login" class="animacion">Logout</a></li>
	</ul><br><br>
</div>

</head>

<body>
<header>
    <title>Rúbricas</title>
</header>

<div>

	
<b class="borde">Gestión de RETOS</b><br><br>


<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
	
	
	
	<script type="text/javascript">
function gurdar(id){
			  alert(id); 


 //$.get('Modulo/borrar',{ID:id}); 
		}
		$("document").ready(function(source){

$('#select-all').click(function(event) {   
 if(this.checked) {
        // Iterate each checkbox
        $(':checkbox').each(function() {
            this.checked = true;                        
        });
  }
  else {
    $(':checkbox').each(function() {
          this.checked = false;
      });
  }

});

		

			$(document).on('change','input[type="checkbox"]' ,function(e) {
    if(this.id=="select-all") {
        if(this.checked) $('#id_fiscal').val(this.value);
        else $('#id_fiscal').val("");
    }
});

				function mostrartabla() {

					var cod1 = document.getElementById('Ciclo').value;
					var cod2 = document.getElementById('Modulo').value;
					
  $.get('Modulo/filtrar_Modulo',{COD_Ciclo:cod1,COD_Modulo:cod2},function(datos){
		
							datos2=JSON.parse(datos);
							document.getElementById("sacardatos").innerHTML="";
							$("#sacardatos").append(
								"<tr><td></td><td><strong>ID_Modulo</strong></td><td><strong>COD_Modulo</strong></td><td><strong>DESC_Modulo</strong></td><td><strong>COD_Ciclo</strong></td><td><strong>DESC_Ciclo</strong></td></tr>"
						)
						$.each(datos2,function(indice,valor){
						
		
							$("#sacardatos").append(

									
  "<tr><td><input type='checkbox' name='checkbox[]' id='"+valor.ID_Modulo+"'onClick='gurdar(this.id)'></td><td><a href=Modulo/editar/"+valor.ID_Modulo+">"+valor.ID_Modulo+"</a></td><td><a href=Modulo/editar/"+valor.ID_Modulo+">"+valor.COD_Modulo+"</a></td><td><a href=Modulo/editar/"+valor.ID_Modulo+">"+valor.DESC_Modulo+"</a></td><td><a href=Modulo/editar/"+valor.ID_Modulo+">"+valor.COD_Ciclo+"</a></td><td><a href=Modulo/editar/"+valor.ID_Modulo+">"+valor.DESC_Ciclo+"</a></td>"



								)
						});
					});
}

					$.get('Modulo/Ciclos', function(datos){
				
					datos2=JSON.parse(datos);
				
					$.each(datos2,function(indice,valor){
						$("#Ciclo").append('<option value="'+valor.COD_Ciclo +'">'+valor.COD_Ciclo	+'</option>')
					});
		
				});

				$.get('Modulo/Modulos', function(datos){
				
					datos2=JSON.parse(datos);

					$.each(datos2,function(indice,valor){
						$("#Modulo").append('<option value="'+valor.COD_Modulo +'">'+valor.COD_Modulo	+'</option>')
					});
		
				});
	
		
					$("#boton").click(function(){
					
					mostrartabla();
					});
					
					mostrartabla();

	});

	</script>
	<td>
	<label>Ciclo: </label>
	<select id="Ciclo">
	<option value="">Todos los Ciclo</option>
		option	
	</select>
	<label>Modulo: </label>
	<select id="Modulo">
		<option value="">Todos los Tipos de Modulo</option>
		option
	</select>
	<button id="boton" >Mostrar</button>
	<hr>
	<input type='checkbox' name='select-all' id='select-all' value="hola">
	<table id='sacardatos'>
	</table>
	<input id="boton" type="submit" name="BtnEliminar" value="Eliminar"/>

	<br>

	<hr>
	  <input type="text" name="id_fiscal" class="form-control" id="id_fiscal">
	<br><br>


</div>
<?php
$form = array(
	'name' => 'form_Usuario'
	);
$url = "'".base_url()."index.php/Usuario'";
$js_cancel_button = 'onClick="location.href='.$url.'"';

$User = array(
	'name' => 'User',
	'value' => $Usuarios->result()[0]->User,
	'placeholder' => 'User',
	'maxlength' => 10,
	'size' => 20,
	'required' => 1
	);
$Password = array(	
	'name' => 'Password',
	'value' => $Usuarios->result()[0]->Password,
	'placeholder' => 'Password',
	'maxlength' => 100,
	'size' => 30,
	'required' => 1
	);

$Nombre = array(
	'name' => 'Nombre',
	'value' => $Usuarios->result()[0]->Nombre,
	'placeholder' => 'Nombre',
	'maxlength' => 10,
	'size' => 20,
	'required' => 1
	);
$Apellidos = array(	
	'name' => 'Apellidos',
	'value' => $Usuarios->result()[0]->Apellidos,
	'placeholder' => 'Apellidos',
	'maxlength' => 100,
	'size' => 30,
	'required' => 1	
	);
$Email = array(
	'name' => 'Email',
	'value' => $Usuarios->result()[0]->Email,
	'placeholder' => 'Email',
	'maxlength' => 50,
	'size' => 50,
	'required' => 1	
	);
$Dni = array(	
	'name' => 'Dni',
	'value' => $Usuarios->result()[0]->Dni,
	'placeholder' => 'Dni',
	'maxlength' => 100,
	'size' => 30,
	'required' => 1
	);


	if ($Centros){
		$ID_Centro = array();
		foreach ($Centros->result() as $Centro) {
			$ID_Centro[$Centro->ID_Centro] = $Centro->DESC_Centro;
		}	
	}
	else{
		$ID_Centro = array(
    		0         => 'No hay Centros'
		);
	}

	if ($TUsuarios){
		$ID_TUsuarioo = array();
		foreach ($TUsuarios->result() as $TUsuario) {
			$ID_TUsuario[$TUsuario->ID_TUsuario] = $TUsuario->DESC_TUsuario;
		}	
	}
	else{
		$ID_TUsuario = array(
    		0         => 'No hay TUsuarios'
		);
	}	

?>

<div>
	<?php echo form_open('Usuario/actualizar/'.$Usuarios->result()[0]->ID_Usuario);?>
	<?php echo form_label('Centro: ','ID_Centro'); ?>
	<?php
	//DESPLEGABLE DE Centro
	echo form_dropdown('ID_Centro', $ID_Centro, $Usuarios->result()[0]->ID_Centro);
	?>
	<br>

	<?php echo form_label('TUsuario: ','ID_TUsuario'); ?>
	<?php
	//DESPLEGABLE DE TUsuarioS
	echo form_dropdown('ID_TUsuario', $ID_TUsuario, $Usuarios->result()[0]->ID_TUsuario);
	?>
	<br>

	<?php echo form_label('User: ','User'); ?>
	<?php echo form_input($User); ?>
	<br>
	<?php echo form_label('Password','Password'); ?>
	<?php echo form_input($Password); ?>
	<br>
	<?php echo form_label('Nombre: ','Nombre'); ?>
	<?php echo form_input($Nombre); ?>
	<br>
	<?php echo form_label('Apellidos','Apellidos'); ?>
	<?php echo form_input($Apellidos); ?>
	<br>
	<?php echo form_label('Email: ','Email'); ?>
	<?php echo form_input($Email); ?>
	<br>
	<?php echo form_label('Dni','Dni'); ?>
	<?php echo form_input($Dni); ?>
	<br>		
	<?php echo form_submit('Actualizar','Actualizar'); ?>
	<?php echo form_button('Cancelar','Cancelar',$js_cancel_button); ?>	
	<?php echo form_close();?>
</div>
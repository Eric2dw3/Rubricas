<div>

<b class="borde">Gestión de USUARIOS</b><br><br>
		
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
	
	
	<script type="text/javascript">
function gurdar(id){
			  alert(id); 


 //$.get('Usuario/borrar',{ID:id}); 
		}
		$("document").ready(function(source){

$('#select-all').click(function(event) {   
 if(this.checked) {
        // Iterate each checkbox
        $(':checkbox').each(function() {
            this.checked = true;                        
        });
  }
  else {
    $(':checkbox').each(function() {
          this.checked = false;
      });
  }

});

		

			$(document).on('change','input[type="checkbox"]' ,function(e) {
    if(this.id=="select-all") {
        if(this.checked) $('#id_fiscal').val(this.value);
        else $('#id_fiscal').val("");
    }
});

				function mostrartabla() {

					var cod1 = document.getElementById('Centros').value;
					var cod2 = document.getElementById('TUsuario').value;

  $.get('Usuario/filtrar_Usuario',{DESC_Centro:cod1,DESC_TUsuario:cod2},function(datos){
		
							datos2=JSON.parse(datos);
							document.getElementById("sacardatos").innerHTML="";
							$("#sacardatos").append(
								"<tr><td></td><td><strong>ID_Usuario</strong></td><td><strong>DESC_TUsuario</strong></td><td><strong>COD_Centro</strong></td><td><strong>DESC_Centro</strong></td><td><strong>User</strong></td><td><strong>Password</strong></td><td><strong>Nombre</strong></td><td><strong>Apellidos</strong></td><td><strong>Email</strong></td><td><strong>DNI</strong></td> </tr>"
						)
						$.each(datos2,function(indice,valor){
						
		
							$("#sacardatos").append(

									
  "<tr><td><input type='checkbox' name='checkbox[]' id='"+valor.ID_Usuario+"'onClick='gurdar(this.id)'></td><td><a href=Usuario/editar/"+valor.ID_Usuario+">"+valor.ID_Usuario+"</a></td><td><a href=Usuario/editar/"+valor.ID_Usuario+">"+valor.DESC_TUsuario+"</a></td><td><a href=Usuario/editar/"+valor.ID_Usuario+">"+valor.COD_Centro+"</a></td><td><a href=Usuario/editar/"+valor.ID_Usuario+">"+valor.DESC_Centro+"</a></td><td><a href=Usuario/editar/"+valor.ID_Usuario+">"+valor.User+"</a></td><td><a href=Usuario/editar/"+valor.ID_Usuario+">"+valor.Password+"</a></td><td><a href=Usuario/editar/"+valor.ID_Usuario+">"+valor.Nombre+"</a></td><td><a href=Usuario/editar/"+valor.ID_Usuario+">"+valor.Apellidos+"</a></td><td><a href=Usuario/editar/"+valor.ID_Usuario+">"+valor.Email+"</a></td><td><a href=Usuario/editar/"+valor.ID_Usuario+">"+valor.Dni+"</a></td>"



								)
						});
					});
}


				$.get('Usuario/TUsuario', function(datos){
				
					datos2=JSON.parse(datos);

					$.each(datos2,function(indice,valor){
						$("#TUsuario").append('<option value="'+valor.DESC_TUsuario +'">'+valor.DESC_TUsuario	+'</option>')
					});
		
				});


					$.get('Usuario/Centros', function(datos){
				
					datos2=JSON.parse(datos);
				
					$.each(datos2,function(indice,valor){
						$("#Centros").append('<option value="'+valor.DESC_Centro +'">'+valor.DESC_Centro	+'</option>')
					});
		
				});
		
					$("#boton").click(function(){
					
					mostrartabla();
					});
					
					mostrartabla();

	});

	</script>
	<td>
	<label>Centros: </label>
	<select id="Centros">
	<option value="">Todos los Centros</option>	
	</select>
	<label>TUsuario: </label>
	<select id="TUsuario">
		<option value="">Todos los Tipos de usuario</option>
	</select>
	<button id="boton" >Mostrar</button>
	<hr>
	<input type='checkbox' name='select-all' id='select-all' value="hola">
	<table id='sacardatos'>
	</table>
	<input type="submit" name="BtnEliminar" value="Eliminar" id="boton"/>

	<br>

	<hr>
	  <input type="text" name="id_fiscal" class="form-control" id="id_fiscal">
	<br><br><br><br><br><br>
</div>
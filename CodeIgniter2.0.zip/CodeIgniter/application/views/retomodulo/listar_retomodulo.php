<div>

	<style type="text/css" media="screen">
		 td{
		 	 padding:10px 20px 0 20px;
		 }
	#select-all{
		position: absolute;
		margin-top: 0.8%;
		margin-left: 1.4%;
	}
	</style>
<?php
		printf('Gestión de RetoModulos<br>');
		printf('--------------------------------------------------------------------<br>');
		
		?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
	
	
	
	<script type="text/javascript">
function gurdar(id){
			  alert(id); 


 //$.get('RetoModulo/borrar',{ID:id}); 
		}
		$("document").ready(function(source){

$('#select-all').click(function(event) {   
 if(this.checked) {
        // Iterate each checkbox
        $(':checkbox').each(function() {
            this.checked = true;                        
        });
  }
  else {
    $(':checkbox').each(function() {
          this.checked = false;
      });
  }

});

		

			$(document).on('change','input[type="checkbox"]' ,function(e) {
    if(this.id=="select-all") {
        if(this.checked) $('#id_fiscal').val(this.value);
        else $('#id_fiscal').val("");
    }
});

				function mostrartabla() {

					var cod1 = document.getElementById('Retos').value;
					var cod2 = document.getElementById('Modulo').value;
			
					
  $.get('RetoModulo/filtrar_RetoModulo',{COD_Reto:cod1,COD_Modulo:cod2,},function(datos){
		
							datos2=JSON.parse(datos);
							document.getElementById("sacardatos").innerHTML="";
							$("#sacardatos").append(
								"<tr><td></td><td><strong>ID_Reto_modulo</strong></td><td><strong>ID_UAdmin</strong></td><td><strong>IN_Extendido</strong></td><td><strong>IN_EAbierta</strong></td><td><strong>DESC_Reto</strong></td><td><strong>COD_Reto</strong></td><td><strong>COD_Modulo</strong></td><td><strong>DESC_Modulo</strong></td></tr>"
						)
						$.each(datos2,function(indice,valor){
						
		
							$("#sacardatos").append(

									
  "<tr><td><input type='checkbox' name='checkbox[]' id='"+valor.ID_Reto_modulo+"'onClick='gurdar(this.id)'></td><td><a href=RetoModulo/editar/"+valor.ID_Reto_modulo+">"+valor.ID_Reto_modulo+"</a></td><td><a href=RetoModulo/editar/"+valor.ID_Reto_modulo+">"+valor.ID_UAdmin+"</a></td><td><a href=RetoModulo/editar/"+valor.ID_Reto_modulo+">"+valor.IN_Extendido+"</a></td><td><a href=RetoModulo/editar/"+valor.ID_Reto_modulo+">"+valor.IN_EAbierta+"</a></td><td><a href=RetoModulo/editar/"+valor.ID_Reto_modulo+">"+valor.DESC_Reto+"</a></td><td><a href=RetoModulo/editar/"+valor.ID_Reto_modulo+">"+valor.COD_Reto+"</a></td><td><a href=RetoModulo/editar/"+valor.ID_Reto_modulo+">"+valor.DESC_Modulo+"</a></td><td><a href=RetoModulo/editar/"+valor.ID_Reto_modulo+">"+valor.COD_Modulo+"</a></td>"



								)
						});
					});
}

					$.get('RetoModulo/Retos', function(datos){
				
					datos2=JSON.parse(datos);
				
					$.each(datos2,function(indice,valor){
						$("#Retos").append('<option value="'+valor.COD_Reto +'">'+valor.COD_Reto +'</option>')
					});
		
				});

				$.get('RetoModulo/Modulo', function(datos){
				
					datos2=JSON.parse(datos);

					$.each(datos2,function(indice,valor){
						$("#Modulo").append('<option value="'+valor.COD_Modulo +'">'+valor.COD_Modulo+'</option>')
					});
		
				});
				
	
		
					$("#boton").click(function(){
					
					mostrartabla();
					});
					
					mostrartabla();

	});

	</script>
	<td>
	<label>Retos: </label>
	<select id="Retos">
	<option value="">Todos los Retos</option>
		</select>
	<label>Modulo: </label>
	<select id="Modulo">
		<option value="">Todos los Tipos de Modulo</option>
	
	</select>
	<button id="boton" >Mostrar</button>
	<hr>
	<input type='checkbox' name='select-all' id='select-all' value="hola">
	<table id='sacardatos'>
	</table>
	<input type="submit" name="BtnEliminar" value="Eliminar"/>

	<br>

	<hr>
	  <input type="text" name="id_fiscal" class="form-control" id="id_fiscal">
	<br><br>


</div>
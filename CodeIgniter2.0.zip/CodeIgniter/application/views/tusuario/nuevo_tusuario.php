<?php
$form = array(
	'name' => 'form_TUsuario'
	);
$DESC_TUsuario = array(
	'name' => 'DESC_TUsuario',
	'placeholder' => 'Descripción de tu usuario',
	'maxlength' => 10,
	'size' => 20
	);
?>


<button class="accordion">Crear Tipo de Usuario</button>



	<div class="panel">
	<?php echo form_open('TUsuario/nuevo_TUsuario',$form);?>
	<?php echo form_label('Descripción de tu usuario: ','DESC_TUsuario'); ?>
	<?php echo form_input($DESC_TUsuario); ?>
	<br>
	<?php echo form_submit('Crear','Crear'); ?>
	<?php echo form_close();?>
</div>
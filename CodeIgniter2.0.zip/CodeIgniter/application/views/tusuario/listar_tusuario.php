<div>
	
<b class="borde">Gestión de Tipo Usuarios</b><br>

	
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
	
	
	
	<script type="text/javascript">
function gurdar(id){
			  alert(id); 


 //$.get('TUsuario/borrar',{ID:id}); 
		}
		$("document").ready(function(source){

$('#select-all').click(function(event) {   
 if(this.checked) {
        // Iterate each checkbox
        $(':checkbox').each(function() {
            this.checked = true;                        
        });
  }
  else {
    $(':checkbox').each(function() {
          this.checked = false;
      });
  }

});

		
			$(document).on('change','input[type="checkbox"]' ,function(e) {
    if(this.id=="select-all") {
        if(this.checked) $('#id_fiscal').val(this.value);
        else $('#id_fiscal').val("");
    }
});

				function mostrartabla() {

					//var cod1 = document.getElementById('TUsuarios').value;
					//var cod2 = document.getElementById('TTUsuario').value;

  $.get('TUsuario/filtrar_TUsuario', function(datos){
		
							datos2=JSON.parse(datos);
							document.getElementById("sacardatos").innerHTML="";
							$("#sacardatos").append(
								"<tr><td></td><td><strong>ID_TUsuario</strong></td><td><strong>DESC_TUsuario</strong></td>"
						)
						$.each(datos2,function(indice,valor){
						
		
							$("#sacardatos").append(			

  "<tr><td><input type='checkbox' name='checkbox[]' id='"+valor.ID_TUsuario+"'onClick='gurdar(this.id)'></td><td><a href=TUsuario/editar/"+valor.ID_TUsuario+">"+valor.ID_TUsuario+"</a></td><td><a href=TUsuario/editar/"+valor.ID_TUsuario+">"+valor.DESC_TUsuario+"</a></td>"

								)
						});
					});
}

					
					mostrartabla();

	});

	</script>
	<hr>
	<input type='checkbox' name='select-all' id='select-all' value="hola">
	<table id='sacardatos'>
	</table>
	<input id="boton" type="submit" name="BtnEliminar" value="Eliminar"/>

	<br>

	<hr>
	  <input type="text" name="id_fiscal" class="form-control" id="id_fiscal">
	<br><br>	
</div>
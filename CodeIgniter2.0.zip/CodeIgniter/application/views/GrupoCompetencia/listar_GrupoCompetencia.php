<div>

<b class="borde">Gestión de GupoCompetencias</b>

		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
	
	
	
	<script type="text/javascript">

		$("document").ready(function(source){


		

				function mostrartabla() {

  $.get('GrupoCompetencia/filtrar_GrupoCompetencia', function(datos){
		
							datos2=JSON.parse(datos);
							document.getElementById("sacardatos").innerHTML="";
							$("#sacardatos").append(
								"<tr><td><strong>ID_Grupo_Competencia</strong></td><td><strong>DESC_Grupo_Competencia</strong></td><tr>"
						)
						$.each(datos2,function(indice,valor){
						
		
							$("#sacardatos").append(			

  				"<tr></td><td>"+valor.ID_Grupo_Competencia+"</td><td>"+valor.DESC_Grupo_Competencia+"</td></tr>"

								)
						});
					});
}
					mostrartabla();

	});

	</script>
	<hr>

	<table id='sacardatos'>
	</table>	
</div>
<div>
	
<b class="borde">Gestión de RETOS</b><br>

		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
	
	
	
	<script type="text/javascript">
function gurdar(id){
			  alert(id); 


 //$.get('Reto/borrar',{ID:id}); 
		}
		$("document").ready(function(source){

$('#select-all').click(function(event) {   
 if(this.checked) {
        // Iterate each checkbox
        $(':checkbox').each(function() {
            this.checked = true;                        
        });
  }
  else {
    $(':checkbox').each(function() {
          this.checked = false;
      });
  }

});

		

			$(document).on('change','input[type="checkbox"]' ,function(e) {
    if(this.id=="select-all") {
        if(this.checked) $('#id_fiscal').val(this.value);
        else $('#id_fiscal').val("");
    }
});

				function mostrartabla() {

					//var cod1 = document.getElementById('Retos').value;
					//var cod2 = document.getElementById('TReto').value;

  $.get('Reto/filtrar_Reto', function(datos){
		
							datos2=JSON.parse(datos);
							document.getElementById("sacardatos").innerHTML="";
							$("#sacardatos").append(
								"<tr><td></td><td><strong>ID_Reto</strong></td><td><strong>COD_Reto</strong></td><td><strong>DESC_Reto</strong></td>"
						)
						$.each(datos2,function(indice,valor){
						
		
							$("#sacardatos").append(			

  "<tr><td><input type='checkbox' name='checkbox[]' id='"+valor.ID_Reto+"'onClick='gurdar(this.id)'></td><td><a href=Reto/editar/"+valor.ID_Reto+">"+valor.ID_Reto+"</a></td><td><a href=Reto/editar/"+valor.ID_Reto+">"+valor.COD_Reto+"</a></td><td><a href=Reto/editar/"+valor.ID_Reto+">"+valor.DESC_Reto+"</a></td>"

								)
						});
					});
}

					
					mostrartabla();

	});

	</script>
	<hr>
	<input type='checkbox' name='select-all' id='select-all' value="hola">
	<table id='sacardatos'>
	</table>
	<input type="submit" name="BtnEliminar" value="Eliminar" id="boton"/>

	<br>

	<hr>
	  <input type="text" name="id_fiscal" class="form-control" id="id_fiscal">
	<br><br>	
</div>
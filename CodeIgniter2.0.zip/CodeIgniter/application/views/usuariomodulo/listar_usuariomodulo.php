<div>

<b class="borde">Gestión de UsuarioMódulo</b><br><br>
		

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
	
	
	
	<script type="text/javascript">
function gurdar(id){
			  alert(id); 


 //$.get('UsuarioModulo/borrar',{ID:id}); 
		}
		$("document").ready(function(source){

$('#select-all').click(function(event) {   
 if(this.checked) {
        // Iterate each checkbox
        $(':checkbox').each(function() {
            this.checked = true;                        
        });
  }
  else {
    $(':checkbox').each(function() {
          this.checked = false;
      });
  }

});

		

			$(document).on('change','input[type="checkbox"]' ,function(e) {
    if(this.id=="select-all") {
        if(this.checked) $('#id_fiscal').val(this.value);
        else $('#id_fiscal').val("");
    }
});

				function mostrartabla() {

					var cod1 = document.getElementById('Modulos').value;
					var cod2 = document.getElementById('Usuarios').value;
					
  $.get('UsuarioModulo/filtrar_UsuarioModulo',{COD_Modulo:cod1,	User:cod2},function(datos){
		
							datos2=JSON.parse(datos);
							document.getElementById("sacardatos").innerHTML="";
							$("#sacardatos").append(
								"<tr><td></td><td><strong>ID_Usuario_Modulo</strong></td><td><strong>User</strong></td><td><strong>Nombre</strong></td><td><strong>Apellidos</strong></td><td><strong>COD_Modulo</strong></td><td><strong>DESC_Modulo</strong></td></tr>"
						)
						$.each(datos2,function(indice,valor){
						
		
							$("#sacardatos").append(

									
  "<tr><td><input type='checkbox' name='checkbox[]' id='"+valor.ID_Usuario_Modulo+"'onClick='gurdar(this.id)'></td><td><a href=UsuarioModulo/editar/"+valor.ID_Usuario_Modulo+">"+valor.ID_Usuario_Modulo+"</a></td><td><a href=UsuarioModulo/editar/"+valor.ID_Usuario_Modulo+">"+valor.User+"</a></td><td><a href=UsuarioModulo/editar/"+valor.ID_Usuario_Modulo+">"+valor.Nombre+"</a></td><td><a href=UsuarioModulo/editar/"+valor.ID_Usuario_Modulo+">"+valor.Apellidos+"</a></td><td><a href=UsuarioModulo/editar/"+valor.ID_Usuario_Modulo+">"+valor.COD_Modulo+"</a></td><td><a href=UsuarioModulo/editar/"+valor.ID_Usuario_Modulo+">"+valor.DESC_Modulo+"</a></td>"



								)
						});
					});
}

					$.get('UsuarioModulo/Modulos', function(datos){
				
					datos2=JSON.parse(datos);
				
					$.each(datos2,function(indice,valor){
						$("#Modulos").append('<option value="'+valor.COD_Modulo +'">'+valor.COD_Modulo	+'</option>')
					});
		
				});

				$.get('UsuarioModulo/Usuarios', function(datos){
				
					datos2=JSON.parse(datos);

					$.each(datos2,function(indice,valor){
						$("#Usuarios").append('<option value="'+valor.User +'">'+valor.User	+'</option>')
					});
		
				});
	
		
					$("#boton").click(function(){
					
					mostrartabla();
					});
					
					mostrartabla();

	});

	</script>
	<td>
	<label>Modulos: </label>
	<select id="Modulos">
	<option value="">Todos los Modulos</option>
		option	
	</select>
	<label>Usuarios: </label>
	<select id="Usuarios">
		<option value="">Todos los Tipos de Usuarios</option>
		option
	</select>
	<button id="boton" >Mostrar</button>
	<hr>
	<input type='checkbox' name='select-all' id='select-all' value="hola">
	<table id='sacardatos'>
	</table>
	<input type="submit" name="BtnEliminar" value="Eliminar" id="boton"/>

	<br>

	<hr>
	  <input type="text" name="id_fiscal" class="form-control" id="id_fiscal">
	<br><br>


</div>
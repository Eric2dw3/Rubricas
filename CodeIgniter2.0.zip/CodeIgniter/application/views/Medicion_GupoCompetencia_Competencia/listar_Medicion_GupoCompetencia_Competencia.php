<div>

<b class="borde">Gestión de Medicion_GupoCompetencia_Competencias</b><br><br>


		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
	
	
	
	<script type="text/javascript">

		$("document").ready(function(source){


		

				function mostrartabla() {
					var cod1 = document.getElementById('Medicion').value;
					//var cod2 = document.getElementById('Curso').value;

  $.get('Medicion_GupoCompetencia_Competencia/filtrar_Medicion_GupoCompetencia_Competencia',{ID_Medicion:cod1}, function(datos){
		
							datos2=JSON.parse(datos);
							document.getElementById("sacardatos").innerHTML="";
							$("#sacardatos").append(
								"<tr><td><strong>ID_GrupoCompetencia_Competencia</strong></td><td><strong>COD_Medicion</strong></td><td><strong>DESC_Grupo_Competencia</strong></td><td><strong>DESC_Competencia</strong></td><td><strong>Porcentaje</strong></td><tr>"
						)	
						$.each(datos2,function(indice,valor){
						
		
							$("#sacardatos").append(			

  				"<tr></td><td>"+valor.ID_GrupoCompetencia_Competencia+"</td><td>"+valor.COD_Medicion+"</td><td>"+valor.DESC_Grupo_Competencia+"</td><td>"+valor.DESC_Competencia+"</td><td>"+valor.Porcentaje+"</td></tr>"

								)
						});
					});
}
					$.get('Medicion_GupoCompetencia_Competencia/Medicion', function(datos){
				
					datos2=JSON.parse(datos);
				
					$.each(datos2,function(indice,valor){
						$("#Medicion").append('<option value="'+valor.ID_Medicion +'">'+valor.COD_Medicion	+'</option>')
					});
		
				});

					$("#sacardatos").on('click','td',function(){
					
					 //alert($(".td1").val());
					});
					
					$("#boton").click(function(){
					
					mostrartabla();
					});
					
					mostrartabla();

	});

	</script>
	<td>
	<label>Medicion: </label>
	<select id="Medicion">
	<option value="">Todos los Medicion</option>
		option	
	</select>
	<button id="boton" >Mostrar</button>
	<hr>
	<table id='sacardatos'>
	</table>
	<br><br><br><br><br><br>

</div>
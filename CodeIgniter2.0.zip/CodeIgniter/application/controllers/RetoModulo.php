<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class RetoModulo extends CI_Controller {

	function __construct(){
		parent::__construct();
		$this->load->helper('form');
		$this->load->helper('url');		
		$this->load->model('RetoModulo_model');	
		$this->load->model('Reto_model');
		$this->load->model('Modulo_model');
		$this->load->model('Usuario_model');
				
		
	}

	//ok
	public function index()
	{
		$datos['segmento']=$this->uri->segment(3);
		if (!$datos['segmento']){
			$datos['RetoModulos'] = $this->RetoModulo_model->obtener_RetoModulos_valores();
		}else{
			$datos['RetoModulos'] = $this->RetoModulo_model->obtener_RetoModulo($datos['segmento']);
		}
		$datos['Retos'] = $this->Reto_model->obtener_Retos();
		$datos['Modulos'] = $this->Modulo_model->obtener_Modulos();
		$datos['Usuarios'] = $this->Usuario_model->obtener_UsuarioAdmin();
		$this->load->view('header');
		$this->load->view('retomodulo/nuevo_retomodulo',$datos);
		$this->load->view('retomodulo/listar_retomodulo',$datos);
		$this->load->view('footer');
	}

	//ok
	public function nuevo(){
		$datos['Retos'] = $this->Reto_model->obtener_Retos();
		$datos['Modulos'] = $this->Modulo_model->obtener_Modulos();
		
		$this->load->view('header');
		$this->load->view('retomodulo/nuevo_retomodulo',$datos);
		$this->load->view('footer');
	}

	//ok
	public function nuevo_RetoModulo(){
		$datos = array(
			'ID_Reto' => $this->input->post('ID_Reto'),
			'ID_Modulo' => $this->input->post('ID_Modulo'),
			'ID_UAdmin' => $this->input->post('ID_UAdmin'),

		);
		$this->RetoModulo_model->nuevo_RetoModulo($datos);
		redirect('RetoModulo');		
	}

	//ok
	public function editar(){
		$datos['segmento']=$this->uri->segment(3);
		$datos['RetoModulos']=$this->RetoModulo_model->obtener_RetoModulo($datos['segmento']);
		$datos['Retos'] = $this->Reto_model->obtener_Retos();
		$datos['Modulos'] = $this->Modulo_model->obtener_Modulos();
		$datos['Usuarios'] = $this->Usuario_model->obtener_UsuarioAdmin();
		$this->load->view('header');
		$this->load->view('retomodulo/editar_retomodulo',$datos);
		$this->load->view('footer');
	}

	//ok
	public function actualizar(){
		$datos = array(
			'ID_Reto' => $this->input->post('ID_Reto'),
			'ID_Modulo' => $this->input->post('ID_Modulo'),
			'ID_UAdmin' => $this->input->post('ID_UAdmin'),

		);
		$id = $this->uri->segment(3);
		$this->RetoModulo_model->actualizar_RetoModulo($id,$datos);
		redirect('RetoModulo');
	}

	public function borrar(){
			$ID = $_GET['ID'];
		$this->RetoModulo_model->borrar_RetoModulo($ID);
		redirect('RetoModulo');
	}	

	public function filtrar_RetoModulo(){
	
		$COD_Reto = $_GET['COD_Reto'];
		$COD_Modulo = $_GET['COD_Modulo'];

		$this->RetoModulo_model->filtrar_RetoModulo_valores($COD_Reto,$COD_Modulo);		
	}

	public function Retos(){
			$this->Reto_model->obtener_Reto2();		
	}
	public function Modulo(){
		
		$this->Modulo_model->obtener_Modulo2();		
	}
	
}
<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class UsuarioModulo extends CI_Controller {

	function __construct(){
		parent::__construct();
		$this->load->helper('form');
		$this->load->helper('url');		
		$this->load->model('UsuarioModulo_model');	
		$this->load->model('Usuario_model');
		$this->load->model('Modulo_model');
				
		
	}

	//ok
	public function index()
	{
		$datos['segmento']=$this->uri->segment(3);
		if (!$datos['segmento']){
			$datos['UsuarioModulos'] = $this->UsuarioModulo_model->obtener_UsuarioModulos_valores();
		}else{
			$datos['UsuarioModulos'] = $this->UsuarioModulo_model->obtener_UsuarioModulo($datos['segmento']);
		}
		$datos['Usuarios'] = $this->Usuario_model->obtener_Usuarios();
		$datos['Modulos'] = $this->Modulo_model->obtener_Modulos();
		$datos['filt'] = 0;
		$this->load->view('header');
		$this->load->view('usuariomodulo/nuevo_usuariomodulo',$datos);
		$this->load->view('usuariomodulo/listar_usuariomodulo',$datos);
		$this->load->view('footer');
	}

	//ok
	public function nuevo(){
		$datos['Usuarios'] = $this->Usuario_model->obtener_Usuarios();
		$datos['Modulos'] = $this->Modulo_model->obtener_Modulos();
		$this->load->view('header');
		$this->load->view('usuariomodulo/nuevo_usuariomodulo',$datos);
		$this->load->view('footer');
	}

	//ok
	public function nuevo_UsuarioModulo(){
		$datos = array(
			'ID_Usuario' => $this->input->post('ID_Usuario'),
			'ID_Modulo' => $this->input->post('ID_Modulo'),

		);
		$this->UsuarioModulo_model->nuevo_UsuarioModulo($datos);
		redirect('UsuarioModulo');		
	}

	//ok
	public function editar(){
		$datos['segmento']=$this->uri->segment(3);
		$datos['UsuarioModulos']=$this->UsuarioModulo_model->obtener_UsuarioModulo($datos['segmento']);
		$datos['Usuarios'] = $this->Usuario_model->obtener_Usuarios();
		$datos['Modulos'] = $this->Modulo_model->obtener_Modulos();
		$this->load->view('header');
		$this->load->view('usuariomodulo/editar_usuariomodulo',$datos);
		$this->load->view('footer');
	}

	//ok
	public function actualizar(){
		$datos = array(
			'ID_Usuario' => $this->input->post('ID_Usuario'),
			'ID_Modulo' => $this->input->post('ID_Modulo'),

		);
		$id = $this->uri->segment(3);
		$this->UsuarioModulo_model->actualizar_UsuarioModulo($id,$datos);
		redirect('UsuarioModulo');
	}

	public function borrar(){
		$ID = $_GET['ID'];
		$this->UsuarioModulo_model->borrar_UsuarioModulo($ID);
		redirect('UsuarioModulo');
	}	

	public function filtrar_UsuarioModulo(){
	
		$COD_Modulo = $_GET['COD_Modulo'];
		$User = $_GET['User'];

		$this->UsuarioModulo_model->filtrar_UsuarioModulo_valores($COD_Modulo,$User);		
	}

	public function Modulos(){
			$this->Modulo_model->obtener_Modulo2();		
	}
	public function Usuarios(){
		
		$this->Usuario_model->obtener_Usuario2();		

		}

}
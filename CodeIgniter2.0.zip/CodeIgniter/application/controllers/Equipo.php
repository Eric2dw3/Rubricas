<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Equipo extends CI_Controller {

	function __construct(){
		parent::__construct();
		$this->load->helper('form');
		$this->load->helper('url');		
		$this->load->model('Equipo_model');
		$this->load->model('RetoModulo_model');
		
	}

	//ok
	public function index()
	{
		$datos['segmento']=$this->uri->segment(3);
		if (!$datos['segmento']){
			$datos['Equipos'] = $this->Equipo_model->obtener_Equipos();
		}else{
			$datos['Equipos'] = $this->Equipos_model->obtener_Equipos($datos['segmento']);
		}
		$datos['RetoModulos'] = $this->RetoModulo_model->obtener_RetoModulos();
		$datos['filt'] = 0;
		$this->load->view('header');
		$this->load->view('equipo/nuevo_equipo');
		$this->load->view('equipo/listar_equipo',$datos);
		$this->load->view('footer');
	}

	//ok
	public function nuevo(){
	$datos['RetoModulos'] = $this->RetoModulo_model->obtener_RetoModulos();
		$this->load->view('header');
		$this->load->view('equipo/nuevo_equipo');
		$this->load->view('footer');
	}

	//ok
	public function nuevo_Equipo(){
		$datos = array(
			'ID_Reto_modulo' => $this->input->post('ID_Reto_modulo'),
			'COD_Equipo' => $this->input->post('COD_Equipo'),
			'DESC_Equipo' => $this->input->post('DESC_Equipo')
		);
		$this->Equipo_model->nuevo_Equipo($datos);
		$datos['RetoModulos'] = $this->RetoModulo_model->obtener_RetoModulos();
		redirect('Equipo');		
	}

	//
	public function editar(){
		$datos['segmento']=$this->uri->segment(3);
		$datos['Equipos']=$this->Equipo_model->obtener_Equipo($datos['segmento']);
		$datos['RetoModulos'] = $this->RetoModulo_model->obtener_RetoModulos();
		$this->load->view('header');
		$this->load->view('equipo/editar_equipo',$datos);
		$this->load->view('footer');
	}

	public function actualizar(){
		$datos = array(
			'ID_Reto_modulo' => $this->input->post('ID_Reto_modulo'),
			'COD_Equipo' => $this->input->post('COD_Equipo'),
			'DESC_Equipo' => $this->input->post('DESC_Equipo')
		);	
		$id = $this->uri->segment(3);
		$this->Equipo_model->actualizar_Equipo($id,$datos);
		redirect('Equipo');
	}

	public function borrar(){
		$ID = $_GET['ID'];
		$this->Equipo_model->borrar_Equipo($ID);
		redirect('Equipo');
	}
	public function filtrar_Equipo(){
		$this->Equipo_model->obtener_Equipo2();		
	}	
}
<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Modulo extends CI_Controller {

	function __construct(){
		parent::__construct();
		$this->load->helper('form');
		$this->load->helper('url');	
		$this->load->model('Ciclo_model');				
		$this->load->model('Modulo_model');		
	}

	//ok
	public function index()
	{
		$datos['segmento']=$this->uri->segment(3);
		if (!$datos['segmento']){
			$datos['Modulos'] = $this->Modulo_model->obtener_Modulos_valores();
			$datos['Modulos2'] = $this->Modulo_model->obtener_Modulos_valores();
		}else{
			$datos['Modulos'] = $this->Modulos_model->obtener_Modulo($datos['segmento']);
		}
		$datos['Ciclos'] = $this->Ciclo_model->obtener_ciclos();


		$this->load->view('header');
		$this->load->view('modulo/nuevo_modulo',$datos);
		$this->load->view('modulo/listar_modulo',$datos);
		$this->load->view('footer');
	}

	//ok
	public function nuevo(){
		$datos['Modulos'] = $this->Centro_model->obtener_Modulos();
		$datos['Ciclos'] = $this->Ciclo_model->obtener_ciclos();
		$this->load->view('header');
		$this->load->view('modulo/nuevo_modulo',$datos);
		$this->load->view('footer');
	}

	//ok
	public function nuevo_Modulo(){
		$datos = array(
			'ID_Ciclo' => $this->input->post('ID_Ciclo'),
			'COD_Modulo' => $this->input->post('COD_Modulo'),									
			'DESC_Modulo' => $this->input->post('DESC_Modulo')
		);
		$this->Modulo_model->nuevo_Modulo($datos);
		redirect('Modulo');		
	}

	//ok
	public function editar(){
		$datos['segmento']=$this->uri->segment(3);
		$datos['Modulos']=$this->Modulo_model->obtener_Modulo($datos['segmento']);
		$datos['Ciclos'] = $this->Ciclo_model->obtener_ciclos();
	
		$this->load->view('header');
		$this->load->view('modulo/editar_modulo',$datos);
		$this->load->view('footer');
	}

	//ok
	public function actualizar(){
		$datos = array(
			'ID_Ciclo' => $this->input->post('ID_Ciclo'),
			'COD_Modulo' => $this->input->post('COD_Modulo'),										
			'DESC_Modulo' => $this->input->post('DESC_Modulo')
		);
		$id = $this->uri->segment(3);
		$this->Modulo_model->actualizar_Modulo($id,$datos);
		redirect('Modulo');
	}

	public function borrar(){
		$ID = $_GET['ID'];
		$this->Modulo_model->borrar_Modulo($ID);
		redirect('Modulo');
	}	

	public function Ciclos(){
			$this->Ciclo_model->obtener_Ciclo2();

	}
	
	public function Modulos(){
		
		$this->Modulo_model->obtener_Modulo2();		

		}
	public function filtrar_Modulo(){
	
		$COD_Ciclo = $_GET['COD_Ciclo'];
		$COD_Modulo = $_GET['COD_Modulo'];

		$this->Modulo_model->filtrar_Modulo_valores($COD_Ciclo,$COD_Modulo);		
	}
}
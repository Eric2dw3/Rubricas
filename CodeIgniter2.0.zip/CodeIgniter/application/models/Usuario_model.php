<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Usuario_model extends CI_Model{

	function __construct(){
		parent::__construct();
		$this->load->database();
	}

	public function nuevo_Usuario($datos){
		$datosBD = array(
		'ID_TUsuario' => $this->input->post('ID_TUsuario'),
			'ID_Centro' => $this->input->post('ID_Centro'),
			'User' => $this->input->post('User'),
			'Password' => $this->input->post('Password'),
			'Nombre' => $this->input->post('Nombre'),
			'Apellidos' => $this->input->post('Apellidos'),
			'Email' => $this->input->post('Email'),
			'Dni' => $this->input->post('Dni')
		);
		$this->db->insert('Usuario', $datosBD);
	}

	public function obtener_Usuarios(){
		$query = $this->db->get('Usuario');
		if ($query->num_rows() > 0){
			return $query;
		}else{
			return false;
		}
	}

		public function obtener_UsuarioAdmin(){
		$where = $this->db->where('ID_TUsuario','2');
		$query = $this->db->get('Usuario');
		if ($query->num_rows() > 0){
			return $query;
		}else{
			return false;
		}
	}

	//Obtiene todo los TUsuarios, pero con los valores de las claves referenciadas
	public function obtener_Usuarios_valores(){
		$query = "SELECT * FROM Usuario, TUsuario, Centro WHERE Usuario.ID_Centro=Centro.ID_Centro and Usuario.ID_TUsuario= TUsuario.ID_TUsuario";
		$query = $this->db->query($query);
		if ($query->num_rows() > 0){
			return $query;
		}else{
			return false;
		}
	}	

	public function obtener_Usuario($id){
		$where = $this->db->where('ID_Usuario',$id);
		$query = $this->db->get('Usuario');
		if ($query->num_rows() > 0){
			return $query;
		}else{
			return false;
		}
	}	

	//Obtiene TUsuario por ID, pero con los valores de las claves referenciadas
	public function obtener_Usuario_valores($id){
	$query = "SELECT ID_Usuario, DESC_TUsuario, COD_Centro, DESC_Centro, User, Password, Nombre, Apellidos, Email, Dni  FROM Usuario, TUsuario, Centro WHERE Usuario.ID_Centro=Centro.ID_Centro and Usuario.ID_TUsuario= TUsuario.ID_TUsuario and TUsuario.ID_TUsuario = ".$id;
		$query = $this->db->query($query);
		if ($query->num_rows() > 0){
			return $query;
		}else{
			return false;
		}
	}	

	public function actualizar_Usuario($id,$datos){
		$datosBD = array(
		'ID_TUsuario' => $this->input->post('ID_TUsuario'),
			'ID_Centro' => $this->input->post('ID_Centro'),
			'User' => $this->input->post('User'),
			'Password' => $this->input->post('Password'),
			'Nombre' => $this->input->post('Nombre'),
			'Apellidos' => $this->input->post('Apellidos'),
			'Email' => $this->input->post('Email'),
			'Dni' => $this->input->post('Dni')
		);
		$this->db->where('ID_Usuario',$id);
		$this->db->update('Usuario', $datosBD);
	}	

	public function borrar_Usuario($id){
		$this->db->where('ID_Usuario',$id);
		$this->db->delete('Usuario');
	}

	public function filtrar_Usuario_valores($DESC_TUsuario,$DESC_Centro){
		include("conexion.php");
		if(!$con) {
	    	echo "No se pudo conectar a la base de datos";
	  	}

		if ($DESC_TUsuario == '' and $DESC_Centro != '') {
			$where = "and Centro.DESC_Centro='$DESC_Centro'";
		}
		elseif($DESC_TUsuario != '' and $DESC_Centro == ''){
			$where = "and TUsuario.DESC_TUsuario='$DESC_TUsuario'";
		}
		elseif($DESC_TUsuario == '' and $DESC_Centro == ''){
			$where = "";
		}
		else{
			$where = "and Centro.DESC_Centro='$DESC_Centro' and TUsuario.DESC_TUsuario='$DESC_TUsuario'";
		}

		$sql = "SELECT * FROM Usuario, TUsuario, Centro WHERE Usuario.ID_Centro=Centro.ID_Centro and Usuario.ID_TUsuario=TUsuario.ID_TUsuario $where";
		$result = $con->query($sql);
		$rowdata=array();
		$i=0;
			while ($row = $result->fetch_array())
			{
				$rowdata[$i]=$row;
				$i++;			
			}
		echo json_encode($rowdata);

	}	
	public function obtener_Usuario2(){
		include ("conexion.php");

		if(!$con) {
	  		echo "No se pudo conectar a la base de datos";
	  	}

		$sql = "SELECT * FROM Usuario";
		$result = $con->query($sql);

		$rowdata=array();
		$i=0;
		while ($row = $result->fetch_array())
		{	
			$rowdata[$i]=$row;
			$i++;			
		}
		echo json_encode($rowdata);
	}

	
}


?>
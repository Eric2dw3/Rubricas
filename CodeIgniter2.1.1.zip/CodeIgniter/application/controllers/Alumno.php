<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Alumno extends CI_Controller {

	function __construct(){
		parent::__construct();
		$this->load->helper('form');
		$this->load->helper('url');		
		$this->load->model('Alumno_model');
	}

	public function index()
	{
		session_start();
		$ID_Usuario = $_SESSION['id_login'];

		$datos['Retos'] = $this->Alumno_model->obtener_RetosAlumno($ID_Usuario);
		
		echo 'Conectado como &rArr; "'.$_SESSION['login'].'"';
		$this->load->view('headerlogin');
		$this->load->view('alumno/body_alumno',$datos);
		$this->load->view('footer');
	
	}
	public function anadir_nota()
	{
		session_start();
		$ID_Usuario = $_SESSION['id_login'];
		$Nota = $_GET['N'];
		$ID_UsuarioA = $_GET['ID_Usuario'];
		$ID_Competencia = $_GET['ID_Competencia'];
		$this->Alumno_model->anadir_Alumno_notas($Nota,$ID_UsuarioA,$ID_Competencia,$ID_Usuario);
	}
	public function Notas()
	{

		$Reto=$this->uri->segment(3);
		session_start();
		$ID_Evaluador = $_SESSION['id_login'];
		$datos['NotasA'] = $this->Alumno_model->obtener_Notasalumnos($Reto,$ID_Evaluador);
		$datos['Porcentaje'] = $this->Alumno_model->obtener_Porcentaje();
		$datos['ob'] = $this->Alumno_model->obtener_ob();
		
		$this->load->view('headerlogin');
		$this->load->view('alumno/body_alumno',$datos);
		$this->load->view('footer');
	}


	


}
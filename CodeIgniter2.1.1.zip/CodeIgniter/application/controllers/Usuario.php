<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Usuario extends CI_Controller {

	function __construct(){
		parent::__construct();
		$this->load->helper('form');
		$this->load->helper('url');		
		$this->load->model('TUsuario_model');
		$this->load->model('Centro_model');
		$this->load->model('Usuario_model');
			
	}

	//ok
	public function index()
	{
		$datos['segmento']=$this->uri->segment(3);
		if (!$datos['segmento']){
			$datos['Usuarios'] = $this->Usuario_model->obtener_Usuarios_valores();
		}else{
			$datos['Usuarios'] = $this->Usuarios_model->obtener_Usuario($datos['segmento']);
		}
		$datos['TUsuarios'] = $this->TUsuario_model->obtener_TUsuarios();
		$datos['Centros'] = $this->Centro_model->obtener_Centros();

			

		$this->load->view('header');
		$this->load->view('usuario/nuevo_usuario',$datos);
		$this->load->view('usuario/listar_usuario',$datos);
		$this->load->view('footer');
	}

	//ok
	public function nuevo(){
		$datos['TUsuarios'] = $this->TUsuario_model->obtener_TUsuarios();
		$datos['Centros'] = $this->Centro_model->obtener_Centro();
		$this->load->view('header');
		$this->load->view('usuario/nuevo_usuario',$datos);
		$this->load->view('footer');
	}

	//ok
	public function nuevo_Usuario(){
		$datos = array(
			'ID_TUsuario' => $this->input->post('ID_TUsuario'),
			'ID_Centro' => $this->input->post('ID_Centro'),
			'User' => $this->input->post('User'),
			'Password' => md5($this->input->post('Password')),
			'Nombre' => $this->input->post('Nombre'),
			'Apellidos' => $this->input->post('Apellidos'),
			'Email' => $this->input->post('Email'),
			'Dni' => $this->input->post('Dni')
		);
		$this->Usuario_model->nuevo_Usuario($datos);
		redirect('Usuario');		
	}

	//ok
	public function editar(){
		$datos['segmento']=$this->uri->segment(3);
		$datos['Usuarios']=$this->Usuario_model->obtener_Usuario($datos['segmento']);
		$datos['TUsuarios'] = $this->TUsuario_model->obtener_TUsuarios();
		$datos['Centros'] = $this->Centro_model->obtener_Centros();
		$this->load->view('header');
		$this->load->view('usuario/editar_usuario',$datos);
		$this->load->view('footer');
	}

	//ok
	public function actualizar(){
		$datos = array(
			'ID_TUsuario' => $this->input->post('ID_TUsuario'),
			'ID_Centro' => $this->input->post('ID_Centro'),
			'User' => $this->input->post('User'),
			'Password' => $this->input->post('Password'),
			'Nombre' => $this->input->post('Nombre'),
			'Apellidos' => $this->input->post('Apellidos'),
			'Email' => $this->input->post('Email'),
			'Dni' => $this->input->post('Dni')
		);
		$id = $this->uri->segment(3);
		$this->Usuario_model->actualizar_Usuario($id,$datos);
		redirect('Usuario');
	}



	public function filtrar_Usuario(){
	
		$DESC_TUsuario = $_GET['DESC_TUsuario'];
		$DESC_Centro = $_GET['DESC_Centro'];

		$this->Usuario_model->filtrar_Usuario_valores($DESC_TUsuario,$DESC_Centro);		
	}

	public function TUsuario(){
		
		$this->TUsuario_model->obtener_TUsuario2();		

		}

	public function Centros(){
			$this->Centro_model->obtener_centro2();		
	}

	public function borrar(){
		$box = $_GET['box'];
		$this->Usuario_model->borrar_Usuario($box);
	}	

}

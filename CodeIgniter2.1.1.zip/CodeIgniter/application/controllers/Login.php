<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {

	function __construct(){
		parent::__construct();
		$this->load->helper('form');
		$this->load->helper('url');	
		$this->load->model('Usuario_model');
		$this->load->model('Reto_model');

	}

	public function index(){

		session_start(); 
		$_SESSION['login']=null;
		$_SESSION['id_login']=null;
		echo $_SESSION['login'];
		unset($_SESSION['login']); 
		unset($_SESSION['id_login']);

		$datos['usuarios'] = $this->Usuario_model->obtener_usuarios_valores();
		$datos['usuario_login'] = $this->input->post('usuario');
		$datos['contraseña_login'] = $this->input->post('contraseña');

		$this->load->view('headerlogin');
		$this->load->view('login', $datos);
		$this->load->view('footer');		

	}

	public function verificar_login(){

		//Coge los datos de todos los usuarios
		$usuarios = $this->Usuario_model->obtener_usuarios_valores();

		//Coge el nombre y la contraseña que hemos puesto en el login
		$usuario_login = $this->input->post('usuario');
		$contraseña_login = md5($this->input->post('contraseña'));

	//Si se han recibido el nombre y la contraseña metidos en el login
	if($usuario_login && $contraseña_login){
		
		foreach ($usuarios->result() as $usuario2){

			//Si el usuario y la contraseña coincide con los de alguna fila de la tabla en la base de datos
			if($usuario2->User == $usuario_login && $usuario2->Password == $contraseña_login){
				//$this->load->view('centro'); 
				session_start();
				$_SESSION['login'] = $usuario2->User;
				$_SESSION['id_login'] = $usuario2->ID_Usuario;
				if($usuario2->ID_TUsuario=='1')
					redirect('centro');
				if($usuario2->ID_TUsuario=='2')
					redirect('profesor');
				if($usuario2->ID_TUsuario=='3'){
					redirect('alumno');
				}
			}
				
		}
		?><script>alert('Usuario o contraseña incorrecta');</script><?
			$this->load->view('headerlogin');
			$this->load->view('login');
			$this->load->view('footer');
	} 
}

	public function logueado(){

		//Coge los retos existentes
		$datos['retos'] = $this->Reto_model->obtener_retos(); 
		$datos['usuarios_del_reto'] = $this->Usuario_model->obtener_usuarios_valores();

		//Envía los datos a la vista loguear
		$this->load->view('login/loguear',$datos); 
		
	}

	public function usuarios_reto(){
		$id = $this->input->post('reto');
		$datos['usuarios_del_reto'] = $this->Usuario_model->usuarios_del_reto($id);
		$this->load->view('login/loguear',$datos);
	}

}
<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class CrearReto extends CI_Controller {

	function __construct(){
		parent::__construct();
		$this->load->helper('form');
		$this->load->helper('url');		
		$this->load->model('CrearReto_model');
	
	}

	//ok
	public function index()
	{
	
		//$datos['centros'] = $this->Centro_model->obtener_centros();
		//$datos['ciclos']

		
		$this->load->view('header');
		$this->load->view('CrearReto/body_CrearReto');
		$this->load->view('footer');
	}
	
	public function Ciclos()
	{

		$ID = $_GET['ID'];
		$this->CrearReto_model->busacar_ciclo($ID);
	
	}
	public function Curso()
	{

		$ID = $_GET['ID'];
		$this->CrearReto_model->busacar_Curso($ID);
	
	}
	public function Usuarios()
	{

		$box = $_GET['box'];
		$alumno = $_GET['alumno'];

		$this->CrearReto_model->sacar_CrearReto($box,$alumno);
	
	}
	public function MostrarModulo()
	{

		$ID = $_GET['ID'];
		$ID2 = $_GET['ID2'];
		$ID3 = $_GET['ID3'];
		$this->CrearReto_model->Mostrar_Modulo($ID,$ID2,$ID3);
	
	}
	public function Crear_Reto()
	{

		$COD_Reto = $_GET['COD_Reto'];
		$DESC_Reto = $_GET['DESC_Reto'];
		$this->CrearReto_model->Crear_Reto($COD_Reto,$DESC_Reto);
		
	}
	public function CrearReto_Modulo()
	{

		$ID_Reto = $_GET['ID_Reto'];
		$ID_Modulos = $_GET['ID_Modulos'];
		$this->CrearReto_model->CrearReto_Modulo($ID_Reto,$ID_Modulos);
		
	}
	public function CrearReto_Medicion()
	{

		$ID_Reto = $_GET['ID_Reto'];
		$this->CrearReto_model->CrearReto_Medicion($ID_Reto);
		
	}
	public function CrearReto_Equipo()
	{

		$ID_Reto = $_GET['ID_Reto'];

		$COD_Equipo = $_GET['COD_Equipo'];
		$DESC_Equipo = $_GET['DESC_Equipo'];
		$this->CrearReto_model->CrearReto_Equipo($ID_Reto,$COD_Equipo,$DESC_Equipo);
		
	}
	public function CrearReto_Equipo_Usuario()
	{

		$ID_Equipo = $_GET['ID_Equipo'];
		$ID_Usuarios = $_GET['ID_Usuarios'];
		$COD_Rols = $_GET['COD_Rols'];
		$this->CrearReto_model->CrearReto_Equipo_Usuario($ID_Equipo,$ID_Usuarios,$COD_Rols);
		
	}
	public function CrearReto_Nota_Profesor()
	{

		$ID_Reto = $_GET['ID_Reto'];
		$ID_Usuarios2 = $_GET['ID_Usuarios2'];
		$this->CrearReto_model->CrearReto_Nota_Profesor($ID_Reto,$ID_Usuarios2);
		
	}
	public function CrearReto_Nota_Usuarios()
	{

		$ID_Reto = $_GET['ID_Reto'];
		$ID_Evaluador = $_GET['ID_Evaluador'];
		$this->CrearReto_model->CrearReto_Nota_Usuarios($ID_Reto,$ID_Evaluador);
		
	}
	public function obtener_retomax()
	{
		$datos['retomax']=$this->CrearReto_model->obtener_retomax();
	}
}
<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class CrearReto_model extends CI_Model{

	function __construct(){
		parent::__construct();
		$this->load->database();
	}


	public function busacar_ciclo($ID){
		include("conexion.php");
		if(!$con) {
	    	echo "No se pudo conectar a la base de datos";
	  	}

		
		$sql = "SELECT * FROM Ciclo, Curso WHERE Ciclo.ID_Curso=Curso.ID_Curso and ID_Centro = $ID group by COD_Ciclo";

		$result = $con->query($sql);

		$rowdata=array();
		$i=0;
		while ($row = $result->fetch_array())
		{
			//echo'<option value="'.$row['nom-com'].'">'.$row['nom-com'].'</option>';
			//echo "sdlkcbsdlckbjed";
			$rowdata[$i]=$row;
			$i++;			
		}
		echo json_encode($rowdata);

	}
	
	public function busacar_Curso($ID){
		include("conexion.php");
		if(!$con) {
	    	echo "No se pudo conectar a la base de datos";
	  	}

		
		$sql = "SELECT * FROM Ciclo, Curso WHERE Ciclo.ID_Curso=Curso.ID_Curso and ID_Ciclo = $ID group by Curso.ID_Curso";

		$result = $con->query($sql);

		$rowdata=array();
		$i=0;
		while ($row = $result->fetch_array())
		{
			//echo'<option value="'.$row['nom-com'].'">'.$row['nom-com'].'</option>';
			//echo "sdlkcbsdlckbjed";
			$rowdata[$i]=$row;
			$i++;			
		}
		echo json_encode($rowdata);

	}

	public function Mostrar_Modulo($ID,$ID2,$ID3){
		include("conexion.php");
		if(!$con) {
	    	echo "No se pudo conectar a la base de datos";
	  	}

		
		$sql = "SELECT * FROM Ciclo, Modulo WHERE Ciclo.ID_Ciclo=Modulo.ID_Ciclo and Ciclo.ID_Ciclo = $ID and ID_Centro = $ID2 and ID_Curso = $ID3";

		$result = $con->query($sql);

		$rowdata=array();
		$i=0;
		while ($row = $result->fetch_array())
		{
			//echo'<option value="'.$row['nom-com'].'">'.$row['nom-com'].'</option>';
			//echo "sdlkcbsdlckbjed";
			$rowdata[$i]=$row;
			$i++;			
		}
		echo json_encode($rowdata);

	}
	
	public function Crear_Reto($COD_Reto,$DESC_Reto){
		$query = "INSERT INTO Reto(COD_Reto, DESC_Reto) VALUES ('$COD_Reto','$DESC_Reto')";
		$query = $this->db->query($query);
		
	}

	public function CrearReto_Modulo($ID_Reto,$ID_Modulos){
		foreach ($ID_Modulos as $i) {

		$query = "INSERT INTO `Reto_Modulo` (`ID_Reto_modulo`, `ID_Reto`, `ID_Modulo`, `ID_UAdmin`, `IN_Extendido`, `IN_EAbierta`) VALUES (NULL, '$ID_Reto', '$i', '14', '', '')";
		$query = $this->db->query($query);
		}
	}

	public function CrearReto_Medicion($ID_Reto){
		
		for ($i=1; $i <= 3; $i++) { 
		$query = "INSERT INTO `Reto_Medicion` (`ID_Reto_Medicion`, `ID_Reto`, `ID_Medicion`) VALUES (NULL, '$ID_Reto', '$i')";
		$query = $this->db->query($query);
		$i++;
		}
	}

	public function CrearReto_Equipo($ID_Reto,$COD_Equipo,$DESC_Equipo){
		
	
		$query = "INSERT INTO `Equipo` (`ID_Equipo`, `ID_Reto`, `COD_Equipo`, `DESC_Equipo`) VALUES (NULL, '$ID_Reto', '$COD_Equipo', '$DESC_Equipo')";
		$query = $this->db->query($query);
		$this->db->select_max('ID_Equipo');
		$result = $this->db->get('Equipo')->row();
		echo $result->ID_Equipo;

	}

	public function CrearReto_Equipo_Usuario($ID_Equipo,$ID_Usuarios,$COD_Rols){
		$kont = count($COD_Rols);
		for ($i=0; $i < $kont; $i++) { 
			# code...
		
		$query = "INSERT INTO `Equipo_Usuario` (`ID_Equipo_Usuario`, `ID_Equipo`, `ID_Usuario`, `COD_Rol`) VALUES (NULL, '$ID_Equipo', '$ID_Usuarios[$i]', '$COD_Rols[$i]')";
		
		$query = $this->db->query($query);
	}

	}

	/*public function CrearReto_Nota_Profesor($ID_Reto,$ID_Usuarios2){
		$kont = count($ID_Usuarios2);
		for ($i=0; $i < $kont; $i++) { 
			for ($j=1; $j <= 9; $j++) { 
		
		$query = "INSERT INTO `Notas` (`ID_Nota`, `ID_Reto`, `ID_Medicion`, `ID_Evaluador`, `ID_Usuario`, `ID_Competencia`, `Nota`) VALUES (NULL, '$ID_Reto', '3', '14', '$ID_Usuarios2[$i]', '$j', '0')";
		
		$query = $this->db->query($query);
			}
		}

	}*/

	public function CrearReto_Nota_Usuarios($ID_Reto,$ID_Evaluador){
		$kont = count($ID_Evaluador);
		for ($k=0; $k < $kont; $k++) { 
			for ($i=0; $i < $kont; $i++) { 
				for ($j=1; $j <= 9; $j++) { 
					if ($j==5) {
						$j=9;
					}

			$query = "INSERT INTO `Notas` (`ID_Nota`, `ID_Reto`, `ID_Medicion`, `ID_Evaluador`, `ID_Usuario`, `ID_Competencia`, `Nota`) VALUES (NULL, '$ID_Reto', '1', '$ID_Evaluador[$k]', '$ID_Evaluador[$i]', '$j', '0')";
			
			$query = $this->db->query($query);
				}
			}
		}

	}

	public function CrearReto_Nota_Profesor($ID_Reto,$ID_Usuarios2){
		$kont = count($ID_Usuarios2);
		for ($i=0; $i < $kont; $i++) { 
			for ($j=1; $j <= 9; $j++) { 
		
		$query = "INSERT INTO `Notas` (`ID_Nota`, `ID_Reto`, `ID_Medicion`, `ID_Evaluador`, `ID_Usuario`, `ID_Competencia`, `Nota`) VALUES (NULL, '$ID_Reto', '3', '14', '$ID_Usuarios2[$i]', '$j', '0')";
		
		$query = $this->db->query($query);
			}
		}

	}

	public function obtener_retomax(){
		$this->db->select_max('ID_Reto');
		$result = $this->db->get('Reto')->row();
		echo $result->ID_Reto;
		
	}


	public function sacar_CrearReto($box,$alumno){
		include("conexion.php");
		if(!$con) {
	    	echo "No se pudo conectar a la base de datos";
	  	}
	  	$where= "and";

	  	$kont=0;
	  //	if ($alumno=="1") {
	  		foreach ($box as $i ) {
	  			if ($kont==0) {
	  				$where = $where."(ID_Modulo = $i";
	  			}else{
	  				$where = $where." or $i";
	  			}
	  			$kont=1;
	  		}
	  		$where= $where.")";
	  /*	}else{
	  		$where= "";
	  		foreach ($alumno as $i ) {
	  		
	  				$where = $where." and Usuario.ID_Usuario!=$i";
	  			
	  		}
	  		
	  	}*/

		if ($alumno!="0") {
			foreach ($alumno as $i ) {
	  		
	  				$where = $where." and Usuario.ID_Usuario!=$i";
	  			
	  		}
		}
	  	$where = $where." and ID_TUsuario = 3 group by Usuario.ID_Usuario";
			$sql = "SELECT Usuario.ID_Usuario, User, Nombre, Apellidos, Email, Dni FROM Usuario, Usuario_Modulo WHERE Usuario.ID_Usuario = Usuario_Modulo.ID_Usuario $where";


		$result = $con->query($sql);
		$rowdata=array();
		$i=0;
			while ($row = $result->fetch_array())
			{
				$rowdata[$i]=$row;
				$i++;			
			}
		echo json_encode($rowdata);
	}
}



?>
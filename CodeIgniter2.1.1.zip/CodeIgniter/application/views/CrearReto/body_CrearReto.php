<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>

<script type="text/javascript">
	$("document").ready(function(source){
	
	//	var cod=1;
var box = [];
var ciclo =[];
var alumno =[];
var Users = [];
var COD_Rols = [];
var activo = false;
var Modulo_creado=0;
var ID_Usuarios2=[];


$('#CrearEquipo').click(function(event) {
				var COD_Reto = document.getElementById('COD_Reto').value;
				var DESC_Reto = document.getElementById('DESC_Reto').value;
				var COD_Equipo = document.getElementById('COD_Equipo').value;
				var DESC_Equipo = document.getElementById('DESC_Equipo').value;
			
				if (COD_Reto=="" || DESC_Reto=="" || COD_Equipo=="" || DESC_Equipo=="") {
					alert('Rellene el formulario');
					return;
				}
			
				$("#Centros").prop('disabled', true);
				$("#Ciclos").prop('disabled', true);
				$('#Cursos').attr("disabled", true);
				$('#MostrarUsuario').attr("disabled", true);
				$("input.td1").prop("disabled", true);
				$("#select-all").prop("disabled", true);
			
				var ID_Reto = $.get('CrearReto/obtener_retomax',function(ID_Reto){
				var ID_Centros = document.getElementById('Centros').value;
				var ID_Ciclos = document.getElementById('Ciclos').value;
				var ID_Cursos = document.getElementById('Cursos').value;
				var ID_Modulos = box;
				if(Modulo_creado == 0){

				$.get('CrearReto/CrearReto_Modulo',{ID_Reto:ID_Reto,ID_Modulos:ID_Modulos});
				$.get('CrearReto/CrearReto_Medicion',{ID_Reto:ID_Reto});
				$.get('CrearReto/CrearReto_Nota_Profesor',{ID_Reto:ID_Reto,ID_Usuarios2:ID_Usuarios2});

				}
				Modulo_creado=1;
				var ID_Equipo = $.get('CrearReto/CrearReto_Equipo',{ID_Reto:ID_Reto,COD_Equipo:COD_Equipo,DESC_Equipo:DESC_Equipo},function(ID_Equipo){
				var ID_Usuarios = alumno;
				COD_Rols = [];
				for (var i = 0; i < Users.length; i++) {
   					
   					var n1 = prompt(Users[i]+" Codigo de rol");
    				COD_Rols.push(n1);
			
				}

					$.get('CrearReto/CrearReto_Equipo_Usuario',{ID_Equipo:ID_Equipo,ID_Usuarios:ID_Usuarios,COD_Rols:COD_Rols});
					$.get('CrearReto/CrearReto_Nota_Usuarios',{ID_Reto:ID_Reto,ID_Evaluador:ID_Usuarios});
					
						Users = [];
						COD_Rols = [];
						Modulo_creado=0;
						ID_Usuarios2=[];
						if(activo==false){
							var array = box;
						}
						if(activo){
						 	var array = ciclo;
							activo=false;
						}
						
						actualizar(array, ID_Usuarios);
						
						document.getElementById('DESC_Equipo').value="";
					    document.getElementById('COD_Equipo').value="";
			

					});
			});

});
		function actualizar(array,alumno) {
			

			$.get('CrearReto/Usuarios',{box:array,alumno:alumno}, function(datos){
		 			
							datos2=JSON.parse(datos);
							document.getElementById("sacardatos2").innerHTML="";
							$("#sacardatos2").append(
								"<tr><td></td><td><strong>User</strong></td><td><strong>Nombre</strong></td><td><strong>Apellidos</strong></td><td><strong>Email</strong></td><td><strong>Dni</strong></td></tr>"
						)
							ID_Usuarios2=[];
						$.each(datos2,function(indice,valor){
						
		ID_Usuarios2.push(valor.ID_Usuario);
							$("#sacardatos2").append(

									
  "<tr><td><input type='checkbox' name='checkbox2' id='"+valor.User+"'class='td2' value='"+valor.ID_Usuario+"'></td><td><a >"+valor.User+"</a></td><td><a >"+valor.Nombre+"</a></td><td><a >"+valor.Apellidos+"</a></td><td><a >"+valor.Email+"</a></td><td><a >"+valor.Dni+"</a></td>"

  							

								)
						});
					});
		}

$('#MostrarUsuario').click(function(event) {
		if(activo==false){
		var array = box;
		}
		if(activo){
		 	var array = ciclo;
			activo=false;
		}
		if (array!="") {
			alumno="0";
			actualizar(array,alumno);
			alumno=[];
			$( "#COD_Equipo" ).show();
					$( "#DESC_Equipo" ).show();
					$( "#COD" ).show();
					$( "#DESC" ).show();
					$( "#CrearEquipo" ).show();
		}else{
			document.getElementById("sacardatos2").innerHTML="";
				$( "#COD_Equipo" ).hide();
					$( "#DESC_Equipo" ).hide();
					$( "#COD" ).hide();
					$( "#DESC" ).hide();
					$( "#CrearEquipo" ).hide();
		}
	});

$('#select-all').click(function(event) {  
	 if(this.checked) {
		$(':checkbox').each(function() {
			
			if ($(this).attr("name")!="checkbox2"){
					this.checked = true; 
			}                    
		});
	  }
	  else {
	    $(':checkbox').each(function() {
	    	if ($(this).attr("name")!="checkbox2"){
				 this.checked = false;
			}
	         
	      
		});
	  }

	});
$(document).on('change','input[type="checkbox"]' ,function(e) {
		if(this.id=="select-all") {
			if(activo==false){
				activo = true;
				for(var i=0;i<ciclo.length;i++){
						box[i]=ciclo[i];
				}
			}else{
				activo=false;
				box=[];
			}
		}
		else{
	        if(this.checked){
	        	if ($(this).attr("name")=="checkbox2"){
					alumno.push(this.value);
					Users.push($(this).attr("id"));
					alumno = jQuery.unique(alumno);
					Users = jQuery.unique(Users);
					
			} else{
	        	box.push(this.value);
	        	activo=false;
				box = jQuery.unique(box);
		
			}
	        }
	        else{
	        	if ($(this).attr("name")=="checkbox2"){
					alumno.splice($.inArray(this.value, alumno),1);
					alumno = jQuery.unique(alumno);
					Users.splice($.inArray($(this).attr("id"), Users),1);
					Users = jQuery.unique(Users);
					
			} else{

			    box.splice($.inArray(this.value, box),1);
				activo=false;
				document.getElementById('select-all').checked = false;
				ciclo = jQuery.unique(ciclo);
				box = jQuery.unique(box);
			}
	        }
	    }
	    
	});
$.get('Ciclo/Centros', function(datos){
					var kont = 0;
					datos2=JSON.parse(datos);
				
					$.each(datos2,function(indice,valor){
						$("#Centros").append('<option value="'+valor.ID_Centro +'">'+valor.DESC_Centro	+'</option>')
						if (kont == 0){
						sessionStorage.setItem("cCentros", valor.ID_Centro);
						
						kont=1;
					}
					});
		
				});

var cCentros = sessionStorage.getItem("cCentros");
$.get('CrearReto/Ciclos',{ID:cCentros}, function(datos){
					var kont=0;

					datos2=JSON.parse(datos);
				
					$.each(datos2,function(indice,valor){
						$("#Ciclos").append('<option value="'+valor.ID_Ciclo +'">'+valor.COD_Ciclo	+'</option>')
						if (kont == 0){
						sessionStorage.setItem("cCurso", valor.ID_Ciclo);
						
	
						kont=1;
					}
					});
		
				});

var cCurso = sessionStorage.getItem("cCurso");
$.get('Ciclo/Curso',{ID:cCurso}, function(datos){
				
					datos2=JSON.parse(datos);
				
					$.each(datos2,function(indice,valor){
						$("#Cursos").append('<option value="'+valor.ID_Curso +'">'+valor.COD_Curso	+'</option>')
						
					});
		
				});




				$("#Centros").on('change',function(){
					var kont = 0;
					//$("#provincias").empty();
					 box = [];
					 ciclo =[];
					var cod2=$(this).val();
					
					//var cod3=$('#Ciclos').val();
					document.getElementById("Ciclos").innerHTML="";
					document.getElementById("Cursos").innerHTML="";
					$.get('CrearReto/Ciclos',{ID:cod2},function(datos){
		
						datos2=JSON.parse(datos);
					
					$.each(datos2,function(indice,valor){
						
						$("#Ciclos").append('<option value="'+valor.ID_Ciclo +'">'+valor.COD_Ciclo	+'</option>')
						if (kont == 0){
						sessionStorage.setItem("cCurso2", valor.ID_Ciclo);
						kont=1;
					}
					});
					});
				document.getElementById("sacardatos").innerHTML="";
				document.getElementById("sacardatos2").innerHTML="";
				$( "#select-all" ).hide();
				$( "#MostrarUsuario" ).hide();
				$( "#COD_Equipo" ).hide();
				$( "#DESC_Equipo" ).hide();
				$( "#COD" ).hide();
				$( "#DESC" ).hide();
				$( "#CrearEquipo" ).hide();
				var cCurso2 = sessionStorage.getItem("cCurso2");
				$.get('CrearReto/Curso',{ID:cCurso2},function(datos){
		
						datos2=JSON.parse(datos);
				
					$.each(datos2,function(indice,valor){
						$("#Cursos").append('<option value="'+valor.ID_Curso +'">'+valor.COD_Curso	+'</option>')
					});
					});

				});

				$("#Ciclos").on('change',function(){
					//$("#provincias").empty();
					 box = [];
					 ciclo =[];
					var cod2=$(this).val();
					
					document.getElementById("Cursos").innerHTML="";
					$.get('CrearReto/Curso',{ID:cod2},function(datos){
		
						datos2=JSON.parse(datos);
				
					$.each(datos2,function(indice,valor){
						$("#Cursos").append('<option value="'+valor.ID_Curso +'">'+valor.COD_Curso	+'</option>')
					});
					});
				document.getElementById("sacardatos").innerHTML="";
				document.getElementById("sacardatos2").innerHTML="";
				$( "#select-all" ).hide();
					$( "#MostrarUsuario" ).hide();
				});


		function mostrartabla() {
					$( "#select-all" ).show();
					$( "#MostrarUsuario" ).show();
					$( "#show" ).show();
					
					document.getElementById('select-all').checked = false;
					var cod1 = document.getElementById('Ciclos').value;
					var cod2 = document.getElementById('Centros').value;
					var cod3 = document.getElementById('Cursos').value;

  $.get('CrearReto/MostrarModulo',{ID:cod1,ID2:cod2,ID3:cod3},function(datos){
		ciclo =[];
							datos2=JSON.parse(datos);
							document.getElementById("sacardatos").innerHTML="";
							$("#sacardatos").append(

								"<tr><td></td><td><strong>COD_Modulo</strong></td><td><strong>DESC_Modulo</strong></td></tr>"
						)
						$.each(datos2,function(indice,valor){
						ciclo.push(valor.ID_Modulo);
						
							$("#sacardatos").append(

									
  "<tr><td><input type='checkbox' name='checkbox[]' id='"+valor.ID_Usuario+"' class='td1' value='"+valor.ID_Modulo+"'></td><td><a >"+valor.COD_Modulo+"</a></td><td><a >"+valor.DESC_Modulo+"</a></td>"



								)
						});
					});
}
	$("#MostrarModulo").click(function(){
					
						mostrartabla();	
					
					});
	$("#CrearReto").click(function(){
				var COD_Reto = document.getElementById('COD_Reto').value;
				var DESC_Reto = document.getElementById('DESC_Reto').value;
				
				if (COD_Reto=="" || DESC_Reto=="") {
					alert('Rellene el formulario');
					return;
				}
				$("#COD_Reto").prop('disabled', true);
				$("#DESC_Reto").prop('disabled', true);
				$('#CrearReto').attr("disabled", true);
				$.get('CrearReto/Crear_Reto',{COD_Reto:COD_Reto,DESC_Reto:DESC_Reto});
					$( "#body" ).show();
					});

});	
</script>
<div class="centrado">
	Codigo reto: <input type="text" id="COD_Reto" name="COD_Reto" > 
	Descripción reto: <input type="text" id="DESC_Reto" name="DESC_Reto" >
	<input type="submit" name="CrearReto" value="Crear Reto" id="CrearReto" />
</div>
<div id="body" hidden>


<div class="centrado">
<br><hr>
	<label>Centros: </label>
		<select id="Centros">		
	</select>

	<label>Ciclos: </label>
		<select id="Ciclos">		
	</select>

	<label>Cursos: </label>
		<select id="Cursos">		
	</select>
	<input type="submit" name="MostrarModulo" value="Mostrar Modulos" id="MostrarModulo"/>
<div>
<br><br><hr>
<input type='checkbox' name='select-all' id='select-all' hidden>
<table id='sacardatos'>
</table><br>
<input type="submit" name="MostrarUsuario" value="Mostrar Usuarios" id="MostrarUsuario" hidden/>
<br><br><hr id="show" hidden>
<table id='sacardatos2'>
</table>

<input type="text" id="COD_Rol" name="COD_Rol" placeholder="Codigo Rol" hidden> 
<br>
 <a id="COD" hidden>Codigo equipo:</a> <input type="text" id="COD_Equipo" name="COD_Equipo" hidden> 
 <a id="DESC" hidden>Descripción equipo:</a> <input type="text" id="DESC_Equipo" name="DESC_Equipo" hidden>
 <input type="submit" name="CrearEquipo" value="Crear Equipo" id="CrearEquipo" hidden/>
</div><br><br>
<div>

<b class="borde">Gestión de UsuarioMódulo</b><br><br>
		

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
	
	
		
	<script type="text/javascript">
var box = [];
var ciclo =[];
var activo = false;

function gurdar(id){
		 	 alert(id); 
		}
$("document").ready(function(source){

	$('#Eliminar').click(function(event) {
		if(activo==false){
			for(var i=0;i<box.length;i++){
				z=box[i];
				alert(z);
		 		$.get('UsuarioModulo/borrar',{box:z});
			}
			box = [];
			ciclo =[];
			mostrartabla();
		}
		if(activo){
			for(var i=0;i<ciclo.length;i++){
				z=ciclo[i];
				alert (z);
		 		$.get('UsuarioModulo/borrar',{box:z});
			}
			activo=false;
			box = [];
			ciclo =[];
		}
		mostrartabla();
	});

		mostrartabla();

	$('#select-all').click(function(event) {  
	 if(this.checked) {
		$(':checkbox').each(function() {
			this.checked = true;                        
		});
	  }
	  else {
	    $(':checkbox').each(function() {
	          this.checked = false;
		});
	  }

	});

	$(document).on('change','input[type="checkbox"]' ,function(e) {
		if(this.id=="select-all") {
			if(activo==false){
				activo = true;
				for(var i=0;i<ciclo.length;i++){
						box[i]=ciclo[i];
				}
			}else{
				activo=false;
				box=[];
			}
		}
		else{
	        if(this.checked){
	        	box.push(this.value);
	        	activo=false;
				box = jQuery.unique(box);
				alert('box '+box);
	        }
	        else{

	        	alert('elimino el '+this.value);
			    box.splice($.inArray(this.value, box),1);
				activo=false;
				alert('box '+box);
				document.getElementById('select-all').checked = false;
				ciclo = jQuery.unique(ciclo);
				box = jQuery.unique(box);
	        }
	    }
	    
	});

				function mostrartabla() {

					document.getElementById('select-all').checked = false;
					var cod1 = document.getElementById('Modulos').value;
					var cod2 = document.getElementById('Usuarios').value;
					
  $.get('UsuarioModulo/filtrar_UsuarioModulo',{COD_Modulo:cod1,	User:cod2},function(datos){
		ciclo=[];
		
							datos2=JSON.parse(datos);
							document.getElementById("sacardatos").innerHTML="";
							$("#sacardatos").append(
								"<tr><td></td><td><strong>ID_Usuario_Modulo</strong></td><td><strong>User</strong></td><td><strong>Nombre</strong></td><td><strong>Apellidos</strong></td><td><strong>COD_Modulo</strong></td><td><strong>DESC_Modulo</strong></td></tr>"
						)
						$.each(datos2,function(indice,valor){
							ciclo.push(valor.ID_Usuario_Modulo);						
							ciclo = jQuery.unique(ciclo);
						
		
							$("#sacardatos").append(

									
  "<tr><td><input type='checkbox' name='checkbox[]' id='"+valor.ID_Usuario_Modulo+"'class='td1' value='"+valor.ID_Usuario_Modulo+"'></td><td><a href=UsuarioModulo/editar/"+valor.ID_Usuario_Modulo+">"+valor.ID_Usuario_Modulo+"</a></td><td><a href=UsuarioModulo/editar/"+valor.ID_Usuario_Modulo+">"+valor.User+"</a></td><td><a href=UsuarioModulo/editar/"+valor.ID_Usuario_Modulo+">"+valor.Nombre+"</a></td><td><a href=UsuarioModulo/editar/"+valor.ID_Usuario_Modulo+">"+valor.Apellidos+"</a></td><td><a href=UsuarioModulo/editar/"+valor.ID_Usuario_Modulo+">"+valor.COD_Modulo+"</a></td><td><a href=UsuarioModulo/editar/"+valor.ID_Usuario_Modulo+">"+valor.DESC_Modulo+"</a></td>"



								)
						});
					});
}

					$.get('UsuarioModulo/Modulos', function(datos){
				
					datos2=JSON.parse(datos);
				
					$.each(datos2,function(indice,valor){
						$("#Modulos").append('<option value="'+valor.COD_Modulo +'">'+valor.COD_Modulo	+'</option>')
					});
		
				});

				$.get('UsuarioModulo/Usuarios', function(datos){
				
					datos2=JSON.parse(datos);

					$.each(datos2,function(indice,valor){
						$("#Usuarios").append('<option value="'+valor.User +'">'+valor.User	+'</option>')
					});
		
				});
	
		
					$("#boton").click(function(){
					
					mostrartabla();
					});
					
					mostrartabla();

	});

	</script>
	<td>
	<label>Modulos: </label>
	<select id="Modulos">
	<option value="">Todos los Modulos</option>
		option	
	</select>
	<label>Usuarios: </label>
	<select id="Usuarios">
		<option value="">Todos los Tipos de Usuarios</option>
		option
	</select>
	<button id="boton" >Mostrar</button>
	<hr>
	<input type='checkbox' name='select-all' id='select-all'>
	<table id='sacardatos'>
	</table>
	<input type="submit" name="BtnEliminar" value="Eliminar" id="Eliminar"/>
	<br>
	<hr>
</div>
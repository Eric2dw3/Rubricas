<div>

	
<b class="borde">Gestión de Módulos</b><br><br>


<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
	
	
		
	<script type="text/javascript">
var box = [];
var ciclo =[];
var activo = false;

function gurdar(id){
		 	 alert(id); 
		}
$("document").ready(function(source){

	$('#Eliminar').click(function(event) {
		if(activo==false){
			for(var i=0;i<box.length;i++){
				z=box[i];
				alert(z);
		 		$.get('Modulo/borrar',{box:z});
			}
			box = [];
			ciclo =[];
			mostrartabla();
		}
		if(activo){
			for(var i=0;i<ciclo.length;i++){
				z=ciclo[i];
				alert (z);
		 		$.get('Modulo/borrar',{box:z});
			}
			activo=false;
			box = [];
			ciclo =[];
		}
		mostrartabla();
	});

		mostrartabla();

	$('#select-all').click(function(event) {  
	 if(this.checked) {
		$(':checkbox').each(function() {
			this.checked = true;                        
		});
	  }
	  else {
	    $(':checkbox').each(function() {
	          this.checked = false;
		});
	  }

	});

	$(document).on('change','input[type="checkbox"]' ,function(e) {
		if(this.id=="select-all") {
			if(activo==false){
				activo = true;
				for(var i=0;i<ciclo.length;i++){
						box[i]=ciclo[i];
				}
			}else{
				activo=false;
				box=[];
			}
		}
		else{
	        if(this.checked){
	        	box.push(this.value);
	        	activo=false;
				box = jQuery.unique(box);
				alert('box '+box);
	        }
	        else{

	        	alert('elimino el '+this.value);
			    box.splice($.inArray(this.value, box),1);
				activo=false;
				alert('box '+box);
				document.getElementById('select-all').checked = false;
				ciclo = jQuery.unique(ciclo);
				box = jQuery.unique(box);
	        }
	    }
	    
	});

				function mostrartabla() {

					var cod1 = document.getElementById('Ciclo').value;
					var cod2 = document.getElementById('Modulo').value;
					
  $.get('Modulo/filtrar_Modulo',{COD_Ciclo:cod1,COD_Modulo:cod2},function(datos){
		ciclo=[];
							datos2=JSON.parse(datos);
							document.getElementById("sacardatos").innerHTML="";
							$("#sacardatos").append(
								"<tr><td></td><td><strong>ID_Modulo</strong></td><td><strong>COD_Modulo</strong></td><td><strong>DESC_Modulo</strong></td><td><strong>COD_Ciclo</strong></td><td><strong>DESC_Ciclo</strong></td></tr>"
						)
						$.each(datos2,function(indice,valor){
						ciclo.push(valor.ID_Modulo);						
						ciclo = jQuery.unique(ciclo);
						
		
							$("#sacardatos").append(

									
  "<tr><td><input type='checkbox' name='checkbox[]' id='"+valor.ID_Modulo+"'class='td1' value='"+valor.ID_Modulo+"'></td><td><a href=Modulo/editar/"+valor.ID_Modulo+">"+valor.ID_Modulo+"</a></td><td><a href=Modulo/editar/"+valor.ID_Modulo+">"+valor.COD_Modulo+"</a></td><td><a href=Modulo/editar/"+valor.ID_Modulo+">"+valor.DESC_Modulo+"</a></td><td><a href=Modulo/editar/"+valor.ID_Modulo+">"+valor.COD_Ciclo+"</a></td><td><a href=Modulo/editar/"+valor.ID_Modulo+">"+valor.DESC_Ciclo+"</a></td>"



								)
						});
					});
}

					$.get('Modulo/Ciclos', function(datos){
				
					datos2=JSON.parse(datos);
				
					$.each(datos2,function(indice,valor){
						$("#Ciclo").append('<option value="'+valor.COD_Ciclo +'">'+valor.COD_Ciclo	+'</option>')
					});
		
				});

				$.get('Modulo/Modulos', function(datos){
				
					datos2=JSON.parse(datos);

					$.each(datos2,function(indice,valor){
						$("#Modulo").append('<option value="'+valor.COD_Modulo +'">'+valor.COD_Modulo	+'</option>')
					});
		
				});
	
		
					$("#boton").click(function(){
					
					mostrartabla();
					});
					
					mostrartabla();

	});

	</script>
	<td>
	<label>Ciclo: </label>
	<select id="Ciclo">
	<option value="">Todos los Ciclo</option>
		option	
	</select>
	<label>Modulo: </label>
	<select id="Modulo">
		<option value="">Todos los Tipos de Modulo</option>
		option
	</select>
	<button id="boton" >Mostrar</button>
	<hr>
	<input type='checkbox' name='select-all' id='select-all'>
	<table id='sacardatos'>
	</table>
	<input id="Eliminar" type="submit" name="BtnEliminar" value="Eliminar"/>
	<br>
	<hr>
</div>
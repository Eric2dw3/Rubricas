<div>

<b class="borde">Gestión de Competencias</b>

		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
	
	
	
	<script type="text/javascript">

		$("document").ready(function(source){


		

				function mostrartabla() {

  $.get('Competencia/filtrar_Competencia', function(datos){
		
							datos2=JSON.parse(datos);
							document.getElementById("sacardatos").innerHTML="";
							$("#sacardatos").append(
								"<tr><td><strong>ID_Competencia</strong></td><td><strong>DESC_Competencia</strong></td><td><strong>Mal</strong></td><td><strong>Regular</strong></td><td><strong>Bien</strong></td><td><strong>Excelente</strong></td><tr>"
						)	
						$.each(datos2,function(indice,valor){
						
		
							$("#sacardatos").append(	

  				"<tr></td><td>"+valor.ID_Competencia+"</td><td>"+valor.DESC_Competencia+"</td><td>"+valor.Mal+"</td><td>"+valor.Regular+"</td><td>"+valor.Bien+"</td><td>"+valor.Excelente+"</td></tr>"

								)
						});
					});
}
					mostrartabla();

	});

	</script>
	<hr>

	<table id='sacardatos' class="tabla">
	</table>	
</div>
<?php
$form = array(
	'name' => 'form_retomodulo'
	);
$IN_Extendido = array(	
	'name' => 'IN_Extendido',

	'maxlength' => 1,
	'size' =>1,
	'required' => 1
	);
$IN_EAbierta = array(	
	'name' => 'IN_EAbierta',
	'maxlength' => 1,
	'size' => 1,
	'required' => 1
	);

	if ($Retos){
		$ID_Reto = array();
		foreach ($Retos->result() as $Reto) {
			$ID_Reto[$Reto->ID_Reto] = $Reto->COD_Reto;
		}	
	}
	else{
		$ID_Reto = array(
    		0         => 'No hay Retos'
		);
	}

	if ($Modulos){
		$ID_Modulo = array();
		foreach ($Modulos->result() as $Modulo) {
			$ID_Modulo[$Modulo->ID_Modulo] = $Modulo->COD_Modulo;
		}	
	}
	else{
		$ID_Modulo = array(
    		0         => 'No hay Modulos'
		);
	}	
	if ($Usuarios){
		$ID_Usuario = array();
		foreach ($Usuarios->result() as $Admin) {
			$ID_Usuario[$Admin->ID_Usuario] = $Admin->User;
		}	
	}
	else{
		$ID_Usuario = array(
    		0         => 'No hay Administrador'
		);
	}

?>


<button class="accordion">Crear RetoMódulo</button>



	<div class="panel">
	<?php echo form_open('RetoModulo/nuevo_RetoModulo',$form);?>
	<?php echo form_label('Reto: ','ID_Reto'); ?>
	<?php
	//DESPLEGABLE DE Reto
	echo form_dropdown('ID_Reto', $ID_Reto,1);
	?>
	<br>

	<?php echo form_label('Modulo: ','ID_Modulo'); ?>
	<?php
	//DESPLEGABLE DE ModuloS
	echo form_dropdown('ID_Modulo', $ID_Modulo,1);
	?>
	<br>
	<?php echo form_label('Administrador: ','ID_Usuario'); ?>
	<?php
	//DESPLEGABLE DE CURSOS
	echo form_dropdown('ID_UAdmin', $ID_Usuario, 1);
	?>

	<br>
	<?php echo form_label('IN_Extendido: ','IN_Extendido'); ?>
	<?php echo form_input($IN_Extendido); ?>
	<br>
	<?php echo form_label('IN_EAbierta: ','IN_EAbierta'); ?>
	<?php echo form_input($IN_EAbierta); ?>
	<br>
	<?php echo form_submit('Crear','Crear'); ?>
	<?php echo form_close();?>
</div>
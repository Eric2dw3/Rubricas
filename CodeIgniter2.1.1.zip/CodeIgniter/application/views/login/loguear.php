<?php
$form = array(
	'name' => 'form_logeado'
	);
$reto = array(	
	'name' => 'reto',
	'required' => 1
	);



	if ($retos){
		$array_retos = array(0=>'---Reto---');
		foreach ($retos->result() as $reto) {
			$array_retos[$reto->ID_Reto] = $reto->DESC_Reto;
		}	
	}
	else{
		$array_retos = array(
			0         => 'No tienes retos'
		);
	}


?>
<div>
	<?php echo form_open('Login/usuarios_reto',$form);?>
	
	<?php echo form_label('Reto: ','reto'); ?>
	<?php echo form_dropdown('reto',$array_retos); ?>
	<br>
		
	<?php echo form_submit('Entrar','Entrar'); ?>
	<?php echo form_close();


printf('--------------------------------------------------------------------<br>');	

	if($usuarios_del_reto){
		
			printf('<table>
				<thead>			
				<tr>
					<td>
						<label for="select_all"></label>
						<input id="select_all" type="checkbox">
					</td>
				');
			$primerusuario = $usuarios_del_reto->result()[0];
			foreach ($primerusuario as $key => $value){
				printf('<th id="%s">
						<span>%s</span>
					</th>',$key,$key);
			}
			printf('<th>Acciones</th></tr>
			</thead>
			<tbody>');
			foreach ($usuarios_del_reto->result() as $usuario_del_reto){
				printf('<tr>
					<th>
					<label for="select_%d"></label>
					<input id="select_%d" type="checkbox">
					</th>',$usuario_del_reto->ID_Usuario,$usuario_del_reto->ID_Usuario);

				printf('</tr>');
			}	
			printf('</tbody></table>');
		}
		else{
				printf('<br> No hay Registros');
		}


	?>

</div>
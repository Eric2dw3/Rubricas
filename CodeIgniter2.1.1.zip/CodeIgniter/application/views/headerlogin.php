<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<link href="login.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" type="text/css" href="<? echo base_url();?>/css/alumprof.css">
</head>

<body>
<header>
    <title>Login</title>
</header>
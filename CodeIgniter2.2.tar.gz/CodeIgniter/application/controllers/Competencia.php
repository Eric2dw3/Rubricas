<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Competencia extends CI_Controller {

	function __construct(){
		parent::__construct();
		$this->load->helper('form');
		$this->load->helper('url');		
		$this->load->model('Competencia_model');
		$this->load->library('session');
	}

	//ok
	public function index()
	{
		$datos['segmento']=$this->uri->segment(3);
		if (!$datos['segmento']){
			$datos['Competencias'] = $this->Competencia_model->obtener_Competencias();
		}else{
			$datos['Competencias'] = $this->Competencia_model->obtener_Competencia($datos['segmento']);
		}
	
		$this->load->view('header');
		$this->load->view('Competencia/listar_Competencia',$datos);
		$this->load->view('footer');
	}

	
	public function filtrar_Competencia(){
	
		$this->Competencia_model->obtener_Competencia2();		
	}	
}
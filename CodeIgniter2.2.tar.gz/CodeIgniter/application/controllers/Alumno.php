<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Alumno extends CI_Controller {

	function __construct(){
		parent::__construct();
		$this->load->helper('form');
		$this->load->helper('url');		
		$this->load->model('Alumno_model');
		$this->load->library('session');
	}

	public function index()
	{		
		$datos['Retos'] = $this->Alumno_model->obtener_RetosAlumno($this->session->id_login);
		if(!$datos['Retos']){
			echo 'El usuario "'.$this->session->login. '" no tiene ningún reto.';
			$this->load->view('headerlogin');
			$this->load->view('alumno/body_alumno');
			$this->load->view('footer');
		}else{
			echo 'Conectado como &rArr; "'.$this->session->login.'"';
			$this->load->view('headerlogin');
			$this->load->view('alumno/body_alumno',$datos);
			$this->load->view('footer');
		}
	}
	public function anadir_nota()
	{
		$ID_Usuario = $this->session->id_login;
		$Nota = $_GET['N'];
		$ID_UsuarioA = $_GET['ID_Usuario'];
		$ID_Competencia = $_GET['ID_Competencia'];
		$this->Alumno_model->anadir_Alumno_notas($Nota,$ID_UsuarioA,$ID_Competencia,$ID_Usuario);
	}
	public function Notas()
	{

		$Reto=$this->uri->segment(3);
		$ID_Evaluador = $this->session->id_login;
		$datos['NotasA'] = $this->Alumno_model->obtener_Notasalumnos($Reto,$ID_Evaluador);
		$datos['Porcentaje'] = $this->Alumno_model->obtener_Porcentaje();
		$datos['ob'] = $this->Alumno_model->obtener_ob();
		
		$this->load->view('headerlogin');
		$this->load->view('alumno/body_alumno',$datos);
		$this->load->view('footer');
	}


	


}
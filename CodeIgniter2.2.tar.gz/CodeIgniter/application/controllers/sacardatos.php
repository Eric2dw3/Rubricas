<?php
	include("conexion_2.php");
	
	$id_prov=$_GET['id_prov'];
	
if(!$con) {
    echo "No se pudo conectar a la base de datos";
  }


$sql = "SELECT * FROM provincias WHERE id_prov='$id_prov'";
$result = $con->query($sql);

$rowdata=array();
$i=0;
		while ($row = $result->fetch_array())
		{
			//echo'<option value="'.$row['nom-com'].'">'.$row['nom-com'].'</option>';
			//echo "sdlkcbsdlckbjed";
			$rowdata[$i]=$row;
			$i++;			
		}
echo json_encode($rowdata);
?>
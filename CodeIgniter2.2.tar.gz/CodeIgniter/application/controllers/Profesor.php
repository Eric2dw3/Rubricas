<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Profesor extends CI_Controller {

	function __construct(){
		parent::__construct();
		$this->load->helper('form');
		$this->load->helper('url');		
		$this->load->model('Profesor_model');
		$this->load->model('Alumno_model');
		$this->load->library('session');
		$this->load->library('session');
	}

	//ok
	public function index()
	{
		$this->session->login;
		$datos['Retos'] = $this->Profesor_model->obtener_Retosprofesor($this->session->id_login);
		if(!$datos['Retos']){
			echo 'El usuario "'.$this->session->login. '" no tiene ningún reto.';
			$this->load->view('headerlogin');
			$this->load->view('profesor/body_profesor');
			$this->load->view('footer');
		}else{
			echo 'Conectado como &rArr; "'.$_SESSION['login'].'"';
			$this->load->view('headerlogin');
			$this->load->view('profesor/body_profesor',$datos);
			$this->load->view('footer');
		}
	}
	public function anadir_nota()
	{
		$Nota = $_GET['N'];
		$ID_UsuarioA = $_GET['ID_Usuario'];
		$ID_Competencia = $_GET['ID_Competencia'];

		$this->Profesor_model->anadir_profesor_notas($Nota,$ID_UsuarioA,$ID_Competencia);

	}
	public function Notas()
	{

		$Reto=$this->uri->segment(3);
		
		$datos['NotasA'] = $this->Profesor_model->obtener_Notasalumnos($Reto);
		$datos['coe'] = $this->Profesor_model->obtener_Notasalumnos_coe($Reto);
		$datos['Porcentaje'] = $this->Profesor_model->obtener_Porcentaje();
		$datos['PorcentajeA'] = $this->Alumno_model->obtener_Porcentaje();
		$datos['ob'] = $this->Profesor_model->obtener_ob();
		$datos['notas'] = $this->Profesor_model->obtener_notas();

		$this->load->view('headerlogin');
		$this->load->view('profesor/body_profesor',$datos);
		$this->load->view('footer');
	}
	public function Prueba()
	{

		$ID_Usuario=$this->uri->segment(3);
		
		$datos['Pruebas'] = $this->Profesor_model->obtener_Coevaluacion($ID_Usuario);
		

		$this->load->view('headerlogin');
		$this->load->view('profesor/body_profesor',$datos);
		$this->load->view('footer');
	}

	


}
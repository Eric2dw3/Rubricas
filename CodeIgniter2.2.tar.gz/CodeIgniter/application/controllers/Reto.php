<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Reto extends CI_Controller {

	function __construct(){
		parent::__construct();
		$this->load->helper('form');
		$this->load->helper('url');		
		$this->load->model('Reto_model');
		$this->load->library('session');
	}

	//ok
	public function index()
	{
		$datos['segmento']=$this->uri->segment(3);
		if (!$datos['segmento']){
			$datos['Retos'] = $this->Reto_model->obtener_Retos();
		}else{
			$datos['Retos'] = $this->Retos_model->obtener_Retos($datos['segmento']);
		}
		
		$this->load->view('header');
		$this->load->view('reto/nuevo_reto');
		$this->load->view('reto/listar_reto',$datos);
		$this->load->view('footer');
	}

	//ok
	public function nuevo(){
		$this->load->view('header');
		$this->load->view('reto/nuevo_reto');
		$this->load->view('footer');
	}

	//ok
	public function nuevo_Reto(){
		$datos = array(
			'COD_Reto' => $this->input->post('COD_Reto'),
			'DESC_Reto' => $this->input->post('DESC_Reto')
		);
		$this->Reto_model->nuevo_Reto($datos);
		redirect('Reto');		
	}

	//
	public function editar(){
		$datos['segmento']=$this->uri->segment(3);
		$datos['Retos']=$this->Reto_model->obtener_Reto($datos['segmento']);
		$this->load->view('header');
		$this->load->view('reto/editar_reto',$datos);
		$this->load->view('footer');
	}

	public function actualizar(){
		$datos = array(
			'COD_Reto' => $this->input->post('COD_Reto'),
			'DESC_Reto' => $this->input->post('DESC_Reto')
		);
		$id = $this->uri->segment(3);
		$this->Reto_model->actualizar_Reto($id,$datos);
		redirect('Reto');
	}

	public function borrar(){
		$ID = $_GET['ID'];
		$this->Reto_model->borrar_Reto($ID);
		redirect('Reto');
	}	

	public function filtrar_Reto(){
	
		$this->Reto_model->obtener_Reto3();		
	}	
}
<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Medicion_GupoCompetencia_Competencia extends CI_Controller {

	function __construct(){
		parent::__construct();
		$this->load->helper('form');
		$this->load->helper('url');		
		$this->load->model('Medicion_GupoCompetencia_Competencia_model');
		$this->load->library('session');
	}

	//ok
	public function index()
	{
		$datos['segmento']=$this->uri->segment(3);
		if (!$datos['segmento']){
			$datos['Medicion_GupoCompetencia_Competencias'] = $this->Medicion_GupoCompetencia_Competencia_model->obtener_Medicion_GupoCompetencia_Competencias();
		}else{
			$datos['Medicion_GupoCompetencia_Competencias'] = $this->Medicion_GupoCompetencia_Competencia_model->obtener_Medicion_GupoCompetencia_Competencia($datos['segmento']);
		}
	
		$this->load->view('header');
		$this->load->view('Medicion_GupoCompetencia_Competencia/listar_Medicion_GupoCompetencia_Competencia',$datos);
		$this->load->view('footer');
	}

	
	public function filtrar_Medicion_GupoCompetencia_Competencia(){
	
		$ID_Medicion = $_GET['ID_Medicion'];

		$this->Medicion_GupoCompetencia_Competencia_model->obtener_Medicion_GupoCompetencia_Competencia2($ID_Medicion);		
	}

	public function Medicion(){
		
	$this->Medicion_model->obtener_Medicion2();		

	}	
}
<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class EquipoUsuario extends CI_Controller {

	function __construct(){
		parent::__construct();
		$this->load->helper('form');
		$this->load->helper('url');		
		$this->load->model('EquipoUsuario_model');	
		$this->load->model('Equipo_model');
		$this->load->model('Usuario_model');
		$this->load->library('session');
	}

	//ok
	public function index()
	{
		$datos['segmento']=$this->uri->segment(3);
		if (!$datos['segmento']){
			$datos['EquipoUsuarios'] = $this->EquipoUsuario_model->obtener_EquipoUsuarios_valores();
		}else{
			$datos['EquipoUsuarios'] = $this->EquipoUsuario_model->obtener_EquipoUsuario($datos['segmento']);
		}
		$datos['Equipos'] = $this->Equipo_model->obtener_Equipos();
		$datos['Usuarios'] = $this->Usuario_model->obtener_Usuarios();
		$datos['filt'] = 0;
		$this->load->view('header');
		$this->load->view('equipousuario/nuevo_equipousuario',$datos);
		$this->load->view('equipousuario/listar_equipousuario',$datos);
		$this->load->view('footer');
	}

	//ok
	public function nuevo(){
		$datos['Equipos'] = $this->Equipo_model->obtener_Equipos();
		$datos['Usuarios'] = $this->Usuario_model->obtener_Usuarios();
		$this->load->view('header');
		$this->load->view('equipousuario/nuevo_equipousuario',$datos);
		$this->load->view('footer');
	}

	//ok
	public function nuevo_EquipoUsuario(){
		$datos = array(
			'ID_Equipo' => $this->input->post('ID_Equipo'),
			'ID_Usuario' => $this->input->post('ID_Usuario'),
			'COD_Rol'=> $this->input->post('COD_Rol')

		);
		$this->EquipoUsuario_model->nuevo_EquipoUsuario($datos);
		redirect('EquipoUsuario');		
	}

	//ok
	public function editar(){
		$datos['segmento']=$this->uri->segment(3);
		$datos['EquipoUsuarios']=$this->EquipoUsuario_model->obtener_EquipoUsuario($datos['segmento']);
		$datos['Equipos'] = $this->Equipo_model->obtener_Equipos();
		$datos['Usuarios'] = $this->Usuario_model->obtener_Usuarios();
		$this->load->view('header');
		$this->load->view('equipousuario/editar_equipousuario',$datos);
		$this->load->view('footer');
	}

	//ok
	public function actualizar(){
		$datos = array(
			'ID_Equipo' => $this->input->post('ID_Equipo'),
			'ID_Usuario' => $this->input->post('ID_Usuario'),
			'COD_Rol'=> $this->input->post('COD_Rol')
		);
		$id = $this->uri->segment(3);
		$this->EquipoUsuario_model->actualizar_EquipoUsuario($id,$datos);
		redirect('EquipoUsuario');
	}

	
	/*public function filtrar_EquipoUsuario(){
		$datos = array(
			'ID_Equipo' => $this->input->post('ID_Equipo'),
			'ID_Usuario' => $this->input->post('ID_Usuario'),
			'COD_Rol'=> $this->input->post('COD_Rol')
		);	
	

		$datos['EquipoUsuarios']=$this->EquipoUsuario_model->filtrar_EquipoUsuario_valores($datos);	
		$datos['Equipos'] = $this->Equipo_model->obtener_Equipos();
		$datos['Usuarios'] = $this->Usuario_model->obtener_Usuarios();
		$datos['filt'] = 1;
		$this->load->view('header');
		$this->load->view('equipousuario/listar_equipousuario',$datos);
		$this->load->view('equipousuario/nuevo_equipousuario',$datos);
		$this->load->view('footer');		
	}*/
	public function filtrar_EquipoUsuario(){
	
		$COD_Equipo = $_GET['COD_Equipo'];
		$User = $_GET['User'];

		$this->EquipoUsuario_model->filtrar_EquipoUsuario_valores($COD_Equipo,$User);		
	}


	public function borrar(){
			$box = $_GET['box'];
			$this->EquipoUsuario_model->borrar_EquipoUsuario($box);
		}	



	public function Equipo(){
			$this->Equipo_model->obtener_Equipo2();		
	}
	public function Usuario(){
		
		$this->Usuario_model->obtener_Usuario2();		

		}
}
<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Medicion extends CI_Controller {

	function __construct(){
		parent::__construct();
		$this->load->helper('form');
		$this->load->helper('url');		
		$this->load->model('Medicion_model');
		$this->load->library('session');
	}

	//ok
	public function index()
	{
		$datos['segmento']=$this->uri->segment(3);
		if (!$datos['segmento']){
			$datos['Medicions'] = $this->Medicion_model->obtener_Mediciones();
		}else{
			$datos['Medicions'] = $this->Medicion_model->obtener_Medicion($datos['segmento']);
		}
	
		$this->load->view('header');
		$this->load->view('Medicion/listar_Medicion',$datos);
		$this->load->view('footer');
	}

	
	public function filtrar_Medicion(){
	
		$this->Medicion_model->obtener_Medicion2();		
	}	
}
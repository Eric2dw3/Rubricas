<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Alumno_model extends CI_Model{

	function __construct(){
		parent::__construct();
		$this->load->database();
	}


	public function obtener_RetosAlumno($ID_Usuario){

		$query = "SELECT * FROM Equipo, Reto, Equipo_Usuario where Equipo.ID_Reto=Reto.ID_Reto and Equipo.ID_Equipo=Equipo_Usuario.ID_Equipo and Equipo_Usuario.ID_Usuario=$ID_Usuario";
		$query = $this->db->query($query);
		if ($query->num_rows() > 0){
			return $query;
		}else{
			return false;
		}

	}

	public function obtener_Notasalumnos($Reto,$ID_Evaluador){

		$query = "SELECT * FROM Notas, Usuario, Competencia, Reto, Equipo WHERE Notas.ID_Reto=$Reto and Notas.ID_Usuario=Usuario.ID_Usuario and Notas.ID_Competencia=Competencia.ID_Competencia  and Notas.ID_Evaluador IN 
       (SELECT ID_Evaluador FROM Notas, Usuario WHERE Notas.ID_Evaluador=Usuario.ID_Usuario and Usuario.ID_TUsuario=3) and ID_Evaluador=$ID_Evaluador group by id_nota";
		$query = $this->db->query($query);
		if ($query->num_rows() > 0){
			return $query;
		}else{
			return false;
		}

	}
	public function obtener_Porcentaje(){

		$query = "SELECT Porcentaje, ID_Competencia FROM Medicion_GupoCompetencia_Competencia WHERE ID_Medicion=1 and ID_Competencia not in (5,6,7,8) ORDER BY Medicion_GupoCompetencia_Competencia.ID_Competencia ASC";
		$query = $this->db->query($query);
		if ($query->num_rows() > 0){
			return $query;
		}else{
			return false;
		}

	}
		public function obtener_ob(){

		$query = "SELECT DESC_Competencia FROM Competencia where ID_Competencia not in (5,6,7,8)";
		$query = $this->db->query($query);
		if ($query->num_rows() > 0){
			return $query;
		}else{
			return false;
		}

	}
	public function anadir_Alumno_notas($Nota,$ID_UsuarioA,$ID_Competencia,$ID_Usuario){

		$query = "UPDATE Notas SET Nota=$Nota WHERE ID_Usuario=$ID_UsuarioA and ID_Competencia=$ID_Competencia and ID_Competencia not in (5,6,7,8) and ID_Evaluador=$ID_Usuario";
		$query = $this->db->query($query);
		
	}
}


?>
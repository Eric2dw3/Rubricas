<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class TUsuario_model extends CI_Model{

	function __construct(){
		parent::__construct();
		$this->load->database();
	}

	public function nuevo_TUsuario($datos){
		$datosBD = array(
			'DESC_TUsuario' => $datos['DESC_TUsuario'],
		);
		$this->db->insert('TUsuario', $datosBD);
	}

	public function obtener_TUsuarios(){
		$this->db->distinct();
		$this->db->group_by('DESC_TUsuario'); 
		$query = $this->db->get('TUsuario');

	
		if ($query->num_rows() > 0){
			return $query;
		}else{
			return false;
		}
	}

	public function borrar_TUsuario($box){
		include("conexion.php");
		if(!$con) {
	    	echo "No se pudo conectar a la base de datos";
	  	}	  
			$sql = "DELETE FROM TUsuario WHERE ID_TUsuario= $box";
		$result = $con->query($sql);
	}

	public function obtener_TUsuario($id){
		$where = $this->db->where('ID_TUsuario',$id);
		$query = $this->db->get('TUsuario');
		if ($query->num_rows() > 0){
			return $query;
		}else{
			return false;
		}
	}	

	public function actualizar_TUsuario($id,$datos){
		$datosBD = array(
			'DESC_TUsuario' => $datos['DESC_TUsuario'],
		);
		$this->db->where('ID_TUsuario',$id);
		$this->db->update('TUsuario', $datosBD);
	}	

	public function obtener_TUsuario2(){
		include ("conexion.php");

		if(!$con) {
	  		echo "No se pudo conectar a la base de datos";
	  	}

		$sql = "SELECT DISTINCT DESC_TUsuario FROM TUsuario";
		$result = $con->query($sql);

		$rowdata=array();
		$i=0;
		while ($row = $result->fetch_array())
		{	
			$rowdata[$i]=$row;
			$i++;			
		}
		echo json_encode($rowdata);
	}	
	public function obtener_TUsuario3(){
		include ("conexion.php");

		if(!$con) {
	  		echo "No se pudo conectar a la base de datos";
	  	}

		$sql = "SELECT * FROM TUsuario";
		$result = $con->query($sql);

		$rowdata=array();
		$i=0;
		while ($row = $result->fetch_array())
		{	
			$rowdata[$i]=$row;
			$i++;			
		}
		echo json_encode($rowdata);
	}	

}


?>
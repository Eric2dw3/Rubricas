<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Modulo_model extends CI_Model{

	function __construct(){
		parent::__construct();
		$this->load->database();
	}

	public function nuevo_Modulo($datos){
		$datosBD = array(
			'ID_Ciclo' => $this->input->post('ID_Ciclo'),
			'COD_Modulo' => $this->input->post('COD_Modulo'),									
			'DESC_Modulo' => $this->input->post('DESC_Modulo')
		);
		$this->db->insert('Modulo', $datosBD);
	}

	public function obtener_Modulos(){
		$this->db->group_by('COD_Modulo'); 
		$query = $this->db->get('Modulo');
		if ($query->num_rows() > 0){
			return $query;
		}else{
			return false;
		}
	}

	//Obtiene todo los Modulos, pero con los valores de las claves referenciadas
	public function obtener_Modulos_valores(){
		$query = "SELECT ID_Modulo, COD_Ciclo, DESC_Ciclo, COD_Modulo, DESC_Modulo FROM Ciclo, Modulo WHERE Modulo.ID_Ciclo=Ciclo.ID_Ciclo";
		$query = $this->db->query($query);
		if ($query->num_rows() > 0){
			return $query;
		}else{
			return false;
		}
	}	

	public function obtener_Modulo($id){
		$where = $this->db->where('ID_Modulo',$id);
		$query = $this->db->get('Modulo');
		if ($query->num_rows() > 0){
			return $query;
		}else{
			return false;
		}
	}	

	//Obtiene Modulo por ID, pero con los valores de las claves referenciadas
	public function obtener_Modulo_valores($id){
			$query = "SELECT ID_Modulo, COD_Ciclo, DESC_Ciclo,COD_Modulo, DESC_Modulo FROM Ciclo, Modulo WHERE Modulo.ID_Ciclo=Ciclo.ID_Ciclo and Modulo.ID_Modulo = ".$id;;

		
		$query = $this->db->query($query);
		if ($query->num_rows() > 0){
			return $query;
		}else{
			return false;
		}
	}	

	public function actualizar_Modulo($id,$datos){
		$datosBD = array(
			'ID_Ciclo' => $datos['ID_Ciclo'],
			'COD_Modulo' => $datos['COD_Modulo'],
			'DESC_Modulo' => $datos['DESC_Modulo']
		);
		$this->db->where('ID_Modulo',$id);
		$this->db->update('Modulo', $datosBD);
	}	

	public function borrar_Modulo($box){
		include("conexion.php");
		if(!$con) {
	    	echo "No se pudo conectar a la base de datos";
	  	}	  
			$sql = "DELETE FROM Modulo WHERE ID_Modulo= $box";

		$result = $con->query($sql);
	}

	public function filtrar_Modulo_valores($COD_Ciclo,$COD_Modulo){
		include("conexion.php");
		if(!$con) {
	    	echo "No se pudo conectar a la base de datos";
	  	}

		if ($COD_Modulo == '' and $COD_Ciclo != '') {
			$where = "and Ciclo.COD_Ciclo='$COD_Ciclo'";
		}
		elseif($COD_Modulo != '' and $COD_Ciclo == ''){
			$where = "and Modulo.COD_Modulo='$COD_Modulo'";
		}
		elseif($COD_Modulo == '' and $COD_Ciclo == ''){
			$where = "";
		}
		else{
			$where = "and Ciclo.COD_Ciclo='$COD_Ciclo' and Modulo.COD_Modulo='$COD_Modulo'";
		}

		$sql = "SELECT * FROM Ciclo, Modulo WHERE Modulo.ID_Ciclo=Ciclo.ID_Ciclo $where";

		$result = $con->query($sql);
		$rowdata=array();
		$i=0;
			while ($row = $result->fetch_array())
			{
				$rowdata[$i]=$row;
				$i++;			
			}
		echo json_encode($rowdata);

	}

	public function obtener_Modulo2(){
		include ("conexion.php");

		if(!$con) {
	  		echo "No se pudo conectar a la base de datos";
	  	}

		$sql = "SELECT DISTINCT COD_Modulo FROM Modulo";
		$result = $con->query($sql);

		$rowdata=array();
		$i=0;
		while ($row = $result->fetch_array())
		{	
			$rowdata[$i]=$row;
			$i++;			
		}
		echo json_encode($rowdata);
	}	
	public function obtener_Modulo3(){
		include ("conexion.php");

		if(!$con) {
	  		echo "No se pudo conectar a la base de datos";
	  	}

		$sql = "SELECT * FROM Modulo ";
		$result = $con->query($sql);

		$rowdata=array();
		$i=0;
		while ($row = $result->fetch_array())
		{	
			$rowdata[$i]=$row;
			$i++;			
		}
		echo json_encode($rowdata);
	}	
	
}


?>
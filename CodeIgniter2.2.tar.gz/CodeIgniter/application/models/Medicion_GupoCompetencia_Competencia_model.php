<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Medicion_GupoCompetencia_Competencia_model extends CI_Model{

	function __construct(){
		parent::__construct();
		$this->load->database();
			$this->load->model('Medicion_model');
	}


	public function obtener_Medicion_GupoCompetencia_Competencias(){
		$query = $this->db->get('Medicion_GupoCompetencia_Competencia');
		if ($query->num_rows() > 0){
			return $query;
		}else{
			return false;
		}
	}	
	public function obtener_Medicion_GupoCompetencia_Competencia2($ID_Medicion){
		include ("conexion.php");

		if(!$con) {
	  		echo "No se pudo conectar a la base de datos";
	  	}
	  	if ($ID_Medicion == '') {
			$where = "";
		}
		else{
			$where = "and Medicion_GupoCompetencia_Competencia.ID_Medicion=$ID_Medicion";
		}

		$sql = "SELECT ID_GrupoCompetencia_Competencia, COD_Medicion, DESC_Grupo_Competencia, DESC_Competencia, Porcentaje FROM Medicion_GupoCompetencia_Competencia,GrupoCompetencia,Competencia , Medicion where Medicion_GupoCompetencia_Competencia.ID_GrupoCompetencia=GrupoCompetencia.ID_Grupo_Competencia and Medicion_GupoCompetencia_Competencia.ID_Competencia=Competencia.ID_Competencia and Medicion_GupoCompetencia_Competencia.ID_Medicion=Medicion.ID_Medicion $where ORDER BY ID_GrupoCompetencia_Competencia ASC";

		$result = $con->query($sql);

		$rowdata=array();
		$i=0;
		while ($row = $result->fetch_array())
		{	
			$rowdata[$i]=$row;
			$i++;			
		}
		echo json_encode($rowdata);
	}
}


?>
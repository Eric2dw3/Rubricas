<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class EquipoUsuario_model extends CI_Model{

	function __construct(){
		parent::__construct();
		$this->load->database();
	}

	public function nuevo_EquipoUsuario($datos){
		$datosBD = array(
			'ID_Equipo' => $this->input->post('ID_Equipo'),
			'ID_Usuario' => $this->input->post('ID_Usuario'),
			'COD_Rol'=> $this->input->post('COD_Rol')
		);
		$this->db->insert('Equipo_Usuario', $datosBD);
	}

	public function obtener_EquipoUsuarios(){
		$query = $this->db->get('Equipo_Usuario');
		if ($query->num_rows() > 0){
			return $query;
		}else{
			return false;
		}
	}

	//Obtiene todo los EquipoUsuario, pero con los valores de las claves referenciadas
	public function obtener_EquipoUsuarios_valores(){
		$query = "SELECT ID_Equipo_Usuario, DESC_Equipo, COD_Equipo, COD_Rol, User, Nombre, Apellidos FROM Equipo_Usuario, Usuario, Equipo WHERE Equipo_Usuario.ID_Usuario=Usuario.ID_Usuario and Equipo_Usuario.ID_Equipo=Equipo.ID_Equipo";
		$query = $this->db->query($query);
		if ($query->num_rows() > 0){
			return $query;
		}else{
			return false;
		}
	}	

	public function obtener_EquipoUsuario($id){
		$where = $this->db->where('ID_Equipo_Usuario',$id);
		$query = $this->db->get('Equipo_Usuario');
		if ($query->num_rows() > 0){
			return $query;
		}else{
			return false;
		}
	}	

	//Obtiene EquipoUsuario por ID, pero con los valores de las claves referenciadas
	public function obtener_EquipoUsuario_valores($id){
		$query = "SELECT ID_Equipo_Usuario, DESC_Equipo, COD_Equipo, COD_Rol, User, Nombre, Apellidos FROM Equipo_Usuario, Usuario, Equipo WHERE Equipo_Usuario.ID_Usuario=Usuario.ID_Usuario and Equipo_Usuario.ID_Equipo= Equipo.ID_Equipo and Equipo_Usuario.ID_Equipo_Usuario= ".$id;

		$query = $this->db->query($query);
		if ($query->num_rows() > 0){
			return $query;
		}else{
			return false;
		}
	}	

	public function actualizar_EquipoUsuario($id,$datos){
		$datosBD = array(
		'ID_Equipo' => $this->input->post('ID_Equipo'),
		'ID_Usuario' => $this->input->post('ID_Usuario'),
		'COD_Rol'=> $this->input->post('COD_Rol')
	
		);
		$this->db->where('ID_Equipo_Usuario',$id);
		$this->db->update('Equipo_Usuario', $datosBD);
	}	

	
	/*public function filtrar_EquipoUsuario_valores($COD_Equipo,$User){
			$query = "SELECT * FROM Equipo_Usuario, Usuario, Equipo WHERE Equipo_Usuario.ID_Usuario=Usuario.ID_Usuario and Equipo_Usuario.ID_Equipo= Equipo.ID_Equipo";
			
		if ($filtro['ID_Equipo'] != 0){
			$query = $query . " and Equipo.ID_Equipo = " . $filtro['ID_Equipo'];
		}
		if ($filtro['ID_Usuario'] != 0){
			$query = $query . " and Usuario.ID_Usuario = " . $filtro['ID_Usuario'];
		}		
		$query = $this->db->query($query);		
		if ($query->num_rows() > 0){
			return $query;
		}else{
			return false;
		}
	}	*/
	public function filtrar_EquipoUsuario_valores($COD_Equipo,$User){
		include("conexion.php");
		if(!$con) {
	    	echo "No se pudo conectar a la base de datos";
	  	}

		if ($COD_Equipo == '' and $User != '') {
			$where = "and Usuario.User='$User'";
		}
		elseif($COD_Equipo != '' and $User == ''){
			$where = "and Equipo.COD_Equipo='$COD_Equipo'";
		}
		elseif($COD_Equipo == '' and $User == ''){
			$where = "";
		}
		else{
			$where = "and Usuario.User='$User' and Equipo.COD_Equipo='$COD_Equipo'";
		}

		$sql = "SELECT * FROM Equipo_Usuario, Usuario, Equipo WHERE Equipo_Usuario.ID_Usuario=Usuario.ID_Usuario and Equipo_Usuario.ID_Equipo=Equipo.ID_Equipo $where";

		$result = $con->query($sql);
		$rowdata=array();
		$i=0;
			while ($row = $result->fetch_array())
			{
				$rowdata[$i]=$row;
				$i++;			
			}
		echo json_encode($rowdata);

	}

		public function borrar_EquipoUsuario($box){
		include("conexion.php");
		if(!$con) {
	    	echo "No se pudo conectar a la base de datos";
	  	}

	  
			$sql = "DELETE FROM Equipo_Usuario WHERE ID_Equipo_Usuario= $box";


		$result = $con->query($sql);
	}
	
}


?>
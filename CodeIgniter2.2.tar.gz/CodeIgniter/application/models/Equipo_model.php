<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Equipo_model extends CI_Model{

	function __construct(){
		parent::__construct();
		$this->load->database();
	}

	public function nuevo_Equipo($datos){
		$datosBD = array(
			'ID_Reto' => $this->input->post('ID_Reto'),
			'COD_Equipo' => $datos['COD_Equipo'],
			'DESC_Equipo' => $datos['DESC_Equipo'],
		);
		$this->db->insert('Equipo', $datosBD);
	}

	public function obtener_Equipos(){
		$query = $this->db->get('Equipo');
		if ($query->num_rows() > 0){
			return $query;
		}else{
			return false;
		}
	}

	public function obtener_Equipo($id){
		$where = $this->db->where('ID_Equipo',$id);
		$query = $this->db->get('Equipo');
		if ($query->num_rows() > 0){
			return $query;
		}else{
			return false;
		}
	}		

	public function actualizar_Equipo($id,$datos){
		$datosBD = array(
			'ID_Reto' => $this->input->post('ID_Reto'),
			'COD_Equipo' => $datos['COD_Equipo'],
			'DESC_Equipo' => $datos['DESC_Equipo']
		);
		$this->db->where('ID_Equipo',$id);
		$this->db->update('Equipo', $datosBD);
	}	

	public function obtener_Equipo2(){
		include ("conexion.php");

		if(!$con) {
	  		echo "No se pudo conectar a la base de datos";
	  	}

		$sql = "SELECT * FROM Equipo";
		$result = $con->query($sql);

		$rowdata=array();
		$i=0;
		while ($row = $result->fetch_array())
		{	
			$rowdata[$i]=$row;
			$i++;			
		}
		echo json_encode($rowdata);
	}

	public function borrar_Equipo($box){
		include("conexion.php");
		if(!$con) {
	    	echo "No se pudo conectar a la base de datos";
	  	}	  
			$sql = "DELETE FROM Equipo WHERE ID_Equipo= $box";
		$result = $con->query($sql);
	}
	
}


?>
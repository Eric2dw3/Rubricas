<?php
$form = array(
	'name' => 'form_TUsuario'
	);
$url = "'".base_url()."index.php/TUsuario'";
$js_cancel_button = 'onClick="location.href='.$url.'"';
$DESC_TUsuario = array(
	'name' => 'COD_Curso',
	'value' => $TUsuarios->result()[0]->DESC_TUsuario,
	'placeholder' => 'Descripción de tu Usuario',
	'maxlength' => 10,
	'size' => 20
	);
?>

<div>
	<?php echo form_open('TUsuario/actualizar/'.$TUsuarios->result()[0]->ID_TUsuario,$form);?>
	<?php echo form_label('Descripción de tu Usuario: ','DESC_TUsuario'); ?>
	<?php echo form_input($DESC_TUsuario); ?>
	<br>
	<?php echo form_submit('Guardar','Guardar'); ?>
	<?php echo form_button('Cancelar','Cancelar',$js_cancel_button); ?>
	<?php echo form_close();?>
</div>


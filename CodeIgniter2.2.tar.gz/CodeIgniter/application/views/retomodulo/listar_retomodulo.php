<div>

	
<b class="borde">Gestión de RetoMódulo</b><br><br>


<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
	
	
			
	<script type="text/javascript">
var box = [];
var ciclo =[];
var activo = false;

$("document").ready(function(source){

	$('#Eliminar').click(function(event) {
		if(activo==false){
			for(var i=0;i<box.length;i++){
				z=box[i];
		 		$.get('<? echo base_url();?>index.php/RetoModulo/borrar',{box:z});
	
			}
			box = [];
			ciclo =[];
			mostrartabla();
		}
		if(activo){
			for(var i=0;i<ciclo.length;i++){
				z=ciclo[i];
		 		$.get('<? echo base_url();?>index.php/RetoModulo/borrar',{box:z});
		 
			}
			activo=false;
			box = [];
			ciclo =[];
		}
		mostrartabla();
	});

		mostrartabla();

	$('#select-all').click(function(event) {  
	 if(this.checked) {
		$(':checkbox').each(function() {
			this.checked = true;                        
		});
	  }
	  else {
	    $(':checkbox').each(function() {
	          this.checked = false;
		});
	  }

	});

	$(document).on('change','input[type="checkbox"]' ,function(e) {
		if(this.id=="select-all") {
			if(activo==false){
				activo = true;
				box=[];
				for(var i=0;i<ciclo.length;i++){
						box[i]=ciclo[i];
				}
			}else{
				activo=false;
				box=[];
			}
		}
		else{
	        if(this.checked){
	        	box.push(this.value);
	        	activo=false;
				box = jQuery.unique(box);
	        }
	        else{
			    box.splice($.inArray(this.value, box),1);
				activo=false;
				document.getElementById('select-all').checked = false;
				ciclo = jQuery.unique(ciclo);
				box = jQuery.unique(box);
	        }
	    }
	    
	});
				function mostrartabla() {

					document.getElementById('select-all').checked = false;
					var cod1 = document.getElementById('Retos').value;
					var cod2 = document.getElementById('Modulo').value;
			
					
  $.get('<? echo base_url();?>index.php/RetoModulo/filtrar_RetoModulo',{COD_Reto:cod1,COD_Modulo:cod2,},function(datos){
				ciclo =[];
							datos2=JSON.parse(datos);
							document.getElementById("sacardatos").innerHTML="";
							$("#sacardatos").append(
								"<tr><td></td><td><strong>ID_Reto_modulo</strong></td><td><strong>ID_UAdmin</strong></td><td><strong>IN_Extendido</strong></td><td><strong>IN_EAbierta</strong></td><td><strong>DESC_Reto</strong></td><td><strong>COD_Reto</strong></td><td><strong>COD_Modulo</strong></td><td><strong>DESC_Modulo</strong></td></tr>"
						)
						$.each(datos2,function(indice,valor){
						ciclo.push(valor.ID_Reto_modulo);						
						ciclo = jQuery.unique(ciclo);
						
		
							$("#sacardatos").append(

									
  "<tr><td><input type='checkbox' name='checkbox[]' id='"+valor.ID_Reto_modulo+"'class='td1' value='"+valor.ID_Reto_modulo+"'></td><td><a href=RetoModulo/editar/"+valor.ID_Reto_modulo+">"+valor.ID_Reto_modulo+"</a></td><td><a href=RetoModulo/editar/"+valor.ID_Reto_modulo+">"+valor.ID_UAdmin+"</a></td><td><a href=RetoModulo/editar/"+valor.ID_Reto_modulo+">"+valor.IN_Extendido+"</a></td><td><a href=RetoModulo/editar/"+valor.ID_Reto_modulo+">"+valor.IN_EAbierta+"</a></td><td><a href=RetoModulo/editar/"+valor.ID_Reto_modulo+">"+valor.DESC_Reto+"</a></td><td><a href=RetoModulo/editar/"+valor.ID_Reto_modulo+">"+valor.COD_Reto+"</a></td><td><a href=RetoModulo/editar/"+valor.ID_Reto_modulo+">"+valor.DESC_Modulo+"</a></td><td><a href=RetoModulo/editar/"+valor.ID_Reto_modulo+">"+valor.COD_Modulo+"</a></td>"



								)
						});
					});
}

					$.get('<? echo base_url();?>index.php/RetoModulo/Retos', function(datos){
				
					datos2=JSON.parse(datos);
				
					$.each(datos2,function(indice,valor){
						$("#Retos").append('<option value="'+valor.COD_Reto +'">'+valor.COD_Reto +'</option>')
					});
		
				});

				$.get('<? echo base_url();?>index.php/RetoModulo/Modulo', function(datos){
				
					datos2=JSON.parse(datos);

					$.each(datos2,function(indice,valor){
						$("#Modulo").append('<option value="'+valor.COD_Modulo +'">'+valor.COD_Modulo+'</option>')
					});
		
				});
				
	
		
					$("#boton").click(function(){
					
					mostrartabla();
					});
					
					mostrartabla();

	});

	</script>
	<td>
	<label>Retos: </label>
	<select id="Retos">
	<option value="">Todos los Retos</option>
		</select>
	<label>Modulo: </label>
	<select id="Modulo">
		<option value="">Todos los Tipos de Modulo</option>
	
	</select>
	<button id="boton" >Mostrar</button>
	<hr>
	<input type='checkbox' name='select-all' id='select-all'>
	<div class="tabla">
		<table id='sacardatos'>
		</table>
	</div>
	<input type="submit" name="BtnEliminar" value="Eliminar" id="Eliminar"/>
	<br>
	<hr>
</div>
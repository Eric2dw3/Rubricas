<div>

<b class="borde">Gestión de Centros</b>

		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
	
	
		
	<script type="text/javascript">
var box = [];
var ciclo =[];
var activo = false;

$("document").ready(function(source){

	$('#Eliminar').click(function(event) {
		if(activo==false){
			for(var i=0;i<box.length;i++){
				z=box[i];
		 		$.get('<? echo base_url();?>index.php/Centro/borrar',{box:z});
			}
			box = [];
			ciclo =[];
		}
		if(activo){
			for(var i=0;i<ciclo.length;i++){
				z=ciclo[i];
		 		$.get('<? echo base_url();?>index.php/Centro/borrar',{box:z});
			}
			activo=false;
			box = [];
			ciclo =[];
			mostrartabla();
		}
		mostrartabla();
	});

		mostrartabla();

	$('#select-all').click(function(event) {  
	 if(this.checked) {
		$(':checkbox').each(function() {
			this.checked = true;                        
		});
	  }
	  else {
	    $(':checkbox').each(function() {
	          this.checked = false;
		});
	  }

	});




	$(document).on('change','input[type="checkbox"]' ,function(e) {
		if(this.id=="select-all") {
			if(activo==false){
				activo = true;
				for(var i=0;i<ciclo.length;i++){
						box[i]=ciclo[i];
				}
			}else{
				activo=false;
				box=[];
			}
		}
		else{
	        if(this.checked){
	        	box.push(this.value);
	        	activo=false;
				box = jQuery.unique(box);
	        }
	        else{
			    box.splice($.inArray(this.value, box),1);
				activo=false;
				document.getElementById('select-all').checked = false;
				ciclo = jQuery.unique(ciclo);
				box = jQuery.unique(box);
	        }
	    }
	    
	});

				function mostrartabla() {

				document.getElementById('select-all').checked = false;
					//var cod1 = document.getElementById('Centros').value;
					//var cod2 = document.getElementById('TCentro').value;

  $.get('<? echo base_url();?>index.php/Centro/filtrar_Centro', function(datos){
		ciclo=[];
							datos2=JSON.parse(datos);
							document.getElementById("sacardatos").innerHTML="";
							$("#sacardatos").append(
								"<tr><td></td><td><strong>ID_Centro</strong></td><td><strong>COD_Centro</strong></td><td><strong>DESC_Centro</strong></td></tr>"
						)
						$.each(datos2,function(indice,valor){
						ciclo.push(valor.ID_Centro);	
						
		
							$("#sacardatos").append(

									
  "<tr><td><input type='checkbox' name='checkbox[]' id='"+valor.ID_Centro+"'class='td1' value='"+valor.ID_Centro+"'></td><td><a href=Centro/editar/"+valor.ID_Centro+">"+valor.ID_Centro+"</a></td><td><a href=Centro/editar/"+valor.ID_Centro+">"+valor.COD_Centro+"</a></td><td><a href=Centro/editar/"+valor.ID_Centro+">"+valor.DESC_Centro+"</a></td>"

								)
						});
					});
				}	
		mostrartabla();
	});


</script>

<hr>
	<div>
		<input type='checkbox' name='select-all' id='select-all'>
			<div class="tabla">
				<table id='sacardatos'>
				</table>
			</div>
		<input type="submit" name="BtnEliminar" value="Eliminar" id="Eliminar"/>
		<hr>
	</div>	
</div>
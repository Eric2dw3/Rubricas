<?php
$form = array(
	'name' => 'form_login'
	);
$usuario = array(	
	'name' => 'usuario',
	'placeholder' => 'Escriba su usuario',
	'maxlength' => 20,
	'size' => 20,
	'required' => 1
	);
$contraseña = array(	
	'name' => 'contraseña',
	'type' => 'password',
	'placeholder' => 'Contraseña',
	'maxlength' => 20,
	'size' => 20,
	'required' => 1
	);

?>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>


<audio autoplay="true">
    <source src="../sound/360.mp3" type="audio/mpeg">
</audio>
    <div class="login">
        <div class="login-html">
            <label for="tab-1" class="tab">LOGIN</label>
            <div class="login-form">
                <div class="sign-in-htm"><hr>
					<?php echo form_open('Login/verificar_login',$form);?>
                        <div class="group">                 
							<?php echo form_label('IZENA: ','usuario'); ?>
                            <?php echo form_input($usuario); ?>
                        </div>
                        <div class="group">
                          	<?php echo form_label('PASAHIZTA: ','contraseña'); ?>
                            <?php echo form_input($contraseña); ?>
                        </div>
                        <hr>
                        <div class="group">
                            <?php echo form_submit('Entrar','Entrar'); ?>
                        </div>
					<?php echo form_close();?>
                </div>
            </div>
        </div>
    </div>
<div>

<b class="borde">Gestión de Cursos</b><br>

	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
	
		
	<script type="text/javascript">
var box = [];
var ciclo =[];
var activo = false;

$("document").ready(function(source){

	$('#Eliminar').click(function(event) {
		if(activo==false){
			for(var i=0;i<box.length;i++){
				z=box[i];
		 		$.get('<? echo base_url();?>index.php/Curso/borrar',{box:z});
			}
			box = [];
			ciclo =[];
		}
		if(activo){
			for(var i=0;i<ciclo.length;i++){
				z=ciclo[i];
		 		$.get('<? echo base_url();?>index.php/Curso/borrar',{box:z});
			}
			activo=false;
			box = [];
			ciclo =[];
			mostrartabla();
		}
		mostrartabla();
	});

		mostrartabla();

	$('#select-all').click(function(event) {  
	 if(this.checked) {
		$(':checkbox').each(function() {
			this.checked = true;                        
		});
	  }
	  else {
	    $(':checkbox').each(function() {
	          this.checked = false;
		});
	  }

	});




	$(document).on('change','input[type="checkbox"]' ,function(e) {
		if(this.id=="select-all") {
			if(activo==false){
				activo = true;
				for(var i=0;i<ciclo.length;i++){
						box[i]=ciclo[i];
				}
			}else{
				activo=false;
				box=[];
			}
		}
		else{
	        if(this.checked){
	        	box.push(this.value);
	        	activo=false;
				box = jQuery.unique(box);
	        }
	        else{
			    box.splice($.inArray(this.value, box),1);
				activo=false;
				document.getElementById('select-all').checked = false;
				ciclo = jQuery.unique(ciclo);
				box = jQuery.unique(box);
	        }
	    }
	    
	});


				function mostrartabla() {

					//var cod1 = document.getElementById('Cursos').value;
					//var cod2 = document.getElementById('TCurso').value;

  $.get('<? echo base_url();?>index.php/Curso/filtrar_Curso', function(datos){
		ciclo=[];
							datos2=JSON.parse(datos);
							document.getElementById("sacardatos").innerHTML="";
							$("#sacardatos").append(
								"<tr><td></td><td><strong>ID_Curso</strong></td><td><strong>COD_Curso</strong></td>"
						)
						$.each(datos2,function(indice,valor){
						ciclo.push(valor.ID_Curso);	
						
		
							$("#sacardatos").append(

  "<tr><td><input type='checkbox' name='checkbox[]' id='"+valor.ID_Curso+"'class='td1' value='"+valor.ID_Curso+"'></td><td><a href=Curso/editar/"+valor.ID_Curso+">"+valor.ID_Curso+"</a></td><td><a href=Curso/editar/"+valor.ID_Curso+">"+valor.COD_Curso+"</a></td>"

								)
						});
					});
}

			mostrartabla();

	});

	</script>
	<hr>
	<input type='checkbox' name='select-all' id='select-all'>
			<div class="tabla">
				<table id='sacardatos'>
				</table>
			</div>
	<input type="submit" name="BtnEliminar" value="Eliminar" id="Eliminar"/>
	<br>
	<hr>	
</div>

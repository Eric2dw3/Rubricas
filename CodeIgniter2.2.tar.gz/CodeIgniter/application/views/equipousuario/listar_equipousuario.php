<div>

<b class="borde">Gestión de EquipoUsuario</b><br><br>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
	
	
	
	<script type="text/javascript">
var box = [];
var ciclo =[];
var activo = false;

$("document").ready(function(source){

	$('#Eliminar').click(function(event) {
		if(activo==false){
			for(var i=0;i<box.length;i++){
				z=box[i];		 		$.get('<? echo base_url();?>index.php/EquipoUsuario/borrar',{box:z});
			}
			box = [];
			ciclo =[];
		}
		if(activo){
			for(var i=0;i<ciclo.length;i++){
				z=ciclo[i];
		 		$.get('<? echo base_url();?>index.php/EquipoUsuario/borrar',{box:z});
			}
			activo=false;
			box = [];
			ciclo =[];
		}
		mostrartabla();
	});

		mostrartabla();

	$('#select-all').click(function(event) {  
	 if(this.checked) {
		$(':checkbox').each(function() {
			this.checked = true;                        
		});
	  }
	  else {
	    $(':checkbox').each(function() {
	          this.checked = false;
		});
	  }

	});

	$(document).on('change','input[type="checkbox"]' ,function(e) {
		if(this.id=="select-all") {
			if(activo==false){
				activo = true;
				for(var i=0;i<ciclo.length;i++){
						box[i]=ciclo[i];
				}
			}else{
				activo=false;
				box=[];
			}
		}
		else{
	        if(this.checked){
	        	box.push(this.value);
	        	activo=false;
				box = jQuery.unique(box);
	        }
	        else{
			    box.splice($.inArray(this.value, box),1);
				activo=false;
				document.getElementById('select-all').checked = false;
				ciclo = jQuery.unique(ciclo);
				box = jQuery.unique(box);
	        }
	    }
	    
	});


				function mostrartabla() {

					document.getElementById('select-all').checked = false;
					var cod1 = document.getElementById('Equipos').value;
					var cod2 = document.getElementById('Usuarios').value;
					
  $.get('<? echo base_url();?>index.php/EquipoUsuario/filtrar_EquipoUsuario',{COD_Equipo:cod1,User:cod2},function(datos){
			ciclo=[];
							datos2=JSON.parse(datos);
							document.getElementById("sacardatos").innerHTML="";
							$("#sacardatos").append(
								"<tr><td></td><td><strong>ID_Equipo_Usuario</strong></td><td><strong>DESC_Equipo</strong></td><td><strong>COD_Equipo</strong></td><td><strong>COD_Rol</strong></td><td><strong>User</strong></td><td><strong>Nombre</strong></td><td><strong>Apellidos</strong></td></tr>"
						)
						$.each(datos2,function(indice,valor){
						ciclo.push(valor.ID_Equipo_Usuario);
						
		
							$("#sacardatos").append(

									
  "<tr><td><input type='checkbox' name='checkbox[]' id='"+valor.ID_Equipo_Usuario+"'class='td1' value='"+valor.ID_Equipo_Usuario+"'></td><td><a href=EquipoUsuario/editar/"+valor.ID_Equipo_Usuario+">"+valor.ID_Equipo_Usuario+"</a></td><td><a href=EquipoUsuario/editar/"+valor.ID_Equipo_Usuario+">"+valor.DESC_Equipo+"</a></td><td><a href=EquipoUsuario/editar/"+valor.ID_Equipo_Usuario+">"+valor.COD_Equipo+"</a></td><td><a href=EquipoUsuario/editar/"+valor.ID_Equipo_Usuario+">"+valor.COD_Rol+"</a></td><td><a href=EquipoUsuario/editar/"+valor.ID_Equipo_Usuario+">"+valor.User+"</a></td><td><a href=EquipoUsuario/editar/"+valor.ID_Equipo_Usuario+">"+valor.Nombre+"</a></td><td><a href=EquipoUsuario/editar/"+valor.ID_Equipo_Usuario+">"+valor.Apellidos+"</a></td>"
								)
						});
					});
}

					$.get('<? echo base_url();?>index.php/EquipoUsuario/Equipo', function(datos){
				
					datos2=JSON.parse(datos);
				
					$.each(datos2,function(indice,valor){
						$("#Equipos").append('<option value="'+valor.COD_Equipo +'">'+valor.COD_Equipo	+'</option>')
					});
		
				});

				$.get('<? echo base_url();?>index.php/EquipoUsuario/Usuario', function(datos){
				
					datos2=JSON.parse(datos);

					$.each(datos2,function(indice,valor){
						$("#Usuarios").append('<option value="'+valor.User +'">'+valor.User	+'</option>')
					});
		
				});
	
		
					$("#boton").click(function(){
					
					mostrartabla();
					});
					
					mostrartabla();

	});

	</script>
	<td>
	<label>Equipos: </label>
	<select id="Equipos">
	<option value="">Todos los Equipos</option>
		option	
	</select>
	<label>Usuarios: </label>
	<select id="Usuarios">
		<option value="">Todos los Tipos de Usuarios</option>
		option
	</select>
	<button id="boton" >Mostrar</button>
	<hr>
	<input type='checkbox' name='select-all' id='select-all'>
			<div class="tabla">
				<table id='sacardatos'>
				</table>
			</div>
	<input id="Eliminar" type="submit" name="BtnEliminar" value="Eliminar"/>
	<br>
	<hr>
</div>
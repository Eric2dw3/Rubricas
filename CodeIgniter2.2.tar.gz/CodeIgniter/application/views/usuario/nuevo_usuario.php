<?php
$form = array(
	'name' => 'form_Usuario'
	);
$User = array(
	'name' => 'User',
	'placeholder' => 'User',
	'maxlength' => 10,
	'size' => 20,
	'required' => 1
	);
$Password = array(	
	'name' => 'Password',
	'placeholder' => 'Password',
	'maxlength' => 100,
	'size' => 30,
	'required' => 1
	);

$Nombre = array(
	'name' => 'Nombre',
	'placeholder' => 'Nombre',
	'maxlength' => 10,
	'size' => 20,
	'required' => 1
	);
$Apellidos = array(	
	'name' => 'Apellidos',
	'placeholder' => 'Apellidos',
	'maxlength' => 100,
	'size' => 30,
	'required' => 1
	);
$Email = array(
	'name' => 'Email',
	'placeholder' => 'Email',
	'maxlength' => 50,
	'size' => 34,
	'required' => 1
	);
$Dni = array(	
	'name' => 'Dni',
	'placeholder' => 'Dni',
	'maxlength' => 100,
	'size' => 30,
	'required' => 1
	);


	if ($Centros){
		$ID_Centro = array();
		foreach ($Centros->result() as $Centro) {
			$ID_Centro[$Centro->ID_Centro] = $Centro->DESC_Centro;
		}	
	}
	else{
		$ID_Centro = array(
    		0         => 'No hay Centros'
		);
	}

	if ($TUsuarios){
		$ID_TUsuario = array();
		foreach ($TUsuarios->result() as $TUsuario) {
			$ID_TUsuario[$TUsuario->ID_TUsuario] = $TUsuario->DESC_TUsuario;
		}	
	}
	else{
		$ID_TUsuario = array(
    		0         => 'No hay TUsuarios'
		);
	}	

?>

<button class="accordion">Crear Usuario</button>



	<div class="panel">
	<?php echo form_open('Usuario/nuevo_Usuario',$form);?>
	<?php echo form_label('Centro: ','ID_Centro'); ?>
	<?php
	//DESPLEGABLE DE Centro
	echo form_dropdown('ID_Centro', $ID_Centro,1);
	?>
	<br>

	<?php echo form_label('TUsuario: ','ID_TUsuario'); ?>
	<?php
	//DESPLEGABLE DE TUsuarioS
	echo form_dropdown('ID_TUsuario', $ID_TUsuario,1);
	?>
	<br>

	<?php echo form_label('User: ','User'); ?>
	<?php echo form_input($User); ?>
	<br>
	<?php echo form_label('Password','Password'); ?>
	<?php echo form_input($Password); ?>
	<br>
	<?php echo form_label('Nombre: ','Nombre'); ?>
	<?php echo form_input($Nombre); ?>
	<br>
	<?php echo form_label('Apellidos','Apellidos'); ?>
	<?php echo form_input($Apellidos); ?>
	<br>
	<?php echo form_label('Email: ','Email'); ?>
	<?php echo form_input($Email); ?>
	<br>
	<?php echo form_label('Dni','Dni'); ?>
	<?php echo form_input($Dni); ?>
	<br>		
	<?php echo form_submit('Crear','Crear'); ?>
	<?php echo form_close();?>
</div>
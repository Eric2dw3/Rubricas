<div>

<b class="borde">Gestión de Usuarios</b><br><br>
		
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
	
		
		
	<script type="text/javascript">
var box = [];
var ciclo =[];
var activo = false;

function gurdar(id){
		 	 alert(id); 
		}
$("document").ready(function(source){

	$('#Eliminar').click(function(event) {
		if(activo==false){
			for(var i=0;i<box.length;i++){
				z=box[i];
				alert(z);
		 		$.get('<? echo base_url();?>index.php/Usuario/borrar',{box:z});
			}
			box = [];
			ciclo =[];
			mostrartabla();
		}
		if(activo){
			for(var i=0;i<ciclo.length;i++){
				z=ciclo[i];
				alert (z);
		 		$.get('<? echo base_url();?>index.php/Usuario/borrar',{box:z});
			}
			activo=false;
			box = [];
			ciclo =[];
		}
		mostrartabla();
	});

		mostrartabla();

	$('#select-all').click(function(event) {  
	 if(this.checked) {
		$(':checkbox').each(function() {
			this.checked = true;                        
		});
	  }
	  else {
	    $(':checkbox').each(function() {
	          this.checked = false;
		});
	  }

	});

	$(document).on('change','input[type="checkbox"]' ,function(e) {
		if(this.id=="select-all") {
			if(activo==false){
				activo = true;
				for(var i=0;i<ciclo.length;i++){
						box[i]=ciclo[i];
				}
			}else{
				activo=false;
				box=[];
			}
		}
		else{
	        if(this.checked){
	        	box.push(this.value);
	        	activo=false;
				box = jQuery.unique(box);
				alert('box '+box);
	        }
	        else{

	        	alert('elimino el '+this.value);
			    box.splice($.inArray(this.value, box),1);
				activo=false;
				alert('box '+box);
				document.getElementById('select-all').checked = false;
				ciclo = jQuery.unique(ciclo);
				box = jQuery.unique(box);
	        }
	    }
	    
	});
				function mostrartabla() {

					document.getElementById('select-all').checked = false;
					var cod1 = document.getElementById('Centros').value;
					var cod2 = document.getElementById('TUsuario').value;

  $.get('<? echo base_url();?>index.php/Usuario/filtrar_Usuario',{DESC_Centro:cod1,DESC_TUsuario:cod2},function(datos){
		ciclo=[];
							datos2=JSON.parse(datos);
							document.getElementById("sacardatos").innerHTML="";
							$("#sacardatos").append(
								"<tr><td></td><td><strong>ID_Usuario</strong></td><td><strong>DESC_TUsuario</strong></td><td><strong>COD_Centro</strong></td><td><strong>DESC_Centro</strong></td><td><strong>User</strong></td><td><strong>Password</strong></td><td><strong>Nombre</strong></td><td><strong>Apellidos</strong></td><td><strong>Email</strong></td><td><strong>DNI</strong></td> </tr>"
						)
						$.each(datos2,function(indice,valor){
						ciclo.push(valor.ID_Usuario);						
						ciclo = jQuery.unique(ciclo);
						
		
							$("#sacardatos").append(

									
  "<tr><td><input type='checkbox' name='checkbox[]' id='"+valor.ID_Usuario+"'class='td1' value='"+valor.ID_Usuario+"'></td><td><a href=Usuario/editar/"+valor.ID_Usuario+">"+valor.ID_Usuario+"</a></td><td><a href=Usuario/editar/"+valor.ID_Usuario+">"+valor.DESC_TUsuario+"</a></td><td><a href=Usuario/editar/"+valor.ID_Usuario+">"+valor.COD_Centro+"</a></td><td><a href=Usuario/editar/"+valor.ID_Usuario+">"+valor.DESC_Centro+"</a></td><td><a href=Usuario/editar/"+valor.ID_Usuario+">"+valor.User+"</a></td><td><a href=Usuario/editar/"+valor.ID_Usuario+">"+valor.Password+"</a></td><td><a href=Usuario/editar/"+valor.ID_Usuario+">"+valor.Nombre+"</a></td><td><a href=Usuario/editar/"+valor.ID_Usuario+">"+valor.Apellidos+"</a></td><td><a href=Usuario/editar/"+valor.ID_Usuario+">"+valor.Email+"</a></td><td><a href=Usuario/editar/"+valor.ID_Usuario+">"+valor.Dni+"</a></td>"



								)
						});
					});
}


				$.get('<? echo base_url();?>index.php/Usuario/TUsuario', function(datos){
				
					datos2=JSON.parse(datos);

					$.each(datos2,function(indice,valor){
						$("#TUsuario").append('<option value="'+valor.DESC_TUsuario +'">'+valor.DESC_TUsuario	+'</option>')
					});
		
				});


					$.get('<? echo base_url();?>index.php/Usuario/Centros', function(datos){
				
					datos2=JSON.parse(datos);
				
					$.each(datos2,function(indice,valor){
						$("#Centros").append('<option value="'+valor.DESC_Centro +'">'+valor.DESC_Centro	+'</option>')
					});
		
				});
		
					$("#boton").click(function(){
					
					mostrartabla();
					});
					
					mostrartabla();

	});

	</script>
	<td>
	<label>Centros: </label>
	<select id="Centros">
	<option value="">Todos los Centros</option>	
	</select>
	<label>TUsuario: </label>
	<select id="TUsuario">
		<option value="">Todos los Tipos de usuario</option>
	</select>
	<button id="boton" >Mostrar</button>
	<hr>
	<input type='checkbox' name='select-all' id='select-all'>
	<div class="tabla">
		<table id='sacardatos'>
		</table>
	</div>
	<input type="submit" name="BtnEliminar" value="Eliminar" id="Eliminar"/>
	<hr>
</div>
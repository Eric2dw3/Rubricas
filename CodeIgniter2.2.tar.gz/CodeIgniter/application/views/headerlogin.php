<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<link href="login.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" media='screen and (min-width: 500px)' href="<? echo base_url();?>/css/alumprof.css">
<link rel='stylesheet' media='screen and (max-width: 500px)' href='<? echo base_url();?>/css/movil.css'>

</head>
<body>
<header>
    <title>Rúbricas</title>
</header>
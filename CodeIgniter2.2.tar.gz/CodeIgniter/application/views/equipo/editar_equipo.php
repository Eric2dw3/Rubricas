<?php
$form = array(
	'name' => 'form_Equipo'
	);
$url = "'".base_url()."index.php/Equipo'";
$js_cancel_button = 'onClick="location.href='.$url.'"';
$COD_Equipo = array(
	'name' => 'COD_Equipo',
	'value' => $Equipos->result()[0]->COD_Equipo,
	'placeholder' => 'Código de Equipo',
	'maxlength' => 10,
	'size' => 20
	);
$DESC_Equipo = array(	
	'name' => 'DESC_Equipo',
	'value' => $Equipos->result()[0]->DESC_Equipo,
	'placeholder' => 'Descripción de Equipo',
	'maxlength' => 100,
	'size' => 30
	);
if ($Reto2){
		$ID_Reto = array();
		foreach ($Reto2->result() as $RModulo) {
			$ID_Reto[$RModulo->ID_Reto] = $RModulo->ID_Reto;
		}	
	}
	else{
		$ID_Reto = array(
    		0         => 'No hay Reto Modulos'
		);
	}

?>




<div>
	<?php echo form_open('Equipo/actualizar/'.$Equipos->result()[0]->ID_Equipo,$form);?>
	<br>
	<?php echo form_label('Reto Modulo: ','ID_Reto'); ?>
	<?php
	//DESPLEGABLE DE Equipos
	echo form_dropdown('ID_Reto', $ID_Reto, $Equipos->result()[0]->ID_Reto);
	?>
	<br>

	<?php echo form_label('Código de Equipo: ','COD_Equipo'); ?>
	<?php echo form_input($COD_Equipo); ?>
	<br>
	<?php echo form_label('Descripción de Equipo: ','DESC_Equipo'); ?>
	<?php echo form_input($DESC_Equipo); ?>
	<br>
	<?php echo form_submit('Actualizar','Actualizar'); ?>
	<?php echo form_button('Cancelar','Cancelar',$js_cancel_button); ?>	
	<?php echo form_close();?>
</div>


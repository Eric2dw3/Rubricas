<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<link href="login.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" media='screen and (min-width: 500px)' href="<? echo base_url();?>/css/login.css">
<link rel='stylesheet' media='screen and (max-width: 500px)' href='<? echo base_url();?>/css/movil.css'>

<?
if(!($this->session->has_userdata('tipo'))){
	redirect(base_url());
}
?>

<style>

.sidebar {
    position: fixed;
    height: 100%;
    width: 0;
    top: 0;
    left: 0;
    z-index: 1;
    background-color: #00324b;
    overflow-x: hidden;
    transition: 0.4s;
    padding: 1rem 0;
    box-sizing:border-box;
}

.sidebar .boton-cerrar {
    position: absolute;
    top: 0.5rem;
    right: 1rem;
    font-size: 2rem;
    display: block;
    padding: 0;
    line-height: 1.5rem;
    margin: 0;
    height: 32px;
    width: 32px;
    text-align: center;
    vertical-align: top;
}

.sidebar ul, .sidebar li{
    margin:0;
    padding:0;
    list-style:none inside;
}

.sidebar ul {
    margin: auto;
    display: block;
    width: 80%;
    min-width:200px;
}

.sidebar a {
    display: block;
    font-size: 120%;
    text-decoration: none;
}

.abrir-cerrar {
    color: coral;
	background:#333;
	border-top: 2px solid #fff;
	border-left: 2px solid #fff;
	border-radius: 18px;	
    padding: 2%;
    margin: 2%;
}

#cerrar {
    display:none;
}
</style>

<body>

<div id="sidebar" class="sidebar">
    <a href="#" class="boton-cerrar" onclick="navocultar()">&times;</a>
	<ul class="menu">
			<li><a href="<? echo base_url();?>index.php/Centro">Centro</a></li>
			<li><a href="<? echo base_url();?>index.php/Ciclo">Ciclo</a></li>
			<li><a href="<? echo base_url();?>index.php/Curso">Curso</a></li>
			<li><a href="<? echo base_url();?>index.php/Modulo">Modulo</a></li>
			<li><a href="<? echo base_url();?>index.php/Equipo">Equipo</a>
				<ul>
					<li><a href="<? echo base_url();?>index.php/EquipoUsuario">EquipoUsuario</a></li>
				</ul>
			</li>
			<li><a href="<? echo base_url();?>index.php/Reto">Reto</a>
				<ul>
					<li><a href="<? echo base_url();?>index.php/CrearReto">Crear Reto</a></li>
					<li><a href="<? echo base_url();?>index.php/RetoModulo">RetoModulo</a></li>
				</ul>
			</li>
			<li><a href="<? echo base_url();?>index.php/Usuario">Usuarios</a>
				<ul>
					<li><a href="<? echo base_url();?>index.php/TUsuario">TUsuarios</a></li>
					<li><a href="<? echo base_url();?>index.php/UsuarioModulo">UsuarioModulo</a></li>
				</ul>
			</li>
			<li><a href="<? echo base_url();?>index.php/Medicion">Medición</a>
				<ul>
					<li><a href="<? echo base_url();?>index.php/Medicion_GupoCompetencia_Competencia">Med. GrupoComp.Comps</a></li>
				</ul>
			</li>
			<li><a href="<? echo base_url();?>index.php/Competencia">Comp.</a>
				<ul>
					<li><a href="<? echo base_url();?>index.php/GrupoCompetencia">GrupoCompetencia</a></li>
				</ul>
			</li>
			<li><a href="<? echo base_url();?>index.php/login" id="animacion">Logout</a></li>
	</ul>
</div>

<div id="contenido"><br>
  <a id="abrir" class="abrir-cerrar" href="javascript:void(0)" onclick="navmostrar()">Abrir menu</a><br>
<br><br>
</div>
<script>
function navmostrar() {
    document.getElementById("sidebar").style.width = "300px";
    document.getElementById("contenido").style.marginLeft = "300px";
    document.getElementById("abrir").style.display = "none";
    document.getElementById("cerrar").style.display = "inline";
}

function navocultar() {
    document.getElementById("sidebar").style.width = "0";
    document.getElementById("contenido").style.marginLeft = "0";
    document.getElementById("abrir").style.display = "inline";
    document.getElementById("cerrar").style.display = "none";
}
navocultar();
</script>




<div id="header">
	<ul class="nav">
		<li><a href="<? echo base_url();?>index.php/Centro">Centro</a></li>
		<li><a href="<? echo base_url();?>index.php/Ciclo">Ciclo</a></li>
		<li><a href="<? echo base_url();?>index.php/Curso">Curso</a></li>
		<li><a href="<? echo base_url();?>index.php/Modulo">Modulo</a></li>
		<li><a href="<? echo base_url();?>index.php/Equipo">Equipo</a>
			<ul>
				<li><a href="<? echo base_url();?>index.php/EquipoUsuario">EquipoUsuario</a></li>
			</ul>
		</li>
		<li><a href="<? echo base_url();?>index.php/Reto">Reto</a>
			<ul>
				<li><a href="<? echo base_url();?>index.php/CrearReto">Crear Reto</a></li>
				<li><a href="<? echo base_url();?>index.php/RetoModulo">RetoModulo</a></li>
			</ul>
		</li>
		<li><a href="<? echo base_url();?>index.php/Usuario">Usuarios</a>
			<ul>
				<li><a href="<? echo base_url();?>index.php/TUsuario">TUsuarios</a></li>
				<li><a href="<? echo base_url();?>index.php/UsuarioModulo">UsuarioModulo</a></li>
			</ul>
		</li>
		<li><a href="<? echo base_url();?>index.php/Medicion">Medición</a>
			<ul>
				<li><a href="<? echo base_url();?>index.php/Medicion_GupoCompetencia_Competencia">Medicion_GrupoCompetencia_Competencias</a></li>
			</ul>
		</li>
		<li><a href="<? echo base_url();?>index.php/Competencia">Comp.</a>
			<ul>
				<li><a href="<? echo base_url();?>index.php/GrupoCompetencia">GrupoCompetencia</a></li>
			</ul>
		</li>
		<li><a href="<? echo base_url();?>index.php/login" id="animacion">Logout</a></li>
	</ul><br><br>
</div>

</head>

<body>
<header>
    <title>Rúbricas</title>
</header>

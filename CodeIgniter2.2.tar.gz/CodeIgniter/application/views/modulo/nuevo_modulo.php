<?php
$form = array(
	'name' => 'form_Modulo'
	);
$COD_Modulo = array(
	'name' => 'COD_Modulo',
	'placeholder' => 'Código de Modulo',
	'maxlength' => 10,
	'size' => 20,
	'required' => 1
	);
$DESC_Modulo = array(	
	'name' => 'DESC_Modulo',
	'placeholder' => 'Descripción de Modulo',
	'maxlength' => 100,
	'size' => 30,
	'required' => 1
	);



	if ($Ciclos){
		$ID_Ciclo = array();
		foreach ($Ciclos->result() as $Ciclo) {
			$ID_Ciclo[$Ciclo->ID_Ciclo] = $Ciclo->COD_Ciclo;
		}	
	}
	else{
		$ID_Ciclo = array(
    		0         => 'No hay Ciclos'
		);
	}
	

	

?>


<button class="accordion">Crear Módulo</button>



	<div class="panel">
	<?php echo form_open('Modulo/nuevo_modulo',$form);?>
	<?php echo form_label('Ciclo: ','ID_Ciclo'); ?>
	<?php
	//DESPLEGABLE DE Ciclo
	echo form_dropdown('ID_Ciclo', $ID_Ciclo,1);
	?>
	
	<br>
	<?php echo form_label('Código de Modulo: ','COD_Modulo'); ?>
	<?php echo form_input($COD_Modulo); ?>
	<br>
	<?php echo form_label('Descripción de Modulo: ','DESC_Modulo'); ?>
	<?php echo form_input($DESC_Modulo); ?>
	<br>
	<?php echo form_submit('Crear','Crear'); ?>
	<?php echo form_close();?>
</div>
<?php
$form = array(
	'name' => 'form_modulo'
	);
$url = "'".base_url()."index.php/Modulo'";
$js_cancel_button = 'onClick="location.href='.$url.'"';
$COD_Modulo = array(
	'name' => 'COD_Modulo',
	'placeholder' => 'Código de Modulo',
	'maxlength' => 10,
	'size' => 20,
	'required' => 1,
	'value' => $Modulos->result()[0]->COD_Modulo
	);
$DESC_Modulo = array(	
	'name' => 'DESC_Modulo',
	'placeholder' => 'Descripción de Modulo',
	'maxlength' => 100,
	'size' => 30,
	'required' => 1,
	'value' => $Modulos->result()[0]->DESC_Modulo	
	);



	if ($Ciclos){
		$ID_Ciclo = array();
		foreach ($Ciclos->result() as $Ciclo) {
			$ID_Ciclo[$Ciclo->ID_Ciclo] = $Ciclo->COD_Ciclo;
		}	
	}
	else{
		$ID_Ciclo = array(
    		0         => 'No hay Ciclos'
		);
	}	
	

?>

<div>
	<?php echo form_open('modulo/actualizar/'.$Modulos->result()[0]->ID_Modulo);?>
	<br>

	<?php echo form_label('Ciclo: ','ID_Ciclo'); ?>
	<?php
	//DESPLEGABLE DE Ciclos
	echo form_dropdown('ID_Ciclo', $ID_Ciclo, $Modulos->result()[0]->ID_Ciclo);
	?>
	<br>
	<?php echo form_label('Código de Modulo: ','COD_Modulo'); ?>
	<?php echo form_input($COD_Modulo); ?>
	<br>
	<?php echo form_label('Descripción de Modulo: ','DESC_Modulo'); ?>
	<?php echo form_input($DESC_Modulo); ?>
	<br>
	<?php echo form_submit('Actualizar','Actualizar'); ?>
	<?php echo form_button('Cancelar','Cancelar',$js_cancel_button); ?>	
	<?php echo form_close();?>
</div>
<div>

<b class="borde">Gestión de Medición</b>


		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
	
	
	
	<script type="text/javascript">

		$("document").ready(function(source){


		

				function mostrartabla() {

  $.get('<? echo base_url();?>index.php/Medicion/filtrar_Medicion', function(datos){
		
							datos2=JSON.parse(datos);
							document.getElementById("sacardatos").innerHTML="";
							$("#sacardatos").append(
								"<tr><td><strong>ID_Medicion</strong></td><td><strong>ID_TUsuario</strong></td><td><strong>COD_Medicion</strong></td><td><strong>DESC_Medicion</strong></td><tr>"
						)	
						$.each(datos2,function(indice,valor){
						
		
							$("#sacardatos").append(			

  				"<tr></td><td>"+valor.ID_Medicion+"</td><td>"+valor.ID_TUsuario+"</td><td>"+valor.COD_Medicion+"</td><td>"+valor.DESC_Medicion+"</td></tr>"

								)
						});
					});
}
					mostrartabla();

	});

	</script>
	<hr>
	<div class="tabla">
		<table id='sacardatos'>
		</table>
	</div>
</div>
<?php
$form = array(
	'name' => 'form_usuariomodulo'
	);



	if ($Modulos){
		$ID_Modulo = array();
		foreach ($Modulos->result() as $Modulo) {
			$ID_Modulo[$Modulo->ID_Modulo] = $Modulo->COD_Modulo;
		}	
	}
	else{
		$ID_Modulo = array(
    		0         => 'No hay Modulos'
		);
	}

	if ($Usuarios){
		$ID_Usuario = array();
		foreach ($Usuarios->result() as $Usuario) {
			$ID_Usuario[$Usuario->ID_Usuario] = $Usuario->User;
		}	
	}
	else{
		$ID_Usuario = array(
    		0         => 'No hay Usuarios'
		);
	}	

?>


<button class="accordion">Crear UsuarioMódulo</button>



	<div class="panel">
	<?php echo form_open('UsuarioModulo/nuevo_usuariomodulo',$form);?>
	<?php echo form_label('Modulo: ','ID_Modulo'); ?>
	<?php
	//DESPLEGABLE DE Modulo
	echo form_dropdown('ID_Modulo', $ID_Modulo,1);
	?>
	<br>

	<?php echo form_label('Usuario: ','ID_Usuario'); ?>
	<?php
	//DESPLEGABLE DE Usuario
	echo form_dropdown('ID_Usuario', $ID_Usuario,1);
	?>
	<br>
	<?php echo form_submit('Crear','Crear'); ?>
	<?php echo form_close();?>
</div>
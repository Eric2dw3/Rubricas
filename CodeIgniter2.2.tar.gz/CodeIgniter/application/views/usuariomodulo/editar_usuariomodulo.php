<?php
$form = array(
	'name' => 'form_UsuarioModulo'
	);
$url = "'".base_url()."index.php/UsuarioModulo'";
$js_cancel_button = 'onClick="location.href='.$url.'"';


	if ($Modulos){
		$ID_Modulo = array();
		foreach ($Modulos->result() as $Modulo) {
			$ID_Modulo[$Modulo->ID_Modulo] = $Modulo->COD_Modulo;
		}	
	}
	else{
		$ID_Modulo = array(
    		0         => 'No hay Modulos'
		);
	}

	if ($Usuarios){
		$ID_Usuario = array();
		foreach ($Usuarios->result() as $Usuario) {
			$ID_Usuario[$Usuario->ID_Usuario] = $Usuario->User;
		}	
	}
	else{
		$ID_Usuario = array(
    		0         => 'No hay Usuarios'
		);
	}	

?>

<div>
	<?php echo form_open('UsuarioModulo/actualizar/'.$UsuarioModulos->result()[0]->ID_Usuario_Modulo);?>
	<?php echo form_label('Modulo: ','ID_Modulo'); ?>
	<?php
	//DESPLEGABLE DE CENTRO
	echo form_dropdown('ID_Modulo', $ID_Modulo, $UsuarioModulos->result()[0]->ID_Modulo);
	?>
	<br>

	<?php echo form_label('Usuario: ','ID_Usuario'); ?>
	<?php
	//DESPLEGABLE DE CURSOS
	echo form_dropdown('ID_Usuario', $ID_Usuario, $UsuarioModulos->result()[0]->ID_Usuario);
	?>
	<br>
	<?php echo form_submit('Actualizar','Actualizar'); ?>
	<?php echo form_button('Cancelar','Cancelar',$js_cancel_button); ?>	
	<?php echo form_close();?>
</div>